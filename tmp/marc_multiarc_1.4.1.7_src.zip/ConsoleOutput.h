#ifndef _CONSOLEOUTPUT_H_
	#define _CONSOLEOUTPUT_H_

#include "ArchiveDescription.h"

class CConsoleOutput
{
  HANDLE m_hFile;
  HANDLE m_hFileMap;
  LPSTR  m_lpData;
  bool m_bSaveList;
  bool m_bDoOemConversion;
  bool m_bShowConsole;
  int  m_nIdx;
  void ReleaseContents();
  void FlushOutPipe(HANDLE hReadPipe, HANDLE hOutFile, bool bLoop = false);
public:
  void SetOemConversion(bool bDoConvertion=true){m_bDoOemConversion=bDoConvertion;}
  void SetShowConsole(bool bShowConsole){ m_bShowConsole = bShowConsole;}
  void SetCommandIdx(int nIdx){ m_nIdx = nIdx; }
  CConsoleOutput(bool bSaveList=true);
  ~CConsoleOutput(){ ReleaseContents(); }

  LPCSTR GetOutputData(){return m_lpData;}
  int ExecuteCommand(LPCSTR lpCommand,LPCSTR lpInput /*=NULL */, int MaxErrorLevel);
};

#define MAEL_CANT_CREATE_PROCESS 0x27272727

#endif //_CONSOLEOUTPUT_H_
