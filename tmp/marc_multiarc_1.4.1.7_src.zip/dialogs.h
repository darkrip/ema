#ifndef _DIALOGS_H
 #define _DIALOGS_H

#include "stdafx.h" 
#include "ArchiveDescription.h"

class PropSheetPage;

class ConfigDialog 
{
  HWND m_hParentHwnd; //Parent of Dialog
  void CreateConfigPages();
  enum ePages{
    pageAbout=0,
    pageAddons=1,
    pageSettings=2,
    pageLanguage=3,
    #ifndef USE_ARCH_CONFIG
    pagesCount=4,
    #else 
    pageArchiverConfig=4,
    pagesCount=5,
    #endif
  }; 

  PropSheetPage *m_apPages[pagesCount];
  void BuildHelpFileName();
public:
  ConfigDialog(HWND ParentHandle = GetFocus());
  int Run();
};
//***********************************************************
class PropSheetPage 
{
protected:
  HWND m_hParentHwnd; //HANDLE to TC
  virtual BOOL DlgProc(WORD msg, WPARAM wParam, LPARAM lParam);  
  HWND m_hwnd;
  LPCSTR m_lpTemplateName;
  string m_Title;
  static BOOL CALLBACK DlgProc(HWND hwnd, UINT msg, WPARAM wParam, LPARAM lParam);
  
  HWND GetDlgItem(UINT id) { return ::GetDlgItem(m_hwnd, id); }

  UINT GetDlgItemText(int nIDDlgItem,LPTSTR lpString,int nMaxCount)
              { return ::GetDlgItemText(m_hwnd, nIDDlgItem, lpString, nMaxCount); }
  UINT GetDlgItemInt( int nIDDlgItem, BOOL *lpTranslated, BOOL bSigned )
              { return ::GetDlgItemInt( m_hwnd, nIDDlgItem, lpTranslated, bSigned); }

  BOOL SetDlgItemText( int nIDDlgItem, LPCTSTR lpString )
              { return ::SetDlgItemText( m_hwnd, nIDDlgItem, lpString); }
  BOOL SetDlgItemInt( int nIDDlgItem, int value, BOOL bSigned )
              { return ::SetDlgItemInt( m_hwnd, nIDDlgItem, value, bSigned); }

  HWND m_hToolTipWindow;
  HWND APIENTRY CreateToolTip();
  static LRESULT CALLBACK ToolTipWndProc(HWND hWnd, UINT msg, WPARAM wParam, LPARAM lParam);
  DWORD m_PageHelpTopicID;
protected:
  BOOL AddTool(HWND hWinToToolTip, LPCTSTR szText, RECT* pr = NULL, UINT nIDTool = NULL);
  virtual HBRUSH OnCtlColor(UINT msg, HDC hdc, HWND hwndChild);
  virtual BOOL OnCommand( int id, HWND hwndCtl, UINT nCode);
  virtual BOOL OnInitDialog(HWND hwndFocus, LPARAM lParam) ;
  virtual BOOL OnNotify( int id, NMHDR * lpNMHdr);
  virtual void SetLangCaptions() {};
  virtual BOOL OnCanCancel() {return TRUE;}; //return True if cancel enabled, FALSE otherwise
  void APIENTRY UpdateTipText(HWND hWnd, LPCTSTR lpszText);
  virtual BOOL OnApply(int id, NMHDR * lpNMHdr) {return FALSE;};
  virtual BOOL OnHelp(HELPINFO *lphi = 0);
public:
  virtual void FillPage(PROPSHEETPAGE* psp);
  void SetParentHandle(HWND hParent) {m_hParentHwnd = hParent;};
};
//***********************************************************
class AboutPage : public PropSheetPage
{
  HFONT   m_hFontBold, m_hFontURL;

  HBRUSH  m_hBrush;
  HCURSOR m_hCursor;
protected:
  virtual BOOL   OnCommand( int id, HWND hwndCtl, UINT nCode);
  virtual HBRUSH OnCtlColor(UINT msg, HDC hdc, HWND hwndChild);
  virtual BOOL   OnInitDialog(HWND hwndFocus, LPARAM lParam);
  virtual void SetLangCaptions();
public:
  AboutPage();
  ~AboutPage();
  virtual void FillPage(PROPSHEETPAGE* psp);
};

//***********************************************************
class AddonsPage : public PropSheetPage
{
  string m_curTypeName; 
  HWND m_hwndCheckXList;
  HWND m_hwndCheckSParam;
  HWND m_hwndSMode; 
  HWND m_hwndTypes;
  HWND m_hwndPath;
  HWND m_hwndStaticActive;

  CArchiveDescription *m_padCurSel;
  BOOL CapabilitiesButtonCommand(int nCode);
  BOOL EditIniButtonCommand(int nCode);
  static BOOL CALLBACK AddonsPage::EnumControlsProc( HWND hwnd, LPARAM lParam );
  BOOL GetFileName(string Title, string Filter, 
       DWORD Flags, string InitialDir, string &FileName, BOOL IsReturnExpand = TRUE);

  void InitDescriptions();
  void InitSParams();
  BOOL ImportAddonButtonCommand(int nCode);
  BOOL LoadNewWincmdIniButtonCommand(int nCode);
  BOOL RemoveAddonButtonCommand(int nCode);
  BOOL PathButtonCommand(int nCode);
  BOOL PathEditCommand(int nCode);
  BOOL SParamCheckCommand(int nCode);
  BOOL SParamCheckXListCommand(int nCode);
  BOOL SParamComboCommand(int nCode);
  void SParamHelper();
  BOOL TypeComboCommand(int nCode);
protected:
  virtual BOOL OnCommand( int id, HWND hwndCtl, UINT nCode);
  virtual BOOL OnInitDialog(HWND hwndFocus, LPARAM lParam);
  virtual void SetLangCaptions();
  BOOL OnCanCancel();
  BOOL OnApply(int id, NMHDR * lpNMHdr);
public:
  AddonsPage();
};
//***********************************************************
class SettingsPage : public PropSheetPage
{
  bool m_bInitDialog;

  HWND m_hwndCMode;
  HWND m_hwndCheckTray;
  HWND m_hwndCheckAutoClose;
  HWND m_hwndCheckXList;
  HWND m_hwndDelay;
  HWND m_hwndLines;
  BOOL ChecksHelper(int nCode);
  BOOL DelayEditCommand(int nCode);
  BOOL ModeComboCommand(int nCode);
  BOOL LinesEditCommand(int nCode);
protected:
  virtual BOOL OnCommand( int id, HWND hwndCtl, UINT nCode);
  virtual BOOL OnInitDialog(HWND hwndFocus, LPARAM lParam);
  void SetLangCaptions();
public:
  SettingsPage();
};

//***********************************************************
class LanguagePage : public PropSheetPage
{
  void AddLangItemToLangCombo(const LPSTR LangFileName); //const LPSTR LangName, const LPSTR PathToLangFile);
  void DisableLangControls();
  void FillControlHWND();
  void FillLangCombo();
  void FillParametersName();
  void FillLangAuthoringInfo(LPSTR LangFile);
  void SetParamValue();
  BOOL LangFileComboCommand(int Code);
  HWND m_LangComboHandle;
  HWND m_LangLabelHandle, m_LangLabelVersion, m_LangLabelLastEdit;
  HWND m_LangVersion;
  HWND m_LangLastedit;
  HWND m_LangListParam;
  HWND m_LangValue;
  HWND m_Lang_LBL_Param, m_Lang_LBL_Value, m_Lang_FileInfo;
  string m_Author, m_Copyright, m_Lisence, m_ContactInfo, m_OtherInfo;

  BOOL OnDeleteItem(WPARAM wParam, LPDELETEITEMSTRUCT lParam);
protected:
  virtual BOOL DlgProc(WORD msg, WPARAM wParam, LPARAM lParam);  
  BOOL OnInitDialog(HWND hwndFocus, LPARAM lParam);
  BOOL OnCommand( int id, HWND hwndCtl, UINT nCode);
  void SetLangCaptions();
  BOOL OnApply(int id, NMHDR * lpNMHdr);
public:
  LanguagePage();
};
//***********************************************************


class SinglePage : public PropSheetPage 
{
protected:
  BOOL DlgProc(WORD msg, WPARAM wParam, LPARAM lParam);  
  virtual BOOL OnCommand( int id, HWND hwndCtl, UINT nCode);
  virtual BOOL OnOK();
  virtual BOOL OnCancel();
  virtual BOOL OnTimer(UINT id) {return TRUE;};
public:
  static BOOL CALLBACK DlgProc2(HWND hwnd, UINT msg, WPARAM wParam, LPARAM lParam);
  LPCSTR TemplateName() {return m_lpTemplateName;};
 
};
//***********************************************************
class CapabilitiesPage: public SinglePage
{
  HWND m_hwndCombo;
  HWND m_hwndCheckActive;
  CArchiveDescription *m_pad;
  BOOL ActiveCheckCommand(int nCode);
  BOOL CapCheckCommand(int nCode, int id);
  BOOL ComboCommand(int nCode);
  int  GetCurSelIdx();
protected:
   BOOL OnCommand( int id, HWND hwndCtl, UINT nCode);
   BOOL OnInitDialog(HWND hwndFocus, LPARAM lParam);
   void SetLangCaptions();
   
public:
  CapabilitiesPage();
  void SetArcDesctiption(CArchiveDescription  *AD) {m_pad = AD;};
};
//***********************************************************
class PageDialog 
{
  HWND m_hParentHwnd; //Parent of Dialog
  SinglePage * m_Page;

public:
  PageDialog(HWND ParentHandle, SinglePage *Page);
  int Run();
};

//******************************************************************
class WaitPage : public SinglePage
{
  HANDLE m_hProcess;
protected:
  void SetLangCaptions();
  BOOL OnCancel();
  BOOL OnInitDialog(HWND hwndFocus, LPARAM lParam);
  BOOL OnTimer(UINT id) ;
  UINT_PTR SetTimer(UINT_PTR nIDEvent, UINT uElapse, TIMERPROC lpTimerFunc = 0)
        { return ::SetTimer(m_hwnd, nIDEvent, uElapse, lpTimerFunc); }
public:
  WaitPage() {m_lpTemplateName ="WAIT";}; 
  void SetProcessHandle(HANDLE hProcess) { m_hProcess = hProcess;};
};

//******************************************************************
CArchiveDescription * GetArcTypeUserChoice(const char *ext, vector<CArchiveDescription *> pads);
bool GetSParamUserChoice(int idx, int Paramcount, CArchiveDescription *pad, string & UserChoiceStr);
//******************************************************************
class CArchiverConfigPage : public PropSheetPage
{};

#endif //_DIALOGS_H_
//******************************************************************



