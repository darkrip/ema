// multiarc.cpp : Defines the entry point for the DLL application.
//

#include "stdafx.h"

#include "ArchiverManager.h"

//  #include "dialogs2.h"
#include "dialogs.h"

#include "multiarc.h"

#define E_EGENERALERROR 27

ArcManager theArcMan;
tProcessDataProc pProcessDataProc;

BOOL APIENTRY DllMain( HANDLE hModule, 
                       DWORD  ul_reason_for_call, 
                       LPVOID lpReserved
					 )
{
	switch(ul_reason_for_call)
	{
	case DLL_PROCESS_ATTACH:
    return theArcMan.Initialize((HINSTANCE)hModule);
	}
    return TRUE;
}

// =========================================================================
// WCX entry points ...
// 

int __stdcall OpenArchive(tOpenArchiveData* ArchiveData)
{
  return (int) theArcMan.OpenArchive(ArchiveData);
}

int __stdcall CloseArchive(int hArcData)
{
	return theArcMan.CloseArchive((CArchiverEngine *)hArcData);
}

int __stdcall ReadHeader(int hArcData,tHeaderData* HeaderData)
{ 
	CArchiverEngine *engine=(CArchiverEngine *)hArcData;
	return engine->ReadHeader(HeaderData);
}

int __stdcall ProcessFile(int hArcData,int Operation,char* DestPath,char* DestName)
{
	CArchiverEngine *engine=(CArchiverEngine *)hArcData;

	if(Operation == PK_SKIP)
		return 0;

	int iRet=E_EREAD;
	switch(Operation)
	{
	case PK_EXTRACT:
		iRet=(engine->ExtractFile(DestPath,DestName))?0:E_EGENERALERROR;
		break;
	case PK_TEST:
		iRet=(engine->TestArchive())?0:E_EGENERALERROR;
		break;
	}
	return iRet;
}

int __stdcall PackFiles(char *PackedFile,char *SubPath,char *SrcPath,
      char *AddList,int Flags)
{
	tOpenArchiveData data;
	data.ArcName=PackedFile;
  struct _stat st;
  BOOL bCreate = (_stat(PackedFile, &st) == -1 && errno == ENOENT);
	CArchiverEngine *engine=theArcMan.OpenArchive(&data, bCreate);
	if(!data.OpenResult)
	{
		bool bRet=engine->PackFiles(SubPath,SrcPath,AddList,Flags);
		theArcMan.CloseArchive(engine);
		return bRet?0:E_EGENERALERROR;
	}
	return E_EGENERALERROR;
}

int __stdcall DeleteFiles(char *PackedFile,char *DeleteList)
{
	tOpenArchiveData data;
	data.ArcName=PackedFile;
	CArchiverEngine *engine=theArcMan.OpenArchive(&data);
	if(!data.OpenResult)
	{
		bool bRet=engine->DeleteFiles(DeleteList);
		theArcMan.CloseArchive(engine);
		return bRet?0:E_EGENERALERROR;
	}
	return E_EGENERALERROR;
}

void __stdcall SetChangeVolProc(int hArcData,tChangeVolProc pChangeVolProc)
{
}

int __stdcall GetPackerCaps()
{
  return PK_CAPS_NEW | PK_CAPS_MODIFY | PK_CAPS_MULTIPLE | PK_CAPS_DELETE 
           | PK_CAPS_OPTIONS | PK_CAPS_BY_CONTENT | PK_CAPS_SEARCHTEXT;
}
//************************************************************
void __stdcall SetProcessDataProc(int hArcData,tProcessDataProc pProcessDataProc)
{
  ::pProcessDataProc=pProcessDataProc;
}
//************************************************************
void __stdcall ConfigurePacker(HANDLE ParentHandle, HANDLE hInstance)
{ 
  OutputDebugString("ConfigurePacker enter");
  ConfigDialog dlg((HWND)ParentHandle); //Run config dialog
  dlg.Run();
}
//************************************************************
BOOL __stdcall CanYouHandleThisFile(char* filename)
{
  OutputDebugString("CanYouHandleThisFile enter");
  return (NULL != theArcMan.CanWeHandleThisFile(filename, false, true));
}

// Invoke ConfigureDialog externally
void __stdcall Settings(HWND hWnd, HINSTANCE hInstance, LPTSTR lpCmdLine, int nCmdShow)
{  
  OutputDebugString("Settings enter");
  ConfigurePacker(GetFocus(), theArcMan.Instance());
}

