#include "stdafx.h"
#include "ArchiveDescription.h"
#include "ArchiverManager.h"
#include "ConsoleOutput.h"
#include "multiarc.h"
#include "utils.h"
#include "shlwapi.h"

#define ID_SIGN     "ID"
#define IDPOS       "IDPos"
#define DEBUG_KEY   "Debug"
#define ERRORLEVEL  "Errorlevel"
#define IGNOREERRORS    "IgnoreErrors"
#define UNIXPATH_KEY    "UnixPath"
#define IDEXTENSIONS    "Extension"
#define SKIPEMPTY_KEY         "SkipEmptyNames"
#define SKIPDIRS_IN_FL_KEY    "SkipDirsInFileList"
#define FORCE_BATCH_UNPACK    "BatchUnpack"
#define SEARCH_FOR_UGLY_DIRS  "SearchForUglyDirs"
#define SKIP_SFX_PART "SkipSfxHeader"
#define ID_SEEK_VOLUME "IDSeekRange"
#define EXCLUDEIDS "ExcludeIDs"

//#define INI_KEY_SPARAM_MODE    "AskMode"

#define INI_KEY_SPARAM_SKIP    "SkipLIST"

#define MAX_FORMAT_NUM 50
const char *cszFormatMask="Format%d";

char aKeyNames[][19]=
{
	"TypeName",
	"Archiver",
	"List",
	"Start",
	"End",
//	"Format0","Format1","Format2","Format3",
//	"Format4","Format5","Format6","Format7",
	"Extract",
   "ExtractWithPath",
	"Test",
	"Delete",
	"Add",
	"Move",
	"InputString",
   "Description"
};

// for translation
const K_Lang_ArchiveDescription = 500;
const K_Lang_ArchiveDescription_Invalid_ExtractWithPath = K_Lang_ArchiveDescription +1;
const K_Lang_ArchiveDescription_RestartTC = K_Lang_ArchiveDescription +2;
const K_Lang_ArchiveDescription_SavingConfig = K_Lang_ArchiveDescription +3;
//***********************************************************
CArchiveDescription::CArchiveDescription()
{
  m_bIgnoreErrors=0;
  m_bDebug=0;
  m_bUnixPath=FALSE;
  m_bSkipDirsInFileList=false;
  m_bSkipEmpty=TRUE;
  m_bBatchUnpack=FALSE;
  m_bSearchForUglyDirs = FALSE;
  m_bUserWarned = false;
  m_bRealEntry = false;
  m_eSParam = eSParamNone;
  m_bSParamSkipLIST = TRUE;
  m_bIsModified = false;
  m_bIstGanzNeu = false;
  m_bIstGestorben = false;
  m_SkipSFXPart = false;
  m_SeekAfterIDPos = FALSE;
}
//***********************************************************
void CArchiveDescription::ReleaseContents()
{
  m_bIgnoreErrors=0;
  m_bRealEntry = false;

  m_strings.clear();
  m_poses.clear();
  m_ids.clear();
  m_exts.clear();
  m_formats.clear();
  m_ExcludeIDs.clear();
}
//***********************************************************
void CArchiveDescription::LoadString(const char *szTypeKeyName,int iStrIdx, const char *szIniPath)
{
	char buf[BUFFER_SIZE];
	int iReaded=::GetPrivateProfileString(szTypeKeyName,aKeyNames[iStrIdx],"",buf,BUFFER_SIZE,szIniPath);
  if(iReaded)
  {
    string str(buf);
    m_strings.insert(map<int, string>::value_type(iStrIdx,str));
  }
}
//***********************************************************
LPCSTR CArchiveDescription::String(int idx) const
{ 
  map<int, string>::const_iterator i = m_strings.find(idx);
  
  if(i == m_strings.end())
    return NULL;

  return i->second.c_str(); 
}
//***********************************************************
void CArchiveDescription::LoadFormats(const char *szTypeKeyName, const char *szIniPath)
{
  //OutputDebugString( szTypeKeyName);
//  OutputDebugString(const char szIniPath);
//	char buf[BUFFER_SIZE], key_name[BUFFER_SIZE];
char buf[4096], key_name[4096];
  for(int idx = 0; idx < MAX_FORMAT_NUM; idx++)
  {
	  wsprintf(key_name, cszFormatMask, idx);
    if(! ::GetPrivateProfileString(szTypeKeyName, key_name, "", buf, BUFFER_SIZE, szIniPath))
      break;

    string str(buf);
    m_formats.push_back(str);
  }
}
//***********************************************************
void explode_string(string &str, vector<string> &strings)
{
  unsigned int pos_b=0, pos_e=string::npos;
  
  do
  {
    pos_e = str.find_first_of(',', pos_b);
    
    string ss = str.substr(pos_b, (pos_e != string::npos) ? pos_e - pos_b : pos_e);
    strings.push_back(ss.erase(0, ss.find_first_not_of(' ')));
    pos_b = pos_e + 1;

  }while(pos_e != string::npos);
}
//***********************************************************

BOOL CArchiveDescription::Load(char *szSectionName, const char *szIniPath)
{
  ReleaseContents();

  string strSectionName(szSectionName);
  m_strings.insert(map<int, string>::value_type(0, strSectionName));

  m_eSParam = (eSParamMode) GetPrivateProfileInt(szSectionName,INI_KEY_SPARAM_MODE, eSParamNone, szIniPath);
  m_bSParamSkipLIST = GetPrivateProfileInt(szSectionName,INI_KEY_SPARAM_SKIP, TRUE, szIniPath);

  if(!strcmp(szSectionName, INI_SECTION_SETUP))
  {
    m_strings.insert(map<int, string>::value_type(DESCRIPT_IDX, theArcMan.LangSupport.Strings(K_Lang_ArchiveDescription, "Global settings").c_str() ));
    return TRUE; //skip general settings section ...
  }

  m_bRealEntry = true;

  char buf[BUFFER_SIZE];

  for(int i=ARCHIVER_IDX;i<STRINGS_COUNT;i++)
     LoadString(szSectionName, i, szIniPath);

  LoadFormats(szSectionName, szIniPath);

  int iReaded=::GetPrivateProfileString(szSectionName,ID_SIGN,"",buf,BUFFER_SIZE,szIniPath);
  if(iReaded>0)
  {
    string str(buf);
    vector<string> id_strings;
    explode_string(str, id_strings);

    for(vector<string>::iterator ss = id_strings.begin(); ss != id_strings.end(); ss++)
    {
      vector<unsigned char> v;
      for(int i = 0; i < ss->length(); i+=3)
      {
        char cc = HexVal(ss->at(i)) * 16 + HexVal(ss->at(i+1));
        v.push_back(cc);
      }
      m_ids.push_back(v);
    }
  }

  iReaded = GetPrivateProfileString(szSectionName,IDPOS,"",buf,BUFFER_SIZE,szIniPath);
  if(iReaded > 0)
  {
    string str(buf);
    vector<string> pos_strings;
    explode_string(str, pos_strings);
    int tmpInt;
    for(vector<string>::iterator ss = pos_strings.begin(); ss != pos_strings.end(); ss++)
    {
      if (!stricmp("<SeekID>", ss->c_str()))
        m_SeekAfterIDPos = TRUE;
      else
      {
        StrToIntEx(ss->c_str(),STIF_SUPPORT_HEX, &tmpInt);
        //m_poses.push_back(atoi(ss->c_str()));
        m_poses.push_back(tmpInt /*atoi(ss->c_str()) */);
      }
    }
  }
  else
   {
     m_SeekAfterIDPos = TRUE;
   };
  iReaded = GetPrivateProfileString(szSectionName,IDEXTENSIONS,"",buf,BUFFER_SIZE,szIniPath);
  if(iReaded > 0)
  {
    string str(buf);
    vector<string> pos_strings;
    explode_string(str, pos_strings);

    for(vector<string>::iterator ss = pos_strings.begin(); ss != pos_strings.end(); ss++)
    {
      wcmd_ext ext;
      ext.ext = *ss;
      m_exts.push_back(ext);
      theArcMan.FillReg(m_exts.back());
    }
  }

  if(!m_poses.size())
    m_poses.push_back(0); // default position - zero-offset from begin ...

  m_bIgnoreErrors=GetPrivateProfileInt(szSectionName,IGNOREERRORS,0,szIniPath);
  m_bDebug=GetPrivateProfileInt(szSectionName,DEBUG_KEY,m_bDebug,szIniPath);
  m_bUnixPath=GetPrivateProfileInt(szSectionName,UNIXPATH_KEY,m_bUnixPath,szIniPath);
  m_bSkipDirsInFileList=GetPrivateProfileInt(szSectionName,SKIPDIRS_IN_FL_KEY,m_bSkipDirsInFileList,szIniPath);
  m_bSkipEmpty=GetPrivateProfileInt(szSectionName,SKIPEMPTY_KEY,m_bSkipEmpty,szIniPath);
  m_bBatchUnpack=GetPrivateProfileInt(szSectionName,FORCE_BATCH_UNPACK,m_bBatchUnpack,szIniPath);
  m_bSearchForUglyDirs=GetPrivateProfileInt(szSectionName,SEARCH_FOR_UGLY_DIRS,m_bSearchForUglyDirs,szIniPath);
  m_SkipSFXPart =	GetPrivateProfileInt(szSectionName, SKIP_SFX_PART, m_SkipSFXPart, szIniPath);
  
  const char* BytesInMegabyte = "1048576";
  iReaded = GetPrivateProfileString(szSectionName,ID_SEEK_VOLUME, BytesInMegabyte, buf,BUFFER_SIZE,szIniPath);
  m_IDSeekVolumeSize = atoi(buf);

 
	if(m_bDebug)
		wsprintf(m_szDebugOutputPath,"%smultiarc.%s.log",theArcMan.MADir(), String(TYPENAME_IDX));
	else
		m_szDebugOutputPath[0]=0;

   LoadExcludeIDs(szSectionName, szIniPath);
	return TRUE;
}
//*******************************************************************************
void CArchiveDescription::DebugOutput(LPCSTR szCommand, LPCSTR lpOutput, int errorlevel,LPCSTR lpCurDir)
{
   // Warning!!! Do not translate strings in this procedure!!!!
	if(m_bDebug)
	{
		HANDLE hFile=CreateFile(m_szDebugOutputPath,GENERIC_WRITE,
									FILE_SHARE_WRITE,0,OPEN_ALWAYS,
									FILE_ATTRIBUTE_NORMAL,0);
		if(hFile!=INVALID_HANDLE_VALUE)
		{
			SYSTEMTIME st;
			GetLocalTime(&st);
			char sz[1024];
			char szBound[]="%s:%d/%d/%d %d:%d:%d\r\n\r\n";
			DWORD dwWritten;
			SetFilePointer(hFile,0,0,FILE_END);

			wsprintf(sz,szBound,"\r\n\r\n>>>> BEGIN",st.wDay,st.wMonth,st.wYear,st.wHour,st.wMinute,st.wSecond);

			WriteFile(hFile,sz,strlen(sz),&dwWritten,0);

			char szPrefix[]=">Command executed:";
			WriteFile(hFile,szPrefix,strlen(szPrefix),&dwWritten,0);

			if(szCommand)
			{
				WriteFile(hFile,szCommand,strlen(szCommand),&dwWritten,0);
				WriteFile(hFile,"\r\n\r\n",4,&dwWritten,0);
			}
			else
			{
				strcpy(sz,"Warning!!! No command specified\r\n\r\n");
				WriteFile(hFile,sz,strlen(sz),&dwWritten,0);
			}

			if(lpCurDir)
			{
				char szCurDir[MAX_PATH*2];
				wsprintf(szCurDir,"Current directory : %s\r\n\r\n",lpCurDir);
				WriteFile(hFile,szCurDir,strlen(szCurDir),&dwWritten,0);
			}

			char szPrefixOut[]="> === Archiver output begin ===\r\n\r\n";
			WriteFile(hFile,szPrefixOut,strlen(szPrefixOut),&dwWritten,0);

			if(lpOutput)
				WriteFile(hFile,lpOutput,strlen(lpOutput),&dwWritten,0);
			else
			{
				strcpy(sz,"Warning!!! No archiver output was received\r\n\r\n");
				WriteFile(hFile,sz,strlen(sz),&dwWritten,0);
			}

			char szPrefixEnd[]="\r\n> === Archiver output end ===\r\n\r\n";
			WriteFile(hFile,szPrefixEnd,strlen(szPrefixEnd),&dwWritten,0);

			wsprintf(sz,"> Errorlevel returned: %d %s\r\n\r\n",errorlevel,(errorlevel==MAEL_CANT_CREATE_PROCESS)?"Warning!!! Process wasn't created.":"");
			WriteFile(hFile,sz,strlen(sz),&dwWritten,0);

			GetLocalTime(&st);
			wsprintf(sz,szBound,"<<<< END",st.wDay,st.wMonth,st.wYear,st.wHour,st.wMinute,st.wSecond);
			WriteFile(hFile,sz,strlen(sz),&dwWritten,0);
			CloseHandle(hFile);
		}
	}
}
//***********************************************************
BOOL CArchiveDescription::BatchUnpack()
{
  if(m_bBatchUnpack && m_strings.find(EXTRACT_WITH_PATH_IDX) == m_strings.end())
  {
    MessageBox(GetFocus(),
     theArcMan.LangSupport.Strings(K_Lang_ArchiveDescription_Invalid_ExtractWithPath,
     "You set ON \"Batch unpacking\" feature for this type of archives "
     "but didn't provide corresponding \"ExtractWithPath=\" command lone. Batch "
     "unpacking feature will be set OFF. Please, correct your settings").c_str(),
     theArcMan.LangSupport.Strings(K_Lang_Warning_String, WARNING_STR_CONST).c_str(), MB_ICONWARNING);

    m_bBatchUnpack = false;
  }

  return m_bBatchUnpack;
}
//***********************************************************
void CArchiveDescription::SetSParams(int sepMode, BOOL bSkipLIST)
{
  m_bIsModified |= (m_eSParam != (eSParamMode) sepMode) || (m_bSParamSkipLIST != bSkipLIST);
  m_eSParam = (eSParamMode) sepMode;
  m_bSParamSkipLIST = bSkipLIST; 
}
//***********************************************************
void CArchiveDescription::SetProgramPath(const char *path)
{
  m_bIsModified |= (stricmp(m_strings[ARCHIVER_IDX].c_str(), path) != 0);
  m_strings[ARCHIVER_IDX] = path;  
}
//***********************************************************
void CArchiveDescription::SaveChanges()
{
//#define BUF_SIZE 10  
  char buf[BUFFER_SIZE];
  const char *s_name = m_strings[TYPENAME_IDX].c_str();
  bool bWinCmdIniChanged = false;

  if(m_bIsModified)
    WritePrivateProfileString(s_name, aKeyNames[ARCHIVER_IDX],
          m_strings[ARCHIVER_IDX].c_str(), theArcMan.IniFile());    

  if(m_bIstGanzNeu)
  {
    string str;
    
    for(ids_iterator id=m_ids.begin(); id != m_ids.end(); id++)
    {
      if(id != m_ids.begin())
        str += ",";
      for(int i=0; i<id->size(); i++)
      {
        sprintf(buf, "%02X ", (*id)[i]);
        str += buf;
      }
    }

    if(str.length())
      WritePrivateProfileString(s_name, ID_SIGN, str.c_str(), theArcMan.IniFile());

    str = "";
    for(poses_iterator pos=m_poses.begin(); pos != m_poses.end(); pos++)
    {
      if(pos != m_poses.begin())
        str += ",";
      str += itoa(*pos, buf, 10 /*BUFFER_SIZE*/);
    }

    if(str.length())
      WritePrivateProfileString(s_name, IDPOS, str.c_str(), theArcMan.IniFile());

    str = "";
    for(exts_iterator ext=m_exts.begin(); ext != m_exts.end(); ext++)
    {
      if(ext != m_exts.begin())
        str += ",";
      str += ext->ext;
    }

    if(str.length())
      WritePrivateProfileString(s_name, IDEXTENSIONS, str.c_str(), theArcMan.IniFile());

    for(strings_iterator s=m_strings.begin(); s != m_strings.end(); s++)
      if(s->first != TYPENAME_IDX)
      {
        string str = s->second;
        str.insert(0,'"');
        str.append(1,'"');
        WritePrivateProfileString(s_name, aKeyNames[s->first], str.c_str(), theArcMan.IniFile());
      }
    for(int i = 0; i < m_formats.size(); i++)
    {
      wsprintf(buf, cszFormatMask, i);
      WritePrivateProfileString(s_name, buf, m_formats[i].c_str(), theArcMan.IniFile());
    }
    WritePrivateProfileInt(s_name,IGNOREERRORS,m_bIgnoreErrors,theArcMan.IniFile());
	 WritePrivateProfileInt(s_name,DEBUG_KEY,m_bDebug,theArcMan.IniFile());
	 WritePrivateProfileInt(s_name,UNIXPATH_KEY,m_bUnixPath,theArcMan.IniFile());
	 WritePrivateProfileInt(s_name,SKIPDIRS_IN_FL_KEY,m_bSkipDirsInFileList,theArcMan.IniFile());
	 WritePrivateProfileInt(s_name,SKIPEMPTY_KEY,m_bSkipEmpty,theArcMan.IniFile());
	 WritePrivateProfileInt(s_name,FORCE_BATCH_UNPACK,m_bBatchUnpack,theArcMan.IniFile());
    WritePrivateProfileInt(s_name,SEARCH_FOR_UGLY_DIRS,m_bSearchForUglyDirs,theArcMan.IniFile());

  }

  if(m_bIsModified)
  {
//    WritePrivateProfileInt(s_name, INI_KEY_SPARAM_MODE, 
 //                            (m_eSParam == eSParamNext) ? 0 : m_eSParam, theArcMan.IniFile());
    WritePrivateProfileInt(s_name, INI_KEY_SPARAM_MODE, m_eSParam, theArcMan.IniFile());
    WritePrivateProfileInt(s_name, INI_KEY_SPARAM_SKIP, m_bSParamSkipLIST, theArcMan.IniFile());
  }

  for(exts_iterator i = m_exts.begin(); i < m_exts.end(); i++)
    bWinCmdIniChanged |= theArcMan.SaveReg(*i);
 
  if(bWinCmdIniChanged)
    MessageBox(GetFocus(), theArcMan.LangSupport.Strings(K_Lang_ArchiveDescription_RestartTC,
    "Restart TCommander to apply your changes, please.").c_str(), 
    theArcMan.LangSupport.Strings(K_Lang_ArchiveDescription_SavingConfig,
    "Saving MultiArc configuration").c_str(), MB_ICONWARNING);
}
//***********************************************************
eSParamMode CArchiveDescription::GetValidSParam() const
{
  if(m_bRealEntry && m_eSParam == eSParamNone)
  {
    CArchiveDescription * pad_general = theArcMan.GetADbyId(-1); // retrieve "MultiArc" general description 
    return pad_general ? pad_general->m_eSParam : eSParamNone;
  }

  return m_eSParam;
}
//***********************************************************
BOOL CArchiveDescription::SParamValidSkipLIST() const
{
  if(m_bRealEntry && m_eSParam == eSParamNone)
  {
    CArchiveDescription * pad_general = theArcMan.GetADbyId(-1); // retrieve "MultiArc" general description 
    return pad_general ? pad_general->m_bSParamSkipLIST : TRUE;
  }

  return m_bSParamSkipLIST;
}
//***********************************************************
void CArchiveDescription::SetValidSParamMode(eSParamMode espm)
{
  if(m_bRealEntry && m_eSParam == eSParamNone)
  {
    CArchiveDescription * pad_general = theArcMan.GetADbyId(-1); // retrieve "MultiArc" general description 
    if( pad_general )
      pad_general->m_eSParam = espm;
  }

  m_eSParam = espm;
}
//***********************************************************
bool CArchiveDescription::IsRegistered() const 
{ 
  bool b_ret = false;
  for(int i = 0; i < m_exts.size(); i++)
    b_ret |= m_exts[i].active;
  return b_ret; 
}
//***********************************************************
bool CArchiveDescription::HasChanges()
{
  bool b_ret = m_bIsModified | m_bIstGanzNeu;
  for(int i = 0; i < m_exts.size(); i++)
    b_ret |= m_exts[i].is_modified;
  return b_ret;
}
//***********************************************************
enum ExcludeID_States
{
  eis_Skip,
  eis_Finish,
  eis_ExtractID,
  eis_ExtractOffset,
  eis_ExtractAbsolute,
  eis_Save,
  eis_Error
};
//***********************************************************
void CArchiveDescription::LoadExcludeIDs(char *szSectionName, const char *szIniPath)
{
  char buf[BUFFER_SIZE];
  _strnset(buf,0,BUFFER_SIZE);
  int iReaded=::GetPrivateProfileString(szSectionName,EXCLUDEIDS,"",buf,BUFFER_SIZE,szIniPath);
  if(iReaded>0)
  {
    ExcludeID_States state = eis_Skip;
    ExcludeID_Struct  tmpExcludeIdStruct;
    tmpExcludeIdStruct.offset =0; // by default
    tmpExcludeIdStruct.isAbsolute = false; // by default
    char * Pos_b ; char  * Pos_e ;char  * Pos_Error ;
    for (const char* Current = buf; state != eis_Finish; Current++)
    {
      switch (state)
      {
        ///////////////////////////////////////////////////////
        case eis_Skip :
        { 
          if (*Current =='(')
          { 
            state = eis_ExtractID; //eis_StartBlock;
            Pos_b = (char *) Current +1; 
            Pos_Error = (char *) Current; 
          };
          if (*Current == 0) 
          {  
            state = eis_Finish;
          } // if
          break;
        }; //eis_Skip
        case eis_Finish:{break;}; //
        ///////////////////////////////////////////////////////
        case eis_ExtractID :{
          if ((*Current == ')') || (*Current == ',') ) 
          { Pos_e = (char *)(Current);
            string tmpstr(Pos_b, Pos_e);
            vector<string> id_strings;
            explode_string(tmpstr, id_strings);
            for(vector<string>::iterator ss = id_strings.begin(); ss != id_strings.end(); ss++)
            {
              vector<unsigned char> v;
              for(int i = 0; i < ss->length(); i+=3)
              {
                char cc = HexVal(ss->at(i)) * 16 + HexVal(ss->at(i+1));
                v.push_back(cc);
              }
              tmpExcludeIdStruct.ID = v;//.assign(v.begin(), v.end());      
            };
            Pos_b = Pos_e +1;
            Pos_e = 0;
        
          } ;//if
          if (*Current == ')')   {state = eis_Save; break;}
          if (*Current == ',' ) {state = eis_ExtractOffset; break;};
          if ((*Current == '(') || (*Current == 0)) 
          { 
            Pos_e  = (char *)Current; 
            Current--;  
            state = eis_Error; 
            break;
          };
          break;
        }; //
        ///////////////////////////////////////////////////////
        case eis_ExtractOffset:{
          if ((*Current == ')') || (*Current == ',') ) 
          { Pos_e = (char *)(Current);
            string tmpstr(Pos_b, Pos_e);
            tmpExcludeIdStruct.offset = atoi(tmpstr.c_str());       
            Pos_b = Pos_e+1; Pos_e =0;
          } //if
          if (*Current == ')')   {
            state = eis_Save; 
            if (*(Current +1) == ',') {Pos_b = Pos_b+1;}
            break;
          } // if (*Current == ')')
          if (*Current == ',' ) {state = eis_ExtractAbsolute; break;};
          if ((*Current == '(') || (*Current == 0)) 
          { 
            Pos_e  = (char *)Current; 
            state = eis_Error; 
            break;
          };
          break;
        }; //eis_ExtractOffset
        ///////////////////////////////////////////////////////
        case eis_ExtractAbsolute:
        {
          if (*Current == ')') { 
             state = eis_Save; 
             Pos_e = (char *)(Current);
             string tmpstr(Pos_b, Pos_e); 
             tmpExcludeIdStruct.isAbsolute = atoi(tmpstr.c_str())==1;
             
             break;
          } // if
          if ((*Current == '(') || (*Current == 0) || (*Current == ',')) 
          { 
            //Pos_e  = (char *)Current; 
            state = eis_Error; 
            break;
          };
          break;
        }; //eis_ExtractAbsolute
        ///////////////////////////////////////////////////////
        case eis_Save :
        {
          state = eis_Skip; 
          m_ExcludeIDs.push_back(tmpExcludeIdStruct);
          break;
        }; //eis_Save
        ///////////////////////////////////////////////////////
        case eis_Error:{
          string tmpstr(Pos_Error);//, Pos_e);
          DebugOutput("Error in the ExcludeID param", tmpstr.c_str()); 
          state = eis_Skip; }; //eis_Error
          Current--;  
      } // switch (state) 
    } //for (const char* Current = buf; state != eis_Finish; Current++)
  } ;
};
//***********************************************************