#ifndef _UTILS_H_
#define _UTILS_H_

// some lost macros ...
#define SetDlgItemFont(hwnd, id, hfont, fRedraw) \
           SendDlgItemMessage((HWND)(hwnd), (int)(id), WM_SETFONT, (WPARAM)(hfont), (LPARAM)(fRedraw));

#define GetDlgItemFont(hwnd, id) \
           (HFONT)SendDlgItemMessage((HWND)(hwnd), (int)(id), WM_GETFONT, (WPARAM)0, (LPARAM)0);


LPSTR GetErrorMessage();
char * GetWCXVersion(char * lpc);
int HexVal(char c);

#define iZspace(ch)((ch)==' ' || (ch)=='\t' || (ch)=='\r' || (ch)=='\n')

BOOL WritePrivateProfileInt(const char *section, const char *key, int iValue, const char *ini_file);

string ExpandParam(string Mask, ...); // Replace same parameters in mask

#endif //_UTILS_H_