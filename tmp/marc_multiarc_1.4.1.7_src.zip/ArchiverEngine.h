#ifndef _ARCHIVERENGINE_H_
	#define _ARCHIVERENGINE_H_

#include "ConsoleOutput.h"
#include "ArchiveDescription.h"
#include "ArcItem.h"

class CArchiverEngine
{
	bool m_bAlreadyTested;
	char m_szArcPathName[_MAX_PATH];
	CConsoleOutput m_coList;
	CArchiveDescription *m_pad;
	CArchiverEngine(CArchiveDescription *pad,tOpenArchiveData *data,BOOL bCreate=FALSE);
	~CArchiverEngine();
public:
	bool OnClose();
	bool PackFiles(char *szSubPath,char *szSrcPath,char *AddList,int Flags);
	bool DeleteFiles(char *DeleteList);
	bool TestArchive();
	bool ExtractFile(LPSTR lpDestPath,LPSTR lpDestName);
	int ReadHeader(tHeaderData *hdrData);
	friend class ArcManager;
private:
	bool IsArchiveType(LPCSTR);
	bool ParseNExecuteCommand(int idx, LPCSTR lpFileOrList=NULL);
	CArcItem *m_pCurItem;
	void AdjustBounds();
	int m_iEndOff;
	int m_iBeginOff;
	int m_iOpenMode;
	CArcItem *m_pArcItemsList;
	char *m_pDeferedNames;
//MB<<
	char *m_pDestPath, *m_pStripPath, *m_SubPath;
//MB>>
};

#endif //_ARCHIVERENGINE_H_
