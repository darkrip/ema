#include "stdafx.h"
#include "multiarc.h"
#include "resource.h"
#include "MAConsole.h"

const char* ccMAConsoleClassName="MAConsoleWndClass";
char *rtfHeader = "{\\rtf1\\ansi\\deff0"
    "{\\fonttbl{\\f0 Courier;}}"
    "{\\colortbl ;"
    "\\red255\\green255\\blue255;"
    "\\red255\\green0\\blue0;"
    "\\red0\\green255\\blue0;"
    "\\red0\\green0\\blue255;}"
    "\\pard\\cf1\\f0\\fs24 ";
char *rtfFooter = "}";

#define NIM_CALLBACK_MESSAGE WM_USER

const int cnTimerId = 70170;

const char *ccWindowKey = "ConRect";

MAConsole::MAConsole()
{
  m_hRichEdLib = LoadLibrary("RICHED32.DLL");
  m_hEvent = CreateEvent(0, TRUE, FALSE, 0);
  m_hCtrlBreakEvent = CreateEvent(0, TRUE, FALSE, CTRL_BREAK_EVENT_NAME);
  m_hEventExLines = CreateEvent(0, TRUE, 0, 0);
  m_hMutexExLines = CreateMutex(0, FALSE, 0);;
}

MAConsole::~MAConsole()
{
  FreeLibrary(m_hRichEdLib);
  CloseHandle(m_hEvent);
  CloseHandle(m_hEventExLines);
  CloseHandle(m_hMutexExLines);
  CloseHandle(m_hCtrlBreakEvent);
  DestroyConsole();
}

void MAConsole::CreateConsole()
{
  m_bDieReq = false;
  DWORD dwThreadId;
  m_hThread = CreateThread(0, 0, ThreadProc, this, 0, &dwThreadId);

  WaitForSingleObject(m_hEvent, 3000);

  if(m_bUseTray)
  {
    NOTIFYICONDATA nid;
    memset(&nid, 0, sizeof(NOTIFYICONDATA));
    nid.cbSize = sizeof(NOTIFYICONDATA);
    nid.hWnd = m_hwnd;
    nid.uFlags = NIF_ICON | NIF_MESSAGE | NIF_TIP;
    nid.uCallbackMessage = NIM_CALLBACK_MESSAGE;
    strcpy(nid.szTip, "MultiArc Console");
    nid.hIcon = (HICON)LoadImage(theArcMan.Instance(), "ARCHIVE", IMAGE_ICON, 16, 16 ,0);
    Shell_NotifyIcon(NIM_ADD, &nid);
  }
}

void MAConsole::DestroyConsole()
{
  if(m_bUseTray)
  {
    NOTIFYICONDATA nid;
    memset(&nid, 0, sizeof(NOTIFYICONDATA));
    nid.cbSize = sizeof(NOTIFYICONDATA);
    nid.hWnd = m_hwnd;
    Shell_NotifyIcon(NIM_DELETE, &nid);
  }

  m_bDieReq = true;
  PostMessage(m_hwnd, WM_NULL, 0 , 0); // let GetMessage go ...
  if(WaitForSingleObject(m_hThread, 1000) == WAIT_TIMEOUT)
    TerminateThread(m_hThread, 0);

  CloseHandle(m_hThread); 
  m_hThread = NULL;
  m_hwnd = 0;
}

DWORD CALLBACK MAConsole::StreamCallback(DWORD dwCookie, LPBYTE buff, LONG cb, LONG *pcb)
{
  MAConsole *pThis = (MAConsole *)dwCookie;
  
  int len = min(pThis->m_length, cb);
  
  memcpy(buff, pThis->m_buff_ptr, len);
  
  *pcb = len;
  
  if(len >= pThis->m_length)
  {
    pThis->m_buff_ptr += len;
    pThis->m_length -= len;
  }

  return 0;
}

void MAConsole::Text(const char *buff, int nFormat)
{
  if(m_cm == cmNever || !IsWindow(m_hwnd) || IsIconic(m_hwnd))
    return;


  WaitForSingleObject(m_hMutexExLines, INFINITE);

  m_buff = buff;
  m_length = strlen(m_buff);
  m_buff_ptr = m_buff;

  EDITSTREAM es;
  memset(&es, 0 , sizeof(EDITSTREAM));
  es.dwCookie = (long) this;
  es.pfnCallback = StreamCallback;

  SendMessage(m_hwndEdit, WM_SETREDRAW, FALSE, 0);

  int n_len=Edit_GetTextLength(m_hwndEdit);
  Edit_SetSel(m_hwndEdit, n_len,n_len);
  SendMessage(m_hwndEdit, EM_STREAMIN, nFormat|SFF_SELECTION, (LPARAM)&es);

  int nCount = Edit_GetLineCount(m_hwndEdit);
  SendMessage(m_hwndEdit, WM_VSCROLL, MAKEWPARAM(SB_BOTTOM, 0), 0);

  if(theArcMan.CLines() && nCount > theArcMan.CLines())
    SetEvent(m_hEventExLines);

  SendMessage(m_hwndEdit, WM_SETREDRAW, TRUE, 0);

  int nLines = theArcMan.CLines();
  if(!nLines || nLines > nCount)
    InvalidateRect(m_hwndEdit, 0, TRUE);

  ReleaseMutex(m_hMutexExLines);
  PostMessage(m_hwnd, WM_NULL, 0, 0);
}

void MAConsole::Header(const char *buff, bool bRtf)
{
  string strText(buff);
  int pos = 0;
  while((pos = strText.find_first_of("\r\n\\", pos)) != string::npos)
  {
    switch(strText[pos])
    {
    case '\r': strText.erase(pos, 1); break;
    case '\n': strText.replace(pos, 1, " \\par "); break;
    case '\\': if(!bRtf) strText.replace(pos, 1, "\\'5c"); break;
    default: break;
    }
    pos++;
  }

  strText.insert(0, rtfHeader);
  strText.append(rtfFooter);

  Text(strText.c_str(), SF_RTF);
}

void MAConsole::CheckTopLines()
{
  if(WaitForSingleObject(m_hEventExLines, 0) != WAIT_OBJECT_0)
    return;

  if(!theArcMan.CLines())
    return;

  if(WaitForSingleObject(m_hMutexExLines, 0) == WAIT_OBJECT_0)
  {
    int nDiff = Edit_GetLineCount(m_hwndEdit) - theArcMan.CLines();
    if(nDiff > 0)
    {
      SendMessage(m_hwndEdit, WM_SETREDRAW, FALSE, 0);
      CHARRANGE cr={0,0};
      cr.cpMax = Edit_LineIndex(m_hwndEdit, nDiff);
      SendMessage(m_hwndEdit, EM_EXSETSEL, 0, (LPARAM)&cr);
      SendMessage(m_hwndEdit, EM_REPLACESEL, FALSE, (LPARAM)"");
      cr.cpMax = cr.cpMin = Edit_GetTextLength(m_hwndEdit);
      SendMessage(m_hwndEdit, EM_EXSETSEL, 0, (LPARAM)&cr);
      SendMessage(m_hwndEdit, WM_VSCROLL, MAKEWPARAM(SB_BOTTOM, 0), 0);
      SendMessage(m_hwndEdit, WM_SETREDRAW, TRUE, 0);
      InvalidateRect(m_hwndEdit, 0, TRUE);
    }
    ReleaseMutex(m_hMutexExLines);
    ResetEvent(m_hEventExLines);
  }
}

BOOL MAConsole::OnCreate(HWND hwnd, LPCREATESTRUCT lpCreateStruct)
{
  m_hwndEdit=CreateWindowEx(0, "RichEdit", "", 
                 WS_CHILD|WS_VISIBLE|ES_READONLY|ES_MULTILINE|
                 ES_AUTOHSCROLL|ES_AUTOVSCROLL|WS_VSCROLL|WS_HSCROLL, 
               0, 0, 0, 0, m_hwnd = hwnd,
               (HMENU)IDC_EDIT, theArcMan.Instance(), 0);

  SendMessage(m_hwndEdit, EM_SETBKGNDCOLOR, 0, RGB(0,0,0));
  CHARFORMAT cf;
  memset(&cf, 0, sizeof(CHARFORMAT));
  cf.cbSize = sizeof(CHARFORMAT);
  cf.dwMask = CFM_COLOR | CFM_FACE | CFM_BOLD;
  cf.dwEffects &= ~CFE_BOLD;
  cf.crTextColor = RGB(0, 255, 0);
  strcpy(cf.szFaceName, "Courier");
  SendMessage(m_hwndEdit, EM_SETCHARFORMAT, SCF_ALL, (LPARAM)&cf);

  
  DWORD dwEvMask = SendMessage(m_hwndEdit, EM_GETEVENTMASK, 0, 0);
  SendMessage(m_hwndEdit, EM_SETEVENTMASK, 0, dwEvMask | ENM_KEYEVENTS);

  HMENU hMenu = GetSystemMenu(m_hwnd, FALSE);
  AppendMenu(hMenu, MF_SEPARATOR, 0, "");
  AppendMenu(hMenu, MF_STRING, IDM_BREAK_RUN, "Break run\tF4");

  Header("Welcome to {\\cf2 MultiArc} Console!!!\n\n", true);

  return TRUE;
}

void MAConsole::OnSize(UINT state, int cx, int cy)
{  
  switch(state)
  {
  case SIZE_MINIMIZED: 
    if(m_bUseTray)
      OnTrayMessage(0, WM_LBUTTONDOWN);
    break;
  }

  SetWindowPos(m_hwndEdit, HWND_TOP, 0, 0, cx, cy, SWP_NOACTIVATE|SWP_NOZORDER);
  SaveWindowSettings();
}

void MAConsole::OnMove(int cx, int cy)
{  
  SaveWindowSettings();
}

void MAConsole::OnExecuteCommand(bool bStart, bool bIsCSet)
{
  OnCParamsChange(); // retrieve settings

  if(m_cm == cmNever)
    return;
  
  if(bStart)
  {
    if((m_cm == cmIfDef) ? bIsCSet : true)
    {
      if(!IsWindow(m_hwnd))
        CreateConsole();

      SetTimer(m_hwnd, cnTimerId, theArcMan.CDelay() * 1000, 0);
    }
  }
  else
  {
    if(IsWindow(m_hwnd))
    {
      if(theArcMan.CAutoClose())
        ShowWindow(SW_MINIMIZE);
      else
        if(m_cm != cmAlways)
          DestroyConsole();
    }
    KillTimer(m_hwnd, cnTimerId);
    ResetEvent(m_hCtrlBreakEvent);
  }
}

LRESULT MAConsole::OnTimer(int id)
{
  if(id == cnTimerId)
  {
    if(!IsWindowVisible(m_hwnd))
    {
      //HWND hwndFocus = GetFocus();
      ShowWindow(SW_SHOWNOACTIVATE/*RESTORE*/);
      //SetFocus(hwndFocus);
    }
  
    KillTimer(m_hwnd, id);
  }
  return 0;
}

void MAConsole::OnCParamsChange()
{
  bool bHasChanges = false;

  if((bHasChanges |= (m_cm != theArcMan.CMode()))
       || (bHasChanges |= (m_bUseTray != (theArcMan.CMinimize() == TRUE))))
  {
    DestroyConsole();
    m_cm = theArcMan.CMode();
    m_bUseTray = theArcMan.CMinimize() == TRUE;
  }
}

LRESULT MAConsole::OnClose()
{
  OnTrayMessage(0, WM_LBUTTONDOWN);
  return 0;
}

BOOL MAConsole::OnSysCommand(UINT id, int x, int y)
{
  BOOL bRet = FALSE;
  if(id == IDM_BREAK_RUN)
  {
    SetEvent(m_hCtrlBreakEvent);
    bRet = FALSE;
  }
  return bRet; 
}

void MAConsole::OnNotify(int id, LPNMHDR lpnmhdr)
{
  if(id == IDC_EDIT && lpnmhdr->code == EN_MSGFILTER)
  {
    MSGFILTER *pMsgFltr = (MSGFILTER *) lpnmhdr; 
    switch(pMsgFltr->msg)
    {
    case WM_KEYUP:
      switch(pMsgFltr->wParam)
      {
      case VK_ESCAPE:
        OnTrayMessage(0, WM_LBUTTONDOWN);
        break;
      case VK_F4:
        PostMessage(m_hwnd, WM_SYSCOMMAND, IDM_BREAK_RUN, 0);
        break;
      }
      break;
    }
  }
}

void MAConsole::OnSetFocus(HWND hwndPrev)
{
  SetFocus(m_hwndEdit);
}

LRESULT CALLBACK MAConsole::WndProc(HWND hwnd, WORD msg, WPARAM wParam, LPARAM lParam)
{
  MAConsole *pThis = (MAConsole *) GetWindowLong(hwnd, GWL_USERDATA);
  switch (msg)
  {
  case WM_CREATE:
    {
      LPCREATESTRUCT lpCreate = (LPCREATESTRUCT)lParam;
      pThis = (MAConsole *) lpCreate->lpCreateParams;
      SetWindowLong(hwnd, GWL_USERDATA, (long)lpCreate->lpCreateParams);
      return pThis->OnCreate(hwnd, lpCreate) ? 0L : (LRESULT)-1L;
    } 
  case WM_SETFOCUS:
    pThis->OnSetFocus((HWND)wParam);
    return 0;
  case WM_SIZE:
    return pThis->OnSize((UINT)wParam, (int)(short)LOWORD(lParam), (int)(short)HIWORD(lParam)), 0;
  case WM_MOVE:
    return pThis->OnMove((int)(short)LOWORD(lParam), (int)(short)HIWORD(lParam)), 0;
  case WM_CLOSE:
    return pThis->OnClose();
  case WM_TIMER:
    return pThis->OnTimer(wParam);
  case NIM_CALLBACK_MESSAGE:
    return pThis->OnTrayMessage((UINT)wParam, (UINT)lParam);
  case WM_SYSCOMMAND:
    if(pThis->OnSysCommand((UINT)(wParam), (int)(short)LOWORD(lParam), (int)(short)HIWORD(lParam)))
      return 0;
  case WM_NOTIFY:
    pThis->OnNotify((int) wParam, (LPNMHDR) lParam);
  default:
    return DefWindowProc(hwnd, msg, wParam, lParam);
  }
} 

LRESULT MAConsole::OnTrayMessage(UINT id, UINT msg)
{
  switch(msg)
  {
  case WM_LBUTTONDOWN: 
  case WM_RBUTTONDOWN: 
    if(m_bUseTray)
    {
      bool bIsVisible = IsWindowVisible(m_hwnd) == TRUE;
      SetWindowPos(m_hwnd, HWND_TOP, 0, 0, 0, 0, SWP_NOMOVE|SWP_NOSIZE|(bIsVisible ? SWP_HIDEWINDOW : SWP_SHOWWINDOW));
      if(!bIsVisible)
        ShowWindow(SW_RESTORE);
    }
    else
      ShowWindow(IsIconic(m_hwnd) ? SW_RESTORE : SW_MINIMIZE);
    break;
  default:break;
  }
  return 0;
}

DWORD WINAPI MAConsole::ThreadProc( LPVOID lpParameter )
{
  MAConsole *pThis = (MAConsole *)lpParameter;

  WNDCLASSEX wc;
  memset(&wc, 0 , sizeof(WNDCLASSEX));
  if(!GetClassInfoEx(theArcMan.Instance(), ccMAConsoleClassName, &wc))
  {
    memset(&wc, 0 , sizeof(WNDCLASSEX));
    wc.cbSize = sizeof(WNDCLASSEX);
    wc.style = CS_VREDRAW|CS_HREDRAW; 
    wc.lpfnWndProc = (WNDPROC)WndProc; 
    wc.cbWndExtra = sizeof(MAConsole *); 
    wc.hInstance = theArcMan.Instance(); 
    wc.hIcon = (HICON)LoadImage(theArcMan.Instance(), "ARCHIVE", IMAGE_ICON, 32, 32 ,0); 
    wc.hIconSm = (HICON)LoadImage(theArcMan.Instance(), "ARCHIVE", IMAGE_ICON, 16, 16 ,0);
    wc.hbrBackground = (HBRUSH)(COLOR_BTNTEXT+1); 
    wc.lpszClassName = ccMAConsoleClassName;
    RegisterClassEx(&wc);
  }

  HWND hwnd = CreateWindowEx(WS_EX_CLIENTEDGE, ccMAConsoleClassName, 
                             "MultiArc console", WS_OVERLAPPEDWINDOW|WS_CLIPCHILDREN,
                             CW_USEDEFAULT, CW_USEDEFAULT, CW_USEDEFAULT, CW_USEDEFAULT,
                             0, 0, theArcMan.Instance(), pThis);
  
  WINDOWPLACEMENT wp = pThis->GetWindowSettings();
  if(wp.length)
    SetWindowPlacement(hwnd, &wp);

  SetEvent(pThis->m_hEvent);

  MSG msg;
  while(GetMessage( &msg, NULL, 0, 0 ))
  { 
    if(pThis->IsDying())
      break;

    pThis->CheckTopLines();

    TranslateMessage(&msg); 
    DispatchMessage(&msg);
  }
  
  DestroyWindow(hwnd);
  return 0;
}

void MAConsole::SaveWindowSettings()
{
  WINDOWPLACEMENT wp;
  memset(&wp, 0, sizeof(WINDOWPLACEMENT));
  wp.length = sizeof(WINDOWPLACEMENT);
  GetWindowPlacement(m_hwnd, &wp);
  WritePrivateProfileStruct(INI_SECTION_SETUP, ccWindowKey, &wp, sizeof(WINDOWPLACEMENT), theArcMan.IniFile());
}

WINDOWPLACEMENT MAConsole::GetWindowSettings()
{
  WINDOWPLACEMENT wp;
  if(!GetPrivateProfileStruct(INI_SECTION_SETUP, ccWindowKey, &wp, sizeof(WINDOWPLACEMENT), theArcMan.IniFile()))
    memset(&wp, 0, sizeof(WINDOWPLACEMENT));

  return wp;
}