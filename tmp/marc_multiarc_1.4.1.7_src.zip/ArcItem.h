#ifndef _ARCITEM_H_
	#define _ARCITEM_H_

#include "ArchiveDescription.h"

class CArcItem
{
	friend class CArchiverEngine;
	CArcItem *m_pNext;
	char m_szFilePath[MAX_PATH];
	int  m_iPackedSize;
	int  m_iUnpackedSize;
	int  m_iFileAttr;
	union
	{
		int  m_iFileTime;
		struct  _dos_ftime {
        /* least significant bits in a double word goes first! */
        unsigned short  sec   : 5;   /* 0  Seconds / 2 */
        unsigned short  min   : 6;   /* 5  Minutes */
        unsigned short  hour  : 5;   /* 11 Hours */
        unsigned short  day   : 5;   /* 16 Days */
        unsigned short  month : 4;   /* 21 Months */
        unsigned short  year  : 7;   /* 25 Year - 1980 */
		}ftime;
	};

public:
	CArcItem();
	~CArcItem();
	CArcItem *GetNext(){return m_pNext;}
	static CArcItem *LoadFromList(const char *pList,int iListLen,CArchiveDescription *pad);
	static int ParseFormatLine(const char *pFmt,const char **ppBeg, CArcItem *pai,CArchiveDescription *pad);
};

#endif //_ARCITEM_H_
