/*----------Console application (CONSPAWN.EXE) code-----------------------
This program (CONSPAWN) is launched with a hidden console that inherits 
the redirected standard handles of the Win32 application. The application 
that CONSPAWN launches in the same hidden console inherits the same redirected 
standard handles. This behavior redirects the standard handles of the MS-DOS 
application to be launched to the pipe created in the parent Win32 application. 
-------------------------------------------------------------------------*/ 
#include <windows.h>
#include <stdio.h>
#include "multiarc.h"

int main (int argc, char *argv[])
{
		int ExitCode = -1;
    BOOL                bRet = FALSE;
    STARTUPINFO         si   = {0};
    PROCESS_INFORMATION pi   = {0};

    SetLastError(0);
    HANDLE hCtrlBreakEvent = CreateEvent(0, FALSE, FALSE, CTRL_BREAK_EVENT_NAME);

    // Make child process use this app's standard files.
    si.cb = sizeof(si);
    si.dwFlags    = STARTF_USESTDHANDLES;
    si.hStdInput  = GetStdHandle (STD_INPUT_HANDLE);
    si.hStdOutput = GetStdHandle (STD_OUTPUT_HANDLE);
    si.hStdError  = GetStdHandle (STD_ERROR_HANDLE);

    bRet = CreateProcess (NULL, argv[1],
                     NULL, NULL,
                     TRUE, CREATE_NEW_PROCESS_GROUP,
                     NULL, NULL,
                     &si, &pi
                     );

    if (bRet)
    {
      HANDLE handles[2];
      handles[0] = hCtrlBreakEvent;
      handles[1] = pi.hProcess;
      if(WaitForMultipleObjects(2, handles, FALSE, INFINITE) == WAIT_OBJECT_0)
      {
        SetLastError(0);
        printf("\n\nCONSPAWN:Ctrl-Break event requested !!! Terminating child processes ...\n\n");
        if(!GenerateConsoleCtrlEvent(CTRL_BREAK_EVENT, pi.dwProcessId))
          printf("\nCONSPAWN: Terminating problems: %d\n",GetLastError());
      }

      GetExitCodeProcess(pi.hProcess,(LPDWORD)&ExitCode);
      CloseHandle (pi.hProcess);
      CloseHandle (pi.hThread);
    }

    if(ExitCode == -1)
	    printf("CONSPAWN: Error executing command \"%s\".\n",argv[1]);

    CloseHandle(hCtrlBreakEvent);
	return ExitCode;
}
