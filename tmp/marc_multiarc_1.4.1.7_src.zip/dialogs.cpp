//#include "dialogs2.h" // Replace to "dialogs.h" after debug/refactoring
#include "dialogs.h" 
#include "ArchiverManager.h"

#include "utils.h"
#include "resource.h"
#include <string>
#include "multiarc.h"

//#include "stdafx.h" 


string HlpNameStr = "multiarc.hlp";

const char *LangFileAuthoringSection = "Authoring";
const char *LangFileAuthorIdent ="Author";
const char *LangFileCopyRigthIdent ="CopyRight";
const char *LangFileVersionIdent = "Version";
const char *LangFileDateEditIdent = "DateEdit";
const char *LangFileLicenseIdent = "License";
const char *LangFileOtherInfoIdent = "OtherInfo";
const char *LangFileContactInfoIdent = "ContactInfo";

enum enAuthorLangParam{
  alpAuthor      =1,
  alpCopyRigth   =2,
  alpLisence     =3,
  alpContactInfo =4,
  alpOtherInfo   =5
};

#define INI_KEY_SPARAM_HISTORY_MASK "AskHistory%d"


// Constants used for access to language strings 
const K_Lang_Button_OK     = 1;
const K_Lang_Button_Cancel = 2;
//const K_Lang_Warning_String =3; //moved to Multiarc.h
const K_Lang_Configure_Caption =7;

const K_Lang_Tabs_About         = 100;
const K_Lang_Tabs_About_Idea    = 101;
const K_Lang_Tabs_About_Version = 102;
// Addons page
const K_Lang_Tabs_Addons                   = 200;
const K_Lang_Tabs_Addons_Type              = 201;
const K_Lang_Tabs_Addons_No_Description    = 202;
const K_Lang_Tabs_Addons_NotSet            = 203;
const K_Lang_Tabs_Addons_Path              = 204;
const K_Lang_Tabs_Addons_Status            = 205;
const K_Lang_Tabs_Addons_Change            = 206;
const K_Lang_Tabs_Addons_ArchivRegister    = 207;
const K_Lang_Tabs_Addons_ArchivNotRegister = 208;
const K_Lang_Tabs_Addons_PathToArchiver    = 209;
const K_Lang_Tabs_Addons_FileType_ExecName = 210;
const K_Lang_Tabs_Addons_FileType_INI      = 211;
const K_Lang_Tabs_Addons_S_Handling        = 212;
const K_Lang_Tabs_Addons_When_Ask          = 213;
const K_Lang_Tabs_Addons_S_Never           = 214;
const K_Lang_Tabs_Addons_S_NEXT            = 215;
const K_Lang_Tabs_Addons_S_Always          = 216;
const K_Lang_Tabs_Addons_Exclude_List      = 217;
const K_Lang_Tabs_Addons_CurrentINI        = 218;
const K_Lang_Tabs_Addons_PathToTCIni       = 219;
const K_Lang_Tabs_Addons_FileType_AnyName  = 220;
const K_Lang_Tabs_Addons_AbandonChanges    = 221;
const K_Lang_Tabs_Addons_FinishConfigure   = 222;
const K_Lang_Tabs_Addons_ErrorShellCommand = 223;
const K_Lang_Tabs_Addons_ImportAddon       = 224;
const K_Lang_Tabs_Addons_PathToAddon       = 225;
const K_Lang_Tabs_Addons_FileType_Addon    = 226;
const K_Lang_Tabs_Addons_OpenIniFailed     = 227;
const K_Lang_Tabs_Addons_SaveBeforeEdit    = 228;
const K_Lang_Tabs_Addons_StartEdit         = 229;
const K_Lang_Tabs_Addons_RemoveType        = 230;
const K_Lang_Tabs_Addons_RemoveAddon       = 231;
const K_Lang_Tabs_Addons_Warning           = K_Lang_Warning_String;//232;
const K_Lang_Tabs_Addons_EditMultiarc      = 233;

// Settings page
const K_Lang_Tabs_Settings =300;
const K_Lang_Tabs_Settings_Caption =K_Lang_Tabs_Settings+ 0;
const K_Lang_Tabs_Settings_ShowConsole   = K_Lang_Tabs_Settings+ 1;
const K_Lang_Tabs_Settings_XLIST_CONSOLE = K_Lang_Tabs_Settings+ 2;
const K_Lang_Tabs_Settings_TRAY          = K_Lang_Tabs_Settings+ 3;
const K_Lang_Tabs_Settings_AUTOCLOSE     = K_Lang_Tabs_Settings+ 4;
const K_Lang_Tabs_Settings_DELAY         = K_Lang_Tabs_Settings+ 5;
const K_Lang_Tabs_Settings_HEIGHT        = K_Lang_Tabs_Settings+ 6;
const K_Lang_Tabs_Settings_CMode_Never   = K_Lang_Tabs_Settings+ 7;
const K_Lang_Tabs_Settings_CMode_If_Def_C= K_Lang_Tabs_Settings+ 8;
const K_Lang_Tabs_Settings_CMode_Always  = K_Lang_Tabs_Settings+ 9;


// Language Page
const K_Lang_Tabs_Language =400;
const K_Lang_Tabs_Language_Caption        = K_Lang_Tabs_Language + 0;
const K_Lang_Tabs_Language_LABEL_LANGUAGE = K_Lang_Tabs_Language + 1;
const K_Lang_Tabs_Language_LABEL_VERSION  = K_Lang_Tabs_Language + 2;
const K_Lang_Tabs_Language_LABEL_LASTEDIT = K_Lang_Tabs_Language + 3;
const K_Lang_Tabs_Language_LABEL_PARAMETERS = K_Lang_Tabs_Language + 4;
const K_Lang_Tabs_Language_LABEL_VALUE    = K_Lang_Tabs_Language + 5;
const K_Lang_Tabs_Language_GROUP_FILEINFO = K_Lang_Tabs_Language + 6;
const K_Lang_Tabs_Language_LangNotSet     = K_Lang_Tabs_Language + 7; 

const K_Lang_Tabs_Language_Authors        = K_Lang_Tabs_Language + 8; 
const K_Lang_Tabs_Language_Copyrigth      = K_Lang_Tabs_Language + 9; 
const K_Lang_Tabs_Language_Licence        = K_Lang_Tabs_Language + 10; 
const K_Lang_Tabs_Language_OtherInfo      = K_Lang_Tabs_Language + 11; 
const K_Lang_Tabs_Language_ContactInfo    = K_Lang_Tabs_Language + 12; 


//Capabilities page
const K_Lang_Capabilities_Caption         = 600;
const K_Lang_Capabilities_Extension       = 601;
const K_Lang_Capabilities_CAN_CREATE      = 602;
const K_Lang_Capabilities_CAN_MODIFY      = 603;
const K_Lang_Capabilities_MULTI_FILES     = 604;
const K_Lang_Capabilities_DETECT_TYPE     = 605;
const K_Lang_Capabilities_CAN_DELETE      = 606;
const K_Lang_Capabilities_SUPPORTS_SEARCH = 607;
const K_Lang_Capabilities_HIDE_ICON       = 608;
const K_Lang_Capabilities_ACTIVE          = 609;
//Wait page
const K_Lang_Wait_Caption           = 700;
const K_Lang_Wait_Message           = 701;
const K_Lang_Wait_Close             = 702;
const K_Lang_Wait_Terminale_Message = 703;
const K_Lang_Wait_Terminate_Caption = 704;
// AskType Page
const K_Lang_AskArcType =800;
const K_Lang_AskArcType_Caption   = K_Lang_AskArcType + 0;
const K_Lang_AskArcType_Info_Text = K_Lang_AskArcType + 1;
// SParameter Page
const K_Lang_Sparameter = 900;
const K_Lang_Sparameter_Info_Text         = K_Lang_Sparameter + 1;
const K_Lang_Sparameter_ActionAdd_Text    = K_Lang_Sparameter + 2;
const K_Lang_Sparameter_ActionDelete_Text = K_Lang_Sparameter + 3;
const K_Lang_Sparameter_ActionMove_Text   = K_Lang_Sparameter + 4;
const K_Lang_Sparameter_ActionTest_Text   = K_Lang_Sparameter + 5;

//*****************************************************
// Dialog  for get choice from user
//*****************************************************
class ArcTypePage : public SinglePage
{
  HWND m_hwndCombo;
  const char *m_ext;
protected:
  vector<CArchiveDescription *> m_pads;
  BOOL OnInitDialog(HWND hwndFocus, LPARAM lParam);
  BOOL OnOK();
  BOOL OnCancel();
  void SetLangCaptions();
  virtual BOOL OnHelp(HELPINFO *lphi);

public:
  ArcTypePage(const char *ext, vector<CArchiveDescription *> pads); 
  CArchiveDescription *m_pad;
  int Pad_Idx;
};

//***********************************************************
// Dialog For Ask User for %S Param
//***********************************************************

class SParamPage : public SinglePage
{
  CArchiveDescription *m_pad;
  int m_nAskHistorySize;

  HWND m_hwndCombo;
  string GetActionText(int idx);
  void LoadHistory();
  void SaveHistory();


protected:

  virtual BOOL OnOK();
  virtual BOOL OnCancel();

  virtual BOOL OnInitDialog(HWND hwndFocus, LPARAM lParam);
  virtual BOOL OnHelp(HELPINFO *lphi);
  virtual void SetLangCaptions();
public:
  SParamPage(HWND hParentHwnd, CArchiveDescription *pad);
  int m_idx;  
  int m_nAskForParamsCount;
  string m_strAddParam;
};



//***********************************************************
// ConfigDialog Methods 
//***********************************************************

//***********************************************************
ConfigDialog::ConfigDialog (HWND ParentHandle)
{
  m_hParentHwnd = ParentHandle;
  CreateConfigPages(); //Create Page object to Configure 
};
//***********************************************************
void ConfigDialog::BuildHelpFileName()
{
  char szFullPath[MAX_PATH],
       szDrive[_MAX_DRIVE],
       szPath[MAX_PATH],
       szName[_MAX_FNAME],
       szExt[_MAX_EXT];
  GetPrivateProfileString("LanG", "HelpFile", "", szFullPath, MAX_PATH, theArcMan.LangSupport.GetPathToLangFile().c_str());
  _splitpath(szFullPath,szDrive,szPath,szName,szExt);
  if (!strcmp(szName, "") )
  {
    strcpy(szName, "MultiArc");
    strcpy(szExt, ".hlp");
  }
  if (!strcmp(szDrive, "")) 
  {
    //szFullPath = strcat(szName, szExt);
    //strcpy(cszHlpName, theArcMan.MADir());
    HlpNameStr = theArcMan.MADir();
    HlpNameStr += szName;
    HlpNameStr += szExt;
  }
  else 
  {
    HlpNameStr = szFullPath;
    return;
  }
}
//***********************************************************
void ConfigDialog::CreateConfigPages()
{
  m_apPages[pageAbout]    = new AboutPage();
  m_apPages[pageAbout]->SetParentHandle(m_hParentHwnd);
  m_apPages[pageAddons]   = new AddonsPage();
  m_apPages[pageAddons]->SetParentHandle(m_hParentHwnd);
  m_apPages[pageSettings] = new SettingsPage();
  m_apPages[pageSettings]->SetParentHandle(m_hParentHwnd);
  m_apPages[pageLanguage] = new LanguagePage();
  m_apPages[pageLanguage]->SetParentHandle(m_hParentHwnd);
#ifdef USE_ARCH_CONFIG
  m_apPages[pageArchiverConfig] = new CArchiverConfigPage();
  m_apPages[pageArchiverConfig]->SetParentHandle(m_hParentHwnd);
#endif

};
//***********************************************************
int ConfigDialog::Run()
{
  PROPSHEETPAGE psp[pagesCount];
  for (int i=0; i< pagesCount; i++)
    m_apPages[i]->FillPage(&psp[i]);
  PROPSHEETHEADER psh;
  int Result = TRUE;
  psh.dwSize = sizeof(PROPSHEETHEADER);
  psh.dwFlags = PSH_PROPSHEETPAGE  |PSH_HASHELP | PSH_NOAPPLYNOW ;
  psh.hwndParent = m_hParentHwnd;
  string tmpStr;
  tmpStr = theArcMan.LangSupport.Strings(K_Lang_Configure_Caption, "Configure MultiArc");
  psh.pszCaption = tmpStr.c_str();
  psh.nPages = sizeof(psp) / sizeof(PROPSHEETPAGE);
  psh.nStartPage = pageAddons;
  psh.ppsp = (LPCPROPSHEETPAGE) &psp;
  // Backup copy of MultiArc.ini 
  string TempFile;
  TempFile = theArcMan.MADir();
  TempFile += "ma.tmp";
  OutputDebugString(TempFile.c_str());
  CopyFile(theArcMan.IniFile(), TempFile.c_str(), FALSE);
  BuildHelpFileName();
  
  
  Result = (PropertySheet(&psh));
  // �������� ���������� �����������
  if (Result == 0)//IDCANCEL)
    {
//    MessageBox(GetFocus(), "�������� ������", "IDCANCEL", 0);
    CopyFile(TempFile.c_str(), theArcMan.IniFile(), FALSE);
    theArcMan.OnConfigFinished(false);
    }
  else if (Result == IDOK){
    //MessageBox(GetFocus(), "�������� ����������", "IDOK", 0);
    theArcMan.OnConfigFinished(true);
    }
  DeleteFile(TempFile.c_str());
  return Result;
};

//***********************************************************
// PropSheetPage Methods 
//***********************************************************

BOOL PropSheetPage::AddTool(HWND hWinToToolTip, LPCTSTR szText, RECT* pr, UINT nIDTool)
{
   LONG oldWndProc = SetWindowLong(hWinToToolTip, GWL_WNDPROC, (LONG)ToolTipWndProc);//(LONG) newWndProc);
   SetWindowLong(hWinToToolTip, GWL_USERDATA, oldWndProc);

   TOOLINFO ti;
   RECT     r = {0,0,0,0};

   ZeroMemory(&ti,sizeof(TOOLINFO));
   ti.cbSize = sizeof(TOOLINFO);
   ti.hwnd   = hWinToToolTip;
   if(!nIDTool)
    {
      ti.uFlags = TTF_IDISHWND;
      ti.uId    = (UINT)hWinToToolTip;
    }
    ti.hinst  = (HINSTANCE)theArcMan.Instance();// (HINSTANCE)GetModuleHandle(NULL);
    ti.uFlags = TTF_SUBCLASS | TTF_TRANSPARENT;
    ti.lpszText = (char *) szText ? (char *) szText : LPSTR_TEXTCALLBACK;
    if(!pr)
    {
        pr = &r;
        GetClientRect(hWinToToolTip, pr);
    }
    memcpy(&ti.rect, pr, sizeof(RECT));
    BOOL res = SendMessage(m_hToolTipWindow, TTM_ADDTOOL, 0, (LPARAM)&ti);
    return res;
};
//***********************************************************

HWND APIENTRY PropSheetPage::CreateToolTip()
{
  m_hToolTipWindow = CreateWindowEx(0, TOOLTIPS_CLASS, (LPSTR) NULL, TTS_ALWAYSTIP|TTS_NOPREFIX, 
                              0, 0, 0, 0, m_hwnd, (HMENU) NULL, theArcMan.Instance(), NULL);
  return m_hToolTipWindow;
}

//***********************************************************
BOOL CALLBACK PropSheetPage::DlgProc(HWND hwnd, UINT msg, WPARAM wParam, LPARAM lParam)
{
  PropSheetPage *pThis = (PropSheetPage *) GetWindowLong(hwnd, GWL_USERDATA);
  switch (msg)
  {
    case WM_INITDIALOG:
      { 
        PROPSHEETPAGE * psp;
        psp = (PROPSHEETPAGE *) lParam; 
        pThis = (PropSheetPage *) psp->lParam;
        SetWindowLong(hwnd, GWL_USERDATA, psp->lParam);
        pThis->m_hwnd = hwnd;
      } 
    default:
      if(pThis)
        return pThis->DlgProc(msg, wParam, lParam);
  } //switch
  return FALSE;
};
//***********************************************************
BOOL PropSheetPage::DlgProc(WORD msg, WPARAM wParam, LPARAM lParam)
{
  switch (msg)
  {
    case WM_COMMAND: return OnCommand((int)(LOWORD(wParam)), (HWND)(lParam), (UINT)HIWORD(wParam));
    case WM_CTLCOLORSTATIC: return (BOOL)OnCtlColor(WM_CTLCOLORSTATIC, (HDC)(wParam), (HWND)(lParam));
    case WM_INITDIALOG: return OnInitDialog((HWND)(wParam), lParam);
    case WM_NOTIFY: return OnNotify((int)(wParam), (NMHDR FAR*)(lParam));
//    case WM_TIMER: return OnTimer((UINT)(wParam));
    case WM_HELP: return OnHelp((HELPINFO *)lParam);
    default:
      break;
  }
  return 0;
};
//***********************************************************
void PropSheetPage::FillPage(PROPSHEETPAGE* psp) 
{
  psp->dwSize = sizeof(PROPSHEETPAGE);
  psp->dwFlags = PSP_USETITLE | PSP_HASHELP;
  psp->pszIcon = NULL;
  psp->lParam = (LPARAM) this;
  psp->hInstance = theArcMan.Instance();
  psp->pszTemplate = m_lpTemplateName; 
  psp->pszTitle = m_Title.c_str();
  psp->pfnDlgProc = DlgProc; 
};
//***********************************************************
BOOL PropSheetPage::OnCommand( int id, HWND hwndCtl, UINT nCode)
{
//  switch(id)
  {
//  case IDHELP: return OnHelp();
  }
  return FALSE;
};
//***********************************************************
HBRUSH PropSheetPage::OnCtlColor(UINT msg, HDC hdc, HWND hwndChild)
{
  return (HBRUSH)DefWindowProc(m_hwnd, msg, (WPARAM)(HDC)(hdc), (LPARAM)(HWND)(hwndChild));
};
//***********************************************************
BOOL PropSheetPage::OnHelp(HELPINFO *lphi )
{
  BOOL bRet = FALSE;

  if(!lphi) // we are initiated from IDHELP button ...
  {
    WinHelp(m_hwnd, HlpNameStr.c_str(), HELP_CONTENTS, m_PageHelpTopicID);
  }
  else
    if(lphi->iContextType == HELPINFO_WINDOW)
    {
/*      switch(lphi->iCtrlId)
      {
//      case IDOK: lphi->iCtrlId = IDC_HLP_OK; break;
      case IDCANCEL: lphi->iCtrlId = IDC_HLP_CANCEL; break;
      case IDHELP: lphi->iCtrlId = IDC_HLP_HELP; break;
      }
*/
      WinHelp(m_hwnd, HlpNameStr.c_str(), HELP_CONTEXTPOPUP, lphi->iCtrlId);
    }

  return bRet;
}
//************************************************************
BOOL PropSheetPage::OnInitDialog(HWND hwndFocus, LPARAM lParam)
{
  m_PageHelpTopicID =0;
  InitCommonControls();
  SetLangCaptions();
  //m_hToolTipWindow=  CreateToolTip(m_hwnd);
  CreateToolTip();
  return TRUE;
};
//***********************************************************
BOOL PropSheetPage::OnNotify( int id, NMHDR * lpNMHdr)
{ 
  switch (lpNMHdr->code)
  {
    case PSN_APPLY: 
    { 
     //MessageBox(GetFocus(), "���������� (PSN_APPLY)", "PropSheetPage::OnNotify", 0); 
     return OnApply(id, lpNMHdr);
     break; //���������� ����������� ������
    }
    case PSN_HELP: // ��������� ������
    { 
      WinHelp(lpNMHdr->hwndFrom,HlpNameStr.c_str(), HELP_CONTEXT,  m_PageHelpTopicID);
      break;
    }
    case PSN_QUERYCANCEL: // ������ "������", ���� ����������� �������� ������
    {
      BOOL Result = OnCanCancel();
      SetWindowLong(m_hwnd, DWL_MSGRESULT, !Result);
      return Result;
    }
    case PSN_RESET: // ������ "������", ������������ ��
    {
//      MessageBox(GetFocus(), "PSN_RESET", "PropSheetPage::OnNotify", 0);      
      break;
    }
  } // switch
  return TRUE;
};
//***********************************************************
LRESULT CALLBACK PropSheetPage::ToolTipWndProc(HWND hWnd, UINT msg, WPARAM wParam, LPARAM lParam)
{
    switch(msg)
    {
    case WM_NOTIFY:
        {
            HWND hwndParent = GetParent(hWnd);
            if(hwndParent)
                SendMessage(hwndParent, msg, wParam, lParam);
            else
                return TRUE;
        }
        break;
    }
    return CallWindowProc((WNDPROC)GetWindowLong(hWnd, GWL_USERDATA), 
                                hWnd, msg, wParam, lParam);
};

//***********************************************************
void APIENTRY PropSheetPage::UpdateTipText(HWND hWnd, LPCTSTR lpszText)
{
  TOOLINFO ti;
  ZeroMemory(&ti,sizeof(TOOLINFO));
  ti.cbSize = sizeof(TOOLINFO);
  ti.hwnd   = hWnd;
  ti.uFlags = TTF_IDISHWND;
  ti.uId    = (UINT)hWnd;
  ti.lpszText = lpszText ? (LPTSTR)lpszText : LPSTR_TEXTCALLBACK;
  SendMessage(m_hToolTipWindow, TTM_UPDATETIPTEXT, 0, (LPARAM)&ti);
};
//***********************************************************
//***********************************************************
// AboutPage Methods 
//***********************************************************

//***********************************************************
AboutPage::AboutPage()
{
  m_lpTemplateName ="PAGE_ABOUT";
  m_Title = (LPSTR) theArcMan.LangSupport.Strings(K_Lang_Tabs_About, "About").c_str();
  m_hFontBold = NULL;
  m_hFontURL  = NULL;
  m_hBrush    = NULL;
  m_hCursor   = NULL;
};
//***********************************************************
AboutPage::~AboutPage()
{
  if(m_hFontBold) DeleteFont(m_hFontBold);
  if(m_hFontURL)  DeleteFont(m_hFontURL);
  if(m_hBrush)    DeleteBrush(m_hBrush);
  if(m_hCursor)   DestroyCursor(m_hCursor);
}
//***********************************************************
void AboutPage::FillPage(PROPSHEETPAGE* psp)
{
  PropSheetPage::FillPage(psp);
  psp->dwFlags = psp->dwFlags ^ PSP_HASHELP ;
};
//************************************************************
BOOL AboutPage::OnCommand( int id, HWND hwndCtl, UINT nCode)
{
  if(nCode == STN_CLICKED)
  {
    char str[255];
    switch(id)
    {
      case IDC_STATIC_MAIL:
      case IDC_STATIC_MAIL2:
        {
          GetWindowText(hwndCtl, str, 255);
          string tmpStr;
          tmpStr = str;
          string::size_type Pos;
          // clear antispam 
          Pos = tmpStr.find("(dog)");
          if (Pos != string::npos) 
          {
            tmpStr.replace(Pos, strlen("(dog)"), "@");
          }
          Pos = tmpStr.find("(");
          if  (Pos != string::npos) tmpStr.erase(Pos-1 , 100);
          tmpStr+= "?Subject=\"[MultiArc] ";
          GetWCXVersion(str);
          tmpStr+= str;
          tmpStr+= "\"";
          strcpy(str, tmpStr.c_str()); 
          break;
        } 
      case IDC_STATIC_URL:
        {
          GetWindowText(hwndCtl, str, 255);
          break;
        }
      default:
        return PropSheetPage::OnCommand(id, hwndCtl, nCode); 
    } //switch
    ShellExecute(m_hwnd, "open", str, 0, 0, SW_SHOW);
  }
  return PropSheetPage::OnCommand(id, hwndCtl, nCode);
};
//************************************************************
HBRUSH AboutPage::OnCtlColor(UINT msg, HDC hdc, HWND hwndChild)
{
  switch(GetDlgCtrlID(hwndChild))
  {
  case IDC_STATIC_MAIL :
  case IDC_STATIC_MAIL2:
  case IDC_STATIC_URL:
//	ULONG bkColor;   
//	bkColor = GetBkColor(hdc
//    SetBkColor(hdc, GetSysColor(COLOR_BTNFACE));
//    SetBkMode(hdc, TRANSPARENT);

    SetBkMode(hdc, OPAQUE);

    SetTextColor(hdc, RGB(0,0,255));
    return m_hBrush;
  }
  return PropSheetPage::OnCtlColor(msg, hdc, hwndChild);
};
//***********************************************************
BOOL AboutPage::OnInitDialog(HWND hwndFocus, LPARAM lParam)
{
  if (!PropSheetPage::OnInitDialog(hwndFocus, lParam)) return FALSE;
  m_PageHelpTopicID = 0;
  HFONT hFont = GetDlgItemFont(m_hwnd, IDC_STATIC_NAME);

  m_hBrush = CreateSolidBrush(GetSysColor(COLOR_BTNFACE));
  m_hCursor = LoadCursor(theArcMan.Instance(), MAKEINTRESOURCE(IDC_CURSOR));

  LOGFONT lf;
  GetObject(hFont,sizeof(LOGFONT),&lf);
  lf.lfWeight=FW_BOLD;
  m_hFontBold=CreateFontIndirect(&lf);
  lf.lfWeight=FW_NORMAL;
  lf.lfUnderline=TRUE;
  m_hFontURL=CreateFontIndirect(&lf);

  SetDlgItemFont(m_hwnd, IDC_STATIC_NAME,    m_hFontBold, 0);
  SetDlgItemFont(m_hwnd, IDC_STATIC_VERSION, m_hFontBold, 0);  

  SetDlgItemFont(m_hwnd, IDC_STATIC_MAIL,    m_hFontURL,  0);
  SetDlgItemFont(m_hwnd, IDC_STATIC_MAIL2,   m_hFontURL,  0);
  SetDlgItemFont(m_hwnd, IDC_STATIC_URL,     m_hFontURL,  0);
  
  SetClassLong(GetDlgItem(IDC_STATIC_MAIL) ,GCL_HCURSOR,(LPARAM)m_hCursor);
  SetClassLong(GetDlgItem(IDC_STATIC_MAIL2),GCL_HCURSOR,(LPARAM)m_hCursor);
  SetClassLong(GetDlgItem(IDC_STATIC_URL)  ,GCL_HCURSOR,(LPARAM)m_hCursor);

  // AddToolTip(IDC_STATIC_MAIL);
  // AddToolTip(IDC_STATIC_URL);

  return TRUE;
};
//***********************************************************
void AboutPage::SetLangCaptions()
{
  string tmpStr;
  {
    tmpStr = theArcMan.LangSupport.Strings(K_Lang_Tabs_About_Version,"Version:");
    tmpStr += " " ;
    char verStr[40];
    GetWCXVersion(verStr);
    tmpStr += string(verStr,4, string::npos);
    SetDlgItemText(IDC_STATIC_VERSION, tmpStr.c_str());
  }
  // thanks
  int iLen = SendMessage(GetDlgItem(IDC_STATIC_THANKS), WM_GETTEXTLENGTH, 0, 0);
  char * DefThanks = new char [iLen +1];
  GetDlgItemText(IDC_STATIC_THANKS, DefThanks,iLen +1);
  tmpStr = theArcMan.LangSupport.Strings(K_Lang_Tabs_About_Idea,DefThanks);
  SetDlgItemText(IDC_STATIC_THANKS, tmpStr.c_str());
  delete [] DefThanks;
};

//***********************************************************
// AddonsPage Methods 
//***********************************************************

//***********************************************************
AddonsPage::AddonsPage()
{;
  m_lpTemplateName ="PAGE_ADDONS";
  m_Title = theArcMan.LangSupport.Strings(K_Lang_Tabs_Addons, "Addons" ).c_str();
  m_padCurSel = NULL;
};
//***********************************************************
BOOL AddonsPage::CapabilitiesButtonCommand(int nCode)
{
  if(nCode == BN_CLICKED)
  {
    CapabilitiesPage * Page = new CapabilitiesPage();
    Page->SetArcDesctiption(m_padCurSel);
    PageDialog dlg(m_hwnd, Page);
    dlg.Run();
    TypeComboCommand(CBN_SELCHANGE);
    return FALSE;
  }
  return TRUE;
}
//************************************************************
BOOL AddonsPage::EditIniButtonCommand(int nCode)
{
  if(theArcMan.HasChanges())
    if(MessageBox(GetFocus(), 
       theArcMan.LangSupport.Strings(K_Lang_Tabs_Addons_SaveBeforeEdit, 
                              "You have made some changes in configuration. "
                              "To avoid problems during manual editing of "
                              "multiarc.ini you have to save this changes."
                              "Save changes now?" ).c_str(), 

      theArcMan.LangSupport.Strings(K_Lang_Tabs_Addons_StartEdit, "Going to edit multiarc.ini" ).c_str(), MB_ICONQUESTION|MB_YESNO) == IDYES)
      theArcMan.SaveChanges();
    else
      return FALSE;

  char buf[MAX_PATH];
  buf[0] = 0;
  {
    char buf2[MAX_PATH];
    buf2[0] = 0;
    GetPrivateProfileString("Configuration", "Editor", "", buf2, MAX_PATH, theArcMan.WCmdIniFile());
    ExpandEnvironmentStrings(buf2, buf, MAX_PATH); 
  }
  bool bHasEditor = strlen(buf) > 0;
  const char *verb  = "open";
  const char *file  = bHasEditor ?  buf : theArcMan.IniFile();
  const char *param = bHasEditor ?  theArcMan.IniFile() : NULL;

    
  SHELLEXECUTEINFO sei;
  memset(&sei, 0, sizeof(SHELLEXECUTEINFO));
  sei.cbSize = sizeof(SHELLEXECUTEINFO);
  sei.fMask = SEE_MASK_NOCLOSEPROCESS;
  sei.hwnd = m_hwnd;
  sei.lpVerb = verb;
  sei.lpFile = file;
  sei.lpDirectory = theArcMan.MADir();
  sei.lpParameters = param;
  sei.nShow = SW_SHOW;
  if(ShellExecuteEx(&sei))
  {
    WaitPage * tmpPage = new WaitPage();
    tmpPage->SetProcessHandle(sei.hProcess);
    PageDialog dlg(m_hwnd, tmpPage);
    //WaitDialog dlg(m_hwnd, sei.hProcess);
    if(dlg.Run() == IDOK)
    {
      theArcMan.ReLoadArcDescriptions();
      m_padCurSel = NULL;
      InitDescriptions(); // reload types ...
      TypeComboCommand(CBN_SELCHANGE);
    }
  }
  else
    MessageBox(GetFocus(), 
       theArcMan.LangSupport.Strings(K_Lang_Tabs_Addons_OpenIniFailed,
          "Shell command \"open\" for file type \"inifile\" failed."
          " Check settings in registry").c_str(),
       theArcMan.LangSupport.Strings(K_Lang_Tabs_Addons_ErrorShellCommand, 
          "Error running shell command").c_str(), MB_ICONSTOP);
  return TRUE;
}
//************************************************************

BOOL AddonsPage::GetFileName(string Title, string Filter, 
             DWORD Flags, string InitialDir, string &FileName, BOOL IsReturnExpand)
{
  char * buf = new char[Filter.length() +2];
  string::size_type sPos, lastPos, Count;
  lastPos = -1;
  Count = sPos = 0;
  do
   {
    sPos = Filter.find("|", lastPos +1); 
    Count = sPos - lastPos;
    if (sPos == string::npos) 
      Count= Filter.length() - lastPos;
    strncpy(&buf[lastPos+1],&Filter[lastPos+1], Count); 
    buf[sPos] = 0;
    lastPos = sPos;
   }while (sPos != string::npos);
  buf[Filter.length()+1] =0;
  buf[Filter.length()+2] =0;

  char fname[MAX_PATH];
  ExpandEnvironmentStrings(FileName.c_str(),fname, MAX_PATH);
  //strcpy(fname, FileName.c_str());
  OPENFILENAME ofn;
  memset(&ofn, 0, sizeof(OPENFILENAME));
  ofn.lStructSize = sizeof(OPENFILENAME);
  ofn.hwndOwner = m_hwnd; 
  ofn.lpstrFile = fname;
  ofn.nMaxFile = MAX_PATH;
  ofn.lpstrFilter = buf; 
  ofn.lpstrTitle = Title.c_str();
  ofn.Flags = Flags;
  ofn.lpstrInitialDir =InitialDir.c_str();
  BOOL bRet = GetOpenFileName(&ofn);
 
  if (bRet) 
  {
    // ����� ����������� ���� ������ ����, 
    // ���� ���� � ����������� ���������
    // ���� � ����������� ���������, ����� ����� �������� � 
    // ������� ���������� ����� ����������
    
    if (IsReturnExpand)
    { 
       FileName = ofn.lpstrFile;
    }
    else
    {
      char buf[MAX_PATH]; 
      ExpandEnvironmentStrings(FileName.c_str(), buf, MAX_PATH);
      if (stricmp(buf, ofn.lpstrFile))
      {
        FileName = ofn.lpstrFile;
        
        ExpandEnvironmentStrings("%COMMANDER_PATH%", fname, MAX_PATH);
        sPos = FileName.find(fname);
        if (sPos == 0)  //��������� � ��������� ������
        {
          FileName.replace(0, strlen(fname),"%COMMANDER_PATH%");
        }
      }
    }
  }
  return bRet;
}
//********************************************************************
BOOL AddonsPage::ImportAddonButtonCommand(int nCode)
{
  if(nCode == BN_CLICKED)
  {
    // build filter string
    string s;
    s = theArcMan.LangSupport.Strings(K_Lang_Tabs_Addons_FileType_Addon, "MultiArc Addon Files(*.addon)|*.addon") + "|"; 
    s += theArcMan.LangSupport.Strings(K_Lang_Tabs_Addons_FileType_AnyName, "All Files(*.*)|*.*");

    string FileName;
    if (GetFileName(theArcMan.LangSupport.Strings(K_Lang_Tabs_Addons_PathToAddon, "Look for addon to import"), 
        s.c_str(), 
        OFN_FILEMUSTEXIST|OFN_PATHMUSTEXIST, theArcMan.MADir(), 
        FileName))
    {
       if(theArcMan.ImportAddon(FileName.c_str()))
       {
         m_padCurSel = NULL;
         m_curTypeName = theArcMan.Vector().back().String(TYPENAME_IDX);
         InitDescriptions(); // reload types ...
         TypeComboCommand(CBN_SELCHANGE);
         CapabilitiesButtonCommand(BN_CLICKED);
         EnableWindow(GetDlgItem(IDC_CHANGE_WINCMD_INI_BUTTON), FALSE);
       }
    }
  }  
  return TRUE;
}
//************************************************************ 
void AddonsPage::InitDescriptions()
{
  m_hwndTypes = GetDlgItem(IDC_COMBO_TYPE);
  ComboBox_ResetContent(m_hwndTypes);
  int iUseTypeName = m_curTypeName.length();
  int idxSel = 0;
  const ArcDescrVector &v = theArcMan.Vector();
  for(int i = 0; i < v.size(); i++)
  {
    if(v[i].String(TYPENAME_IDX))
    {
      int idx = ComboBox_AddString(m_hwndTypes, v[i].String(TYPENAME_IDX));
      ComboBox_SetItemData(m_hwndTypes, idx, i);
      if( (m_padCurSel && 
           !stricmp(m_padCurSel->String(TYPENAME_IDX), v[i].String(TYPENAME_IDX))) ||
             (iUseTypeName && !stricmp(m_curTypeName.c_str(), v[i].String(TYPENAME_IDX))))
        idxSel = idx;
    }
  }
  ComboBox_SetCurSel(m_hwndTypes, idxSel);
};
//***********************************************************
void AddonsPage::InitSParams()
{
  m_hwndSMode = GetDlgItem(IDC_COMBO_SMODE);
  m_hwndCheckXList = GetDlgItem(IDC_CHECK_XLIST);
  m_hwndCheckSParam = GetDlgItem(IDC_CHECK_SPARAM);

  struct s_mode
  {
    int Lang_StringID;
    char * DefStr;
    eSParamMode espm;
  } modes[]={
    {K_Lang_Tabs_Addons_S_Never, "Never", eSParamNone},
    {K_Lang_Tabs_Addons_S_NEXT, "For next command", eSParamNext},
    {K_Lang_Tabs_Addons_S_Always,"Always", eSParamAlways}
  };

  for(int i=0; i < sizeof(modes)/sizeof(modes[0]); i++)
  {
    ComboBox_InsertString(m_hwndSMode, i, theArcMan.LangSupport.Strings(modes[i].Lang_StringID,modes[i].DefStr).c_str());
    ComboBox_SetItemData(m_hwndSMode,  i, modes[i].espm);
  }
  ComboBox_SetCurSel(m_hwndSMode, 0);
}
//***********************************************************
BOOL AddonsPage::LoadNewWincmdIniButtonCommand(int nCode)
{
  if(nCode == BN_CLICKED)
  {
    string FileName;
    // build filter string
    string s;
    s = theArcMan.LangSupport.Strings(K_Lang_Tabs_Addons_FileType_INI, "Configuration Files(*.ini)|*.ini") +"|"; 
    s += theArcMan.LangSupport.Strings(K_Lang_Tabs_Addons_FileType_AnyName, "All Files(*.*)|*.*");

    if(GetFileName(theArcMan.LangSupport.Strings(K_Lang_Tabs_Addons_PathToTCIni, "Look for TC main configuration file"), 
       s.c_str(),
       OFN_FILEMUSTEXIST | OFN_PATHMUSTEXIST | OFN_HIDEREADONLY, 
        "", FileName))
    {
      theArcMan.SetWCmdIniFile(FileName);
      // Set caption 
      SetWindowText(GetDlgItem(IDC_STATIC_CURRENT_WINCMD_INI), theArcMan.WCmdIniFile());
      TypeComboCommand(CBN_SELCHANGE);
      UpdateTipText(GetDlgItem(IDC_STATIC_CURRENT_WINCMD_INI),theArcMan.WCmdIniFile());
    }
  }  
  return TRUE;
}
//********************************************************************
BOOL AddonsPage::OnApply(int id, NMHDR * lpNMHdr) 
{
//  if(!m_pageAddons.OnOK())
//    return FALSE;
//
//  if(!m_pageSettings.OnOK())
//    return FALSE;
//
//  theArcMan.OnConfigFinished(true);
//
//  return Dialog::OnOK();


//  MessageBox(GetFocus(), "���������� (PSN_APPLY)", "AddonsPage::OnApply", 0); 
  return TRUE;
};
//********************************************************************
BOOL AddonsPage::OnCanCancel()
{ 
  if(theArcMan.HasChanges() && 
    MessageBox(GetFocus(), 
      theArcMan.LangSupport.Strings(K_Lang_Tabs_Addons_AbandonChanges, "You have made some changes in configuration during this session. Abandon those changes?").c_str(), 
      theArcMan.LangSupport.Strings(K_Lang_Tabs_Addons_FinishConfigure, "Finishing MultiArc configuration").c_str(), 
       MB_ICONQUESTION|MB_OKCANCEL) == IDCANCEL)
    return FALSE;

  return PropSheetPage::OnCanCancel();
};
//********************************************************************
BOOL AddonsPage::OnCommand( int id, HWND hwndCtl, UINT nCode)
{
  switch(id)
  {
    case IDC_BUTTON_CAPABILITIES      : return CapabilitiesButtonCommand(nCode);
    case IDC_BUTTON_EDIT_INI          : return EditIniButtonCommand(nCode);  
    case IDC_BUTTON_IMPORT            : return ImportAddonButtonCommand(nCode);
    case IDC_BUTTON_REMOVE            : return RemoveAddonButtonCommand(nCode);
    case IDC_BUTTON_PATH              : return PathButtonCommand(nCode);
    case IDC_CHANGE_WINCMD_INI_BUTTON : return LoadNewWincmdIniButtonCommand(nCode);
    case IDC_COMBO_TYPE               : return TypeComboCommand(nCode);
    case IDC_CHECK_SPARAM             : return SParamCheckCommand(nCode);
    case IDC_COMBO_SMODE              : return SParamComboCommand(nCode);
    case IDC_CHECK_XLIST              : return SParamCheckXListCommand(nCode);
    case IDC_EDIT_PATH                : return PathEditCommand(nCode);
    default: break;
  }
  return PropSheetPage::OnCommand(id, hwndCtl, nCode);
};
//***********************************************************
BOOL CALLBACK AddonsPage::EnumControlsProc( HWND hwnd, LPARAM lParam )
{
  char buf[256];
  int iPrevIdx = 0;

  if(!lParam) return FALSE;

  if(GetClassName(hwnd, buf, sizeof(buf)))
    if(!strcmp(buf, "TComboBox"))
      if(ComboBox_GetText(hwnd, buf, sizeof(buf)))
        *(CArchiveDescription **)lParam = theArcMan.FindArchiveDescriptionForExt(buf, iPrevIdx);

  return TRUE;
}
//***********************************************************

BOOL AddonsPage::OnInitDialog(HWND hwndFocus, LPARAM lParam)
{  
  if(!PropSheetPage::OnInitDialog(hwndFocus, lParam)) return FALSE;
  // Get selection from TC config
  m_PageHelpTopicID = IDC_PAGE_ADDONS;
  EnumChildWindows(m_hParentHwnd, EnumControlsProc, (LPARAM)&m_padCurSel);
  m_hwndPath = GetDlgItem(IDC_EDIT_PATH);
  m_hwndStaticActive = GetDlgItem(IDC_STATIC_ACTIVE);

  InitDescriptions();
  InitSParams();
  TypeComboCommand(CBN_SELCHANGE);
  // Set path to Wincmd.ini 
  SetWindowText(GetDlgItem(IDC_STATIC_CURRENT_WINCMD_INI), theArcMan.WCmdIniFile());
//  AddTool1(m_hToolTipWindow, GetDlgItem(IDC_STATIC_CURRENT_WINCMD_INI), NULL, NULL, (char*) theArcMan.WCmdIniFile());
  AddTool(GetDlgItem(IDC_STATIC_CURRENT_WINCMD_INI), (char*) theArcMan.WCmdIniFile(), NULL, NULL);
  SendMessage(m_hToolTipWindow, TTM_ACTIVATE, TRUE, 0); //EnableToolTip
  // AddToolTip(GetDlgItem(IDC_STATIC_CURRENT_WINCMD_INI),NULL,0,theArcMan.WCmdIniFile());
  // EnableToolTip(TRUE); 

  return TRUE;
};
//***********************************************************
BOOL AddonsPage::PathButtonCommand(int nCode)
{
  if(nCode == BN_CLICKED)
  {
    string FileName;
    {
      char fname[MAX_PATH];
      Edit_GetText(m_hwndPath, fname, MAX_PATH);  
      FileName = fname;
    }
    // build filter string
    string s;
    s = theArcMan.LangSupport.Strings(K_Lang_Tabs_Addons_FileType_ExecName, "Executable Files(*.exe;*.cmd;*.bat;*.com)") + "|"; 
    s += theArcMan.LangSupport.Strings(K_Lang_Tabs_Addons_FileType_AnyName, "All Files(*.*)");
    
    if (GetFileName(
       theArcMan.LangSupport.Strings(K_Lang_Tabs_Addons_PathToArchiver, "Look for archiver utility"), 
       s.c_str(), OFN_FILEMUSTEXIST|OFN_PATHMUSTEXIST, "", FileName, FALSE))
    {
      Edit_SetText(m_hwndPath, FileName.c_str());
    }
  }
  return TRUE;
}
//************************************************************
BOOL AddonsPage::PathEditCommand(int nCode)
{
  if(nCode == EN_CHANGE && m_padCurSel)
  {
    char buf[MAX_PATH];
    Edit_GetText(m_hwndPath, buf, MAX_PATH);
    m_padCurSel->SetProgramPath(buf);
  }
  return TRUE;
}
//********************************************************************
BOOL AddonsPage::RemoveAddonButtonCommand(int nCode)
{
  if(nCode == BN_CLICKED)
  {
    if(MessageBox(GetFocus(), ExpandParam(theArcMan.LangSupport.Strings(K_Lang_Tabs_Addons_RemoveAddon, 
        "You are going to remove configuration information for \"%1!s!\" archive type. Are you sure?").c_str(), m_curTypeName.c_str()).c_str(),
         theArcMan.LangSupport.Strings(K_Lang_Tabs_Addons_Warning, WARNING_STR_CONST /*"Warning" */).c_str(), 
         MB_ICONWARNING|MB_YESNO) == IDYES)
    {
      if(theArcMan.RemoveAddon(m_curTypeName.c_str()))
      {
        m_padCurSel = NULL;
        m_curTypeName = theArcMan.Vector().back().String(TYPENAME_IDX);
        InitDescriptions(); // reload types ...
        TypeComboCommand(CBN_SELCHANGE);
      }
    }
  }  
  return TRUE;
}
//************************************************************
void AddonsPage::SetLangCaptions()
{
  char str[40];
  GetDlgItemText(IDC_STATIC_TYPE, str, 40);
  SetDlgItemText(IDC_STATIC_TYPE, theArcMan.LangSupport.Strings(K_Lang_Tabs_Addons_Type, str).c_str()) ;

  GetDlgItemText(IDC_LABEL_PATH, str, 40);
  SetDlgItemText(IDC_LABEL_PATH, theArcMan.LangSupport.Strings(K_Lang_Tabs_Addons_Path, str).c_str()) ;

  GetDlgItemText(IDC_LABEL_STATUS, str, 40);
  SetDlgItemText(IDC_LABEL_STATUS, theArcMan.LangSupport.Strings(K_Lang_Tabs_Addons_Status, str).c_str()) ;

  GetDlgItemText(IDC_BUTTON_CAPABILITIES, str, 40);
  SetDlgItemText(IDC_BUTTON_CAPABILITIES, theArcMan.LangSupport.Strings(K_Lang_Tabs_Addons_Change, str).c_str()) ;


  GetDlgItemText(IDC_STATIC_CURRENT_INI_CAPTION, str, 40);
  SetDlgItemText(IDC_STATIC_CURRENT_INI_CAPTION, theArcMan.LangSupport.Strings(K_Lang_Tabs_Addons_CurrentINI, str).c_str()) ;

  GetDlgItemText(IDC_BUTTON_IMPORT, str, 40);
  SetDlgItemText(IDC_BUTTON_IMPORT, theArcMan.LangSupport.Strings(K_Lang_Tabs_Addons_ImportAddon, str).c_str()) ;

  GetDlgItemText(IDC_BUTTON_REMOVE, str, 40);
  SetDlgItemText(IDC_BUTTON_REMOVE, theArcMan.LangSupport.Strings(K_Lang_Tabs_Addons_RemoveType, str).c_str()) ;

  GetDlgItemText(IDC_BUTTON_EDIT_INI, str, 40);
  SetDlgItemText(IDC_BUTTON_EDIT_INI, theArcMan.LangSupport.Strings(K_Lang_Tabs_Addons_EditMultiarc, str).c_str()) ;


  GetDlgItemText(IDC_CHECK_SPARAM, str, 40);
  SetDlgItemText(IDC_CHECK_SPARAM, theArcMan.LangSupport.Strings(K_Lang_Tabs_Addons_S_Handling, str).c_str()) ;

  GetDlgItemText(IDC_STATIC_ASK, str, 40);
  SetDlgItemText(IDC_STATIC_ASK, theArcMan.LangSupport.Strings(K_Lang_Tabs_Addons_When_Ask, str).c_str()) ;

  GetDlgItemText(IDC_CHECK_XLIST, str, 40);
  SetDlgItemText(IDC_CHECK_XLIST, theArcMan.LangSupport.Strings(K_Lang_Tabs_Addons_Exclude_List, str).c_str()) ;
};
//***********************************************************
BOOL AddonsPage::SParamCheckCommand(int nCode)
{ 
  if(nCode == BN_CLICKED) 
  {
    if(m_padCurSel)
    {
      if(m_padCurSel->IsRealEntry())
      {
        int SMode = eSParamNone;
        if(Button_GetCheck(m_hwndCheckSParam))
        {
          m_padCurSel->SetSParams(SMode, TRUE);
          Button_SetCheck(m_hwndCheckSParam, FALSE);
        }
        else
        {
          m_padCurSel->SetSParams(eSParamNext, TRUE);
          Button_SetCheck(m_hwndCheckSParam, TRUE);
        }
      }
    }
    TypeComboCommand(CBN_SELCHANGE);
  }
  return TRUE;
}
//************************************************************
BOOL AddonsPage::SParamCheckXListCommand(int nCode)
{
  if(nCode == BN_CLICKED) SParamHelper();
  return TRUE;
}
//************************************************************ 
BOOL AddonsPage::SParamComboCommand(int nCode)
{
  if(nCode == CBN_SELCHANGE) SParamHelper();
  return TRUE;
}
//************************************************************
void AddonsPage::SParamHelper()
{

  if(m_padCurSel)
  {
    int mode = ComboBox_GetItemData(m_hwndSMode, ComboBox_GetCurSel(m_hwndSMode));
    if(mode == CB_ERR) mode = 0;
    m_padCurSel->SetSParams((eSParamMode)mode, Button_GetCheck(m_hwndCheckXList));
  }
  TypeComboCommand(CBN_SELCHANGE);

}
//************************************************************
BOOL AddonsPage::TypeComboCommand(int nCode)
{

  if(nCode == CBN_SELCHANGE)
  {
    int idx = ComboBox_GetCurSel(m_hwndTypes);
    if(idx != -1)
    {   
      // retrieve current arc description ...
      int i = ComboBox_GetItemData(m_hwndTypes, idx);
      const ArcDescrVector &v = theArcMan.Vector();
      m_padCurSel = theArcMan.GetADbyId(i);
      if(m_padCurSel)
        m_curTypeName = m_padCurSel->String(TYPENAME_IDX);
       
      // set description label text ...
      LPCSTR lp = v[i].String(DESCRIPT_IDX);
      SetWindowText(GetDlgItem(IDC_STATIC_DESCRIPTION), lp ? lp : theArcMan.LangSupport.Strings(K_Lang_Tabs_Addons_No_Description, "No description available").c_str() );
        
      // set path edit text ...
      const BOOL bIsRealEntry = v[i].IsRealEntry();
      if(bIsRealEntry)
      {
        lp = v[i].String(ARCHIVER_IDX);
        SetWindowText(m_hwndPath, lp ? lp : theArcMan.LangSupport.Strings(K_Lang_Tabs_Addons_NotSet, "Not set").c_str() );
      }
      else
        SetWindowText(m_hwndPath, "");

      EnableWindow(m_hwndPath, bIsRealEntry);
      EnableWindow(GetDlgItem(IDC_BUTTON_PATH), bIsRealEntry);
      EnableWindow(GetDlgItem(IDC_LABEL_PATH), bIsRealEntry);
      EnableWindow(GetDlgItem(IDC_BUTTON_REMOVE), bIsRealEntry);
        
      // set status label text .. 
      string s =  theArcMan.LangSupport.Strings(K_Lang_Tabs_Addons_ArchivRegister, "Registered for") ;
      if(v[i].IsRegistered())
      {
        for(int j=0, k=0; j<v[i].ExtsCount(); j++)
        {
          if(v[i].IsExtActive(j))
          {
            if(!k++) s += " "; else s += ", "; 
            s += v[i].GetExt(j);
          }
        }
      }
      else
        s= theArcMan.LangSupport.Strings(K_Lang_Tabs_Addons_ArchivNotRegister, "Not registered");

      SetWindowText(m_hwndStaticActive, bIsRealEntry ? s.c_str() : "");
      EnableWindow(m_hwndStaticActive, bIsRealEntry);
      EnableWindow(GetDlgItem(IDC_LABEL_STATUS), bIsRealEntry);
      EnableWindow(GetDlgItem(IDC_BUTTON_CAPABILITIES), bIsRealEntry);

      // SParam combo - adjust items count ...
      int idxSMode = ComboBox_GetItemData(m_hwndSMode, 0);
      if(!bIsRealEntry && idxSMode != eSParamNone )  // for general settings - add "Never" item if not found...
      {
        ComboBox_InsertString(m_hwndSMode, 0, theArcMan.LangSupport.Strings(K_Lang_Tabs_Addons_S_Never,"Never").c_str());
        ComboBox_SetItemData (m_hwndSMode, 0, eSParamNone);
      }

      if(bIsRealEntry && idxSMode == eSParamNone)  // for "real" items - remove if exist ...
        ComboBox_DeleteString(m_hwndSMode, 0);
     
      // SParam combo - determine type ... 
      int SMode = v[i].GetSParam();
      BOOL bIsSParamValid = bIsRealEntry ? SMode != eSParamNone : TRUE;

      // SParam check - set state ...
      if(!bIsRealEntry)
        Button_SetCheck(m_hwndCheckSParam, BST_INDETERMINATE);
      else
        Button_SetCheck(m_hwndCheckSParam, (SMode == eSParamNone) ? FALSE : TRUE);

      // SParam combo - select required item 
      if(bIsSParamValid)
      {
        int sel = -1;
        int count = ComboBox_GetCount(m_hwndSMode);
        for(int i=0; i < count; i++)
          if(ComboBox_GetItemData(m_hwndSMode, i) == SMode)
            sel = i; 
          
        ComboBox_SetCurSel(m_hwndSMode, sel);
      }
      else
        ComboBox_SetCurSel(m_hwndSMode, -1);
     
      EnableWindow(m_hwndSMode, bIsSParamValid);
      EnableWindow(m_hwndCheckXList, (SMode != eSParamNone));
      Button_SetCheck(m_hwndCheckXList, (bIsSParamValid) ? v[i].SParamSkipLIST() : FALSE);

    }

  }
  return TRUE;
}
//***********************************************************

//***********************************************************
// SettingsPage Methods 
//***********************************************************

//***********************************************************
SettingsPage::SettingsPage()
{
  m_lpTemplateName ="PAGE_SETTINGS";
  m_Title = theArcMan.LangSupport.Strings(K_Lang_Tabs_Settings_Caption, "Settings").c_str();
};
//********************************************************************
BOOL SettingsPage::ChecksHelper(int nCode)
{
  if(nCode == BN_CLICKED)
    ModeComboCommand(CBN_SELCHANGE);
  return TRUE;
}
//********************************************************************
BOOL SettingsPage::DelayEditCommand(int nCode)
{
  if(nCode = EN_CHANGE && !m_bInitDialog)
    ModeComboCommand(CBN_SELCHANGE);
  return TRUE;
}
//********************************************************************
BOOL SettingsPage::LinesEditCommand(int nCode)
{
  if(nCode = EN_CHANGE && !m_bInitDialog)
    ModeComboCommand(CBN_SELCHANGE);
  return TRUE;
}
//********************************************************************
BOOL SettingsPage::ModeComboCommand(int nCode)
{

  if(CBN_SELCHANGE)
  {
    int d = ComboBox_GetItemData(m_hwndCMode, ComboBox_GetCurSel(m_hwndCMode));
    if(d != -1)
    {
      bool bUsed = (cmNever != (eConMode)d);
      EnableWindow(m_hwndCheckTray, bUsed);
      EnableWindow(m_hwndCheckAutoClose, bUsed);  
      EnableWindow(m_hwndCheckXList, bUsed);
      EnableWindow(m_hwndDelay, bUsed);
      EnableWindow(m_hwndLines, bUsed);
      EnableWindow(GetDlgItem(IDC_LABEL_DELAY), bUsed);
      EnableWindow(GetDlgItem(IDC_LABEL_SECONDS), bUsed);
      EnableWindow(GetDlgItem(IDC_LABEL_HEIGHT), bUsed);
      EnableWindow(GetDlgItem(IDC_LABEL_LINES), bUsed);

      theArcMan.SetCParams((eConMode)d, 
            Button_GetCheck(m_hwndCheckTray),
            Button_GetCheck(m_hwndCheckXList),
            Button_GetCheck(m_hwndCheckAutoClose),
            GetDlgItemInt(IDC_EDIT_DELAY, 0, TRUE),
            GetDlgItemInt(IDC_EDIT_LINES, 0, TRUE));
    }
  }
  return TRUE;
}
//********************************************************************
BOOL SettingsPage::OnCommand( int id, HWND hwndCtl, UINT nCode)
{
  switch(id)
  {
  case IDC_COMBO_CMODE: return ModeComboCommand(nCode);
  case IDC_CHECK_TRAY:
  case IDC_CHECK_AUTOCLOSE:
  case IDC_CHECK_XLIST_CONSOLE: return ChecksHelper(nCode);
  case IDC_EDIT_DELAY: return DelayEditCommand(nCode);
  case IDC_EDIT_LINES: return LinesEditCommand(nCode);
  default: break;
  }
  return PropSheetPage::OnCommand(id, hwndCtl, nCode);
}
//********************************************************************
BOOL SettingsPage::OnInitDialog(HWND hwndFocus, LPARAM lParam)
{
  if(!PropSheetPage::OnInitDialog(hwndFocus, lParam)) return FALSE;
  m_hwndCMode = GetDlgItem(IDC_COMBO_CMODE);
  m_hwndDelay = GetDlgItem(IDC_EDIT_DELAY);
  m_hwndLines = GetDlgItem(IDC_EDIT_LINES);
  m_hwndCheckTray  = GetDlgItem(IDC_CHECK_TRAY);
  m_hwndCheckXList = GetDlgItem(IDC_CHECK_XLIST_CONSOLE);
  m_hwndCheckAutoClose = GetDlgItem(IDC_CHECK_AUTOCLOSE);
  m_PageHelpTopicID = IDC_PAGE_SETTINGS;

  m_bInitDialog = true;

  int idxSel = 0;
  struct c_mode
  {
    int Lang_StringID;
    char * DefStr;
    eConMode ecm;
  } modes[]={
    {K_Lang_Tabs_Settings_CMode_Never, "never", cmNever },
    {K_Lang_Tabs_Settings_CMode_If_Def_C, "if defined (%C)", cmIfDef },
    {K_Lang_Tabs_Settings_CMode_Always,"always", cmAlways}
  };

  
  for(int i=0; i < sizeof(modes)/sizeof(modes[0]); i++)
  {
    ComboBox_InsertString(m_hwndCMode, i, theArcMan.LangSupport.Strings(modes[i].Lang_StringID, modes[i].DefStr).c_str());
    ComboBox_SetItemData (m_hwndCMode, i, modes[i].ecm);
    if(modes[i].ecm == theArcMan.CMode()) idxSel = i;
  }
  ComboBox_SetCurSel(m_hwndCMode, idxSel);

  Button_SetCheck(m_hwndCheckTray, theArcMan.CMinimize());
  Button_SetCheck(m_hwndCheckAutoClose, theArcMan.CAutoClose());
  Button_SetCheck(m_hwndCheckXList, theArcMan.CExclude());
  SetDlgItemInt(IDC_EDIT_DELAY, theArcMan.CDelay(), TRUE);

  if(theArcMan.CLines() > 0)
    SetDlgItemInt(IDC_EDIT_LINES, theArcMan.CLines(), TRUE);
  else
    SetWindowText(m_hwndLines, "");
  ModeComboCommand(CBN_SELCHANGE);
  m_bInitDialog = false;

  return TRUE;
}
//********************************************************************
void SettingsPage::SetLangCaptions()
{
  char str[40];
  GetDlgItemText(IDC_STATIC_SHOW_CONSOLE, str, 40);
  SetDlgItemText(IDC_STATIC_SHOW_CONSOLE, theArcMan.LangSupport.Strings(K_Lang_Tabs_Settings_ShowConsole, str).c_str()) ;

  GetDlgItemText(IDC_CHECK_XLIST_CONSOLE, str, 40);
  SetDlgItemText(IDC_CHECK_XLIST_CONSOLE, theArcMan.LangSupport.Strings(K_Lang_Tabs_Settings_XLIST_CONSOLE, str).c_str()) ;

  GetDlgItemText(IDC_CHECK_TRAY, str, 40);
  SetDlgItemText(IDC_CHECK_TRAY, theArcMan.LangSupport.Strings(K_Lang_Tabs_Settings_TRAY, str).c_str()) ;

  GetDlgItemText(IDC_CHECK_AUTOCLOSE, str, 40);
  SetDlgItemText(IDC_CHECK_AUTOCLOSE, theArcMan.LangSupport.Strings(K_Lang_Tabs_Settings_AUTOCLOSE, str).c_str()) ;

  GetDlgItemText(IDC_LABEL_DELAY, str, 40);
  SetDlgItemText(IDC_LABEL_DELAY, theArcMan.LangSupport.Strings(K_Lang_Tabs_Settings_DELAY, str).c_str()) ;

  GetDlgItemText(IDC_LABEL_HEIGHT, str, 40);
  SetDlgItemText(IDC_LABEL_HEIGHT, theArcMan.LangSupport.Strings(K_Lang_Tabs_Settings_HEIGHT, str).c_str()) ;
};
//********************************************************************

//***********************************************************
// LanguagePage Methods 
//***********************************************************

//***********************************************************
LanguagePage::LanguagePage()
{ 
  m_lpTemplateName ="PAGE_LANGUAGE"; 
  m_Title =theArcMan.LangSupport.Strings(K_Lang_Tabs_Language_Caption, "Language" ).c_str();
}
//***********************************************************
void LanguagePage::AddLangItemToLangCombo(const LPSTR LangFileName) //const LPSTR LangName, const LPSTR PathToLangFile)
{
  char buf[MAX_PATH], LangFile[MAX_PATH];
  char szDrive[_MAX_DRIVE], szPath[MAX_PATH], szName[_MAX_FNAME],  
       szExt[_MAX_EXT];
  _splitpath(LangFileName, szDrive, szPath, szName, szExt);  
  if (!stricmp(szExt,".lng"))
  {
    strcpy(LangFile, theArcMan.LangSupport.GetPathToLangDir().c_str());
    strcat(LangFile, LangFileName);
    GetPrivateProfileString("LanG", "Name", "", buf, MAX_PATH, LangFile);
    strcat(buf, " ");
    strcat(buf, LangFileName);
    int idx = ComboBox_AddString(m_LangComboHandle, buf);
    char * tmpBuf = new char [strlen(LangFile) +1];
    strcpy(tmpBuf, LangFile);
    ComboBox_SetItemData (m_LangComboHandle, idx,  tmpBuf);
  }
};
//***********************************************************
void LanguagePage::DisableLangControls()
{
  //AddLangItemToLangCombo(0, (char* const) theArcMan.LangSupport.Strings(K_Lang_Tabs_Language_LangNotSet, "(default)").c_str(), "");
  ComboBox_AddString(m_LangComboHandle, theArcMan.LangSupport.Strings(K_Lang_Tabs_Language_LangNotSet, "(default)").c_str());
  ComboBox_SetCurSel(m_LangComboHandle, 0);
  ComboBox_Enable(m_LangComboHandle, FALSE);
  EnableWindow(m_LangLabelHandle,   FALSE);
  EnableWindow(m_LangLabelVersion,  FALSE);
  EnableWindow(m_LangLabelLastEdit, FALSE);
  EnableWindow(m_LangVersion      , FALSE);
  EnableWindow(m_LangLastedit     , FALSE);
  EnableWindow(m_LangListParam    , FALSE);
  EnableWindow(m_LangValue        , FALSE);
  EnableWindow(m_Lang_LBL_Param   , FALSE);
  EnableWindow(m_Lang_LBL_Value   , FALSE);
  EnableWindow(m_Lang_FileInfo    , FALSE);
};
//***********************************************************
BOOL LanguagePage::DlgProc(WORD msg, WPARAM wParam, LPARAM lParam)
{
  switch (msg)
  {
    case WM_DELETEITEM: return OnDeleteItem(wParam, (LPDELETEITEMSTRUCT) lParam); 
/*
    case WM_CTLCOLORSTATIC: return (BOOL)OnCtlColor(WM_CTLCOLORSTATIC, (HDC)(wParam), (HWND)(lParam));
    case WM_INITDIALOG: return OnInitDialog((HWND)(wParam), lParam);
    case WM_NOTIFY: return OnNotify((int)(wParam), (NMHDR FAR*)(lParam));
//    case WM_TIMER: return OnTimer((UINT)(wParam));
//    case WM_HELP: return OnHelp((HELPINFO *)lParam);
*/
    default:
      return PropSheetPage::DlgProc(msg, wParam, lParam);
  }

  return FALSE;
};  
//***********************************************************
void LanguagePage::FillControlHWND()
{
  m_LangComboHandle   = GetDlgItem(IDC_LANG_COMBO_LANGUAGE);
  m_LangLabelHandle   = GetDlgItem(IDC_LANG_LABEL_LANGUAGE);       
  m_LangLabelVersion  = GetDlgItem(IDC_LANG_LABEL_VERSION);
  m_LangLabelLastEdit = GetDlgItem(IDC_LANG_LABEL_LASTEDIT);
  m_LangVersion       = GetDlgItem(IDC_LANG_VERSION);
  m_LangLastedit      = GetDlgItem(IDC_LANG_LASTEDIT);
  m_LangListParam     = GetDlgItem(IDC_LANG_LIST_PARAMETERS);
  m_LangValue         = GetDlgItem(IDC_LANG_EDIT_VALUE);
  m_Lang_LBL_Param    = GetDlgItem(IDC_LANG_LABEL_PARAMETERS);
  m_Lang_LBL_Value    = GetDlgItem(IDC_LANG_LABEL_VALUE);
  m_Lang_FileInfo     = GetDlgItem(IDC_LANG_GROUP_FILEINFO);
}
//***********************************************************
void LanguagePage::FillLangAuthoringInfo(LPSTR LangFile)
{
  char Buff[40];
  GetPrivateProfileString(LangFileAuthoringSection, LangFileVersionIdent,     "", Buff, 40,  LangFile);
  SetDlgItemText(IDC_LANG_VERSION, Buff); 
  GetPrivateProfileString(LangFileAuthoringSection, LangFileDateEditIdent,    "", Buff, 40,  LangFile);
  SetDlgItemText(IDC_LANG_LASTEDIT, Buff);
  GetPrivateProfileString(LangFileAuthoringSection, LangFileAuthorIdent,      "", Buff, 40,  LangFile);
  m_Author = Buff;
  GetPrivateProfileString(LangFileAuthoringSection, LangFileCopyRigthIdent,   "", Buff, 40,  LangFile);
  m_Copyright = Buff;
  GetPrivateProfileString(LangFileAuthoringSection, LangFileLicenseIdent,     "", Buff, 40,  LangFile);
  m_Lisence = Buff;
  GetPrivateProfileString(LangFileAuthoringSection, LangFileOtherInfoIdent,   "", Buff, 40,  LangFile);
  m_OtherInfo = Buff;
  GetPrivateProfileString(LangFileAuthoringSection, LangFileContactInfoIdent, "", Buff, 40,  LangFile);
  m_ContactInfo = Buff;
  SetParamValue();
}
//***********************************************************
void LanguagePage::FillLangCombo()
{
  ComboBox_ResetContent(m_LangComboHandle);
  char FindLangStr[MAX_PATH];
  strcpy(FindLangStr, theArcMan.LangSupport.GetPathToLangDir().c_str());
  strcat(FindLangStr, "*.lng");
  WIN32_FIND_DATA fd;
  HANDLE FindFileHandle;
  FindFileHandle = FindFirstFile(FindLangStr, &fd);
  if (FindFileHandle == INVALID_HANDLE_VALUE) 
  { 
     DisableLangControls();
     return;
  }
  else
  {
    // For First Founded File
    AddLangItemToLangCombo(fd.cFileName);
    // For rest files
    while (FindNextFile(FindFileHandle, &fd))
      AddLangItemToLangCombo(fd.cFileName);
    // Synhronize GUI
    int i= SendMessage(m_LangComboHandle,CB_GETCOUNT,  0,0);
    int CurrSelIdx = -1;    

    for (int idx=0; idx<i;idx++)
    {
      char * tBuf; 
      tBuf = (char *)ComboBox_GetItemData(m_LangComboHandle,idx);
      if (!stricmp((char *)theArcMan.LangSupport.GetPathToLangFile().c_str(), tBuf))
      {
        CurrSelIdx = idx;
        FillLangAuthoringInfo(tBuf);
        break;
      }

    }
    ComboBox_SetCurSel(m_LangComboHandle, CurrSelIdx);
    
    FindClose(FindFileHandle);
  } // if else
}
//***********************************************************
void LanguagePage::FillParametersName()
{
  char str[40]; int tmpIdx;
  strcpy(str, theArcMan.LangSupport.Strings(K_Lang_Tabs_Language_Authors, "Authors").c_str()) ;
  tmpIdx = SendMessage(m_LangListParam, LB_ADDSTRING, 0, (LPARAM) (LPCTSTR) str);
  SendMessage(m_LangListParam, LB_SETITEMDATA,  tmpIdx, alpAuthor);

  strcpy(str, theArcMan.LangSupport.Strings(K_Lang_Tabs_Language_Copyrigth, "Copyrigth").c_str()) ;
  tmpIdx = SendMessage(m_LangListParam, LB_ADDSTRING, 0, (LPARAM) (LPCTSTR) str);
  SendMessage(m_LangListParam, LB_SETITEMDATA,  tmpIdx, alpCopyRigth);

  strcpy(str, theArcMan.LangSupport.Strings(K_Lang_Tabs_Language_Licence, "Licence").c_str()) ;
  tmpIdx = SendMessage(m_LangListParam, LB_ADDSTRING, 0, (LPARAM) (LPCTSTR) str);
  SendMessage(m_LangListParam, LB_SETITEMDATA,  tmpIdx, alpLisence);

  strcpy(str, theArcMan.LangSupport.Strings(K_Lang_Tabs_Language_OtherInfo, "Other Info").c_str()) ;
  tmpIdx = SendMessage(m_LangListParam, LB_ADDSTRING, 0, (LPARAM) (LPCTSTR) str);
  SendMessage(m_LangListParam, LB_SETITEMDATA,  tmpIdx, alpOtherInfo);

  strcpy(str, theArcMan.LangSupport.Strings(K_Lang_Tabs_Language_ContactInfo, "Contact Info").c_str()) ;
  tmpIdx = SendMessage(m_LangListParam, LB_ADDSTRING, 0, (LPARAM) (LPCTSTR) str);
  SendMessage(m_LangListParam, LB_SETITEMDATA,  tmpIdx, alpContactInfo);
  
  SendMessage(m_LangListParam, LB_SETCURSEL,0,0);
};
//***********************************************************
BOOL LanguagePage::LangFileComboCommand(int nCode)
{
  if(nCode == CBN_SELCHANGE)
  {
    int idx = ComboBox_GetCurSel(m_LangComboHandle);
    if(idx != -1)
    { 
      char * tmpBuf = (char *) ComboBox_GetItemData(m_LangComboHandle,idx);
      if (strcmp(tmpBuf, ""))
        FillLangAuthoringInfo(tmpBuf);
    }
  }
  return TRUE;
}
//***********************************************************
BOOL LanguagePage::OnApply(int id, NMHDR * lpNMHdr)
{
    int idx = ComboBox_GetCurSel(m_LangComboHandle);
    if(idx != -1)
    { 
      char * tmpBuf = (char *) ComboBox_GetItemData(m_LangComboHandle,idx);
      if (strcmp(tmpBuf, ""))
          theArcMan.LangSupport.SetPathToLangFile(tmpBuf);
    }

  return TRUE;
}
//***********************************************************
BOOL LanguagePage::OnCommand( int id, HWND hwndCtl, UINT nCode)
{
  switch (id)
  {
    case IDC_LANG_LIST_PARAMETERS: 
      {  SetParamValue();
        return TRUE;
      } 
    case IDC_LANG_COMBO_LANGUAGE: 
      {
        return LangFileComboCommand(nCode);
      }
  }

  return PropSheetPage::OnCommand(id, hwndCtl, nCode);
}
//***********************************************************
BOOL LanguagePage::OnDeleteItem(WPARAM wParam, LPDELETEITEMSTRUCT lParam)
{
  delete [] (char *) lParam->itemData;
  return TRUE;
};
//***********************************************************
BOOL LanguagePage::OnInitDialog(HWND hwndFocus, LPARAM lParam)
{
  if(!PropSheetPage::OnInitDialog(hwndFocus, lParam)) return FALSE;
  m_PageHelpTopicID = IDC_PAGE_LANGUAGE;
  // set handles to controls
  FillControlHWND();
  // Set Parameters Names
  FillParametersName();
  // fill All Avalible language files
  FillLangCombo();
  return TRUE;
};
//***********************************************************
void LanguagePage::SetLangCaptions()
{
  char str[40];
  GetDlgItemText(IDC_LANG_LABEL_LANGUAGE, str, 40);
  SetDlgItemText(IDC_LANG_LABEL_LANGUAGE, theArcMan.LangSupport.Strings(K_Lang_Tabs_Language_LABEL_LANGUAGE, str).c_str()) ;

  GetDlgItemText(IDC_LANG_LABEL_VERSION, str, 40);
  SetDlgItemText(IDC_LANG_LABEL_VERSION, theArcMan.LangSupport.Strings(K_Lang_Tabs_Language_LABEL_VERSION, str).c_str()) ;

  GetDlgItemText(IDC_LANG_LABEL_LASTEDIT, str, 40);
  SetDlgItemText(IDC_LANG_LABEL_LASTEDIT, theArcMan.LangSupport.Strings(K_Lang_Tabs_Language_LABEL_LASTEDIT, str).c_str()) ;

  GetDlgItemText(IDC_LANG_LABEL_PARAMETERS, str, 40);
  SetDlgItemText(IDC_LANG_LABEL_PARAMETERS, theArcMan.LangSupport.Strings(K_Lang_Tabs_Language_LABEL_PARAMETERS, str).c_str()) ;

  GetDlgItemText(IDC_LANG_LABEL_VALUE, str, 40);
  SetDlgItemText(IDC_LANG_LABEL_VALUE, theArcMan.LangSupport.Strings(K_Lang_Tabs_Language_LABEL_VALUE, str).c_str()) ;

  GetDlgItemText(IDC_LANG_GROUP_FILEINFO, str, 40);
  SetDlgItemText(IDC_LANG_GROUP_FILEINFO, theArcMan.LangSupport.Strings(K_Lang_Tabs_Language_GROUP_FILEINFO, str).c_str()) ;
}
//***********************************************************
void LanguagePage::SetParamValue()
{ int curIdx = SendMessage(m_LangListParam, LB_GETCURSEL ,0,0);
  if (curIdx == LB_ERR) return;
  curIdx = SendMessage(m_LangListParam, LB_GETITEMDATA, curIdx, 0);
  switch (curIdx)  
  {
    case alpAuthor: {SetDlgItemText(IDC_LANG_EDIT_VALUE, m_Author.c_str()); break;}
    case alpCopyRigth:{SetDlgItemText(IDC_LANG_EDIT_VALUE, m_Copyright.c_str()); break;}
    case alpLisence:{SetDlgItemText(IDC_LANG_EDIT_VALUE, m_Lisence.c_str()); break;}
    case alpContactInfo:{SetDlgItemText(IDC_LANG_EDIT_VALUE, m_ContactInfo.c_str()); break;}
    case alpOtherInfo:{SetDlgItemText(IDC_LANG_EDIT_VALUE, m_OtherInfo.c_str()); break;}
  };
};
//***********************************************************

//***********************************************************
// PageDialog class
//***********************************************************
PageDialog::PageDialog(HWND ParentHandle, SinglePage *Page)
{
  m_hParentHwnd =ParentHandle;
  m_Page = Page;
};
//*********************************************************** 
int PageDialog::Run()
{
  return DialogBoxParam(theArcMan.Instance(), m_Page->TemplateName(), m_hParentHwnd, m_Page->DlgProc2, (long)this->m_Page);
};
//***********************************************************
// SinglePage class
//***********************************************************
BOOL CALLBACK SinglePage::DlgProc2(HWND hwnd, UINT msg, WPARAM wParam, LPARAM lParam)
{
  SinglePage *pThis = (SinglePage *) GetWindowLong(hwnd, GWL_USERDATA);
  switch (msg)
  {
  case WM_INITDIALOG:
    {
      pThis = (SinglePage *) lParam;
      SetWindowLong(hwnd, GWL_USERDATA, lParam);
      pThis->m_hwnd = hwnd;
    } 
  default:
    if(pThis)
      return pThis->DlgProc(msg, wParam, lParam);
  } //switch
  return FALSE;
}
//***********************************************************
BOOL SinglePage::DlgProc(WORD msg, WPARAM wParam, LPARAM lParam)
{
  switch (msg)
  {
    case WM_COMMAND: return OnCommand((int)(LOWORD(wParam)), (HWND)(lParam), (UINT)HIWORD(wParam));
//    case WM_CTLCOLORSTATIC: return (BOOL)OnCtlColor(WM_CTLCOLORSTATIC, (HDC)(wParam), (HWND)(lParam));
//    case WM_INITDIALOG: return OnInitDialog((HWND)(wParam), lParam);
//    case WM_NOTIFY: return OnNotify((int)(wParam), (NMHDR FAR*)(lParam));
    case WM_TIMER: return OnTimer((UINT)(wParam));
//    case WM_HELP: return OnHelp((HELPINFO *)lParam);
    default:
      return PropSheetPage::DlgProc(msg, wParam,lParam);
  }
  return 0;
};
//***********************************************************
/*
BOOL SinglePage::OnInitDialog(HWND hwndFocus, LPARAM lParam)
{return TRUE;};
*/
//***********************************************************
BOOL SinglePage::OnCommand( int id, HWND hwndCtl, UINT nCode)
{
  switch(id)
  {
    case IDOK:     return OnOK();
    case IDCANCEL: return OnCancel();
  }
  return FALSE;
};
//***********************************************************
BOOL SinglePage::OnOK()
{
  EndDialog(m_hwnd, 1);
  return TRUE;
};
//***********************************************************
BOOL SinglePage::OnCancel()
{ 
  EndDialog(m_hwnd, 0);
  return TRUE;
};
//***********************************************************

//***********************************************************
// CapabilitesPage class
//***********************************************************
CapabilitiesPage::CapabilitiesPage()
{  
  m_lpTemplateName ="CAPABILITIES";
};
//***********************************************************

// Capabilities dialog
struct cap_check{
  unsigned int caps;
  unsigned int id; 
} cap_checks[]=
{
  { PK_CAPS_NEW,        IDC_CHECK_CAN_CREATE},
  { PK_CAPS_MODIFY,     IDC_CHECK_CAN_MODIFY},
  { PK_CAPS_MULTIPLE,   IDC_CHECK_MULTI_FILES},
  { PK_CAPS_BY_CONTENT, IDC_CHECK_DETECT_TYPE},
  { PK_CAPS_DELETE,     IDC_CHECK_CAN_DELETE},
  { PK_CAPS_SEARCHTEXT, IDC_CHECK_SUPPORTS_SEARCH},
  { PK_CAPS_HIDE_ICON,  IDC_CHECK_HIDE_ICON},
};


//===========================================================================0
BOOL CapabilitiesPage::ActiveCheckCommand(int nCode)
{
  if(nCode == BN_CLICKED)
  { 
    int idx = GetCurSelIdx();
    if(idx != CB_ERR)
    {
      if(m_pad)
        m_pad->SetExtActive(idx, Button_GetCheck(m_hwndCheckActive) == TRUE);
      ComboCommand(CBN_SELCHANGE);
    }
  }
  return TRUE;
}
//********************************************************************
BOOL CapabilitiesPage::CapCheckCommand(int nCode, int id)
{
  if(nCode == BN_CLICKED)
  {
    int idx = GetCurSelIdx();
    if(idx != CB_ERR)
    {
      if(m_pad)
      {
        int caps = m_pad->GetExtCaps(idx);
        
        if(Button_GetCheck(GetDlgItem(id)))
          caps |= cap_checks[id - IDC_CHECK_CAPS_BASE].caps;
        else
          caps &= ~cap_checks[id - IDC_CHECK_CAPS_BASE].caps;
          
        m_pad->SetExtCaps(idx, caps);
      }
      ComboCommand(CBN_SELCHANGE);
    }
  }
  return TRUE;
}
//********************************************************************
BOOL CapabilitiesPage::ComboCommand(int nCode)
{
  if(nCode == CBN_SELCHANGE)
  {
    int idx = GetCurSelIdx();
    if(idx != CB_ERR)
    {
      BOOL bIsActive = m_pad->IsExtActive(idx) == true;
      Button_SetCheck(m_hwndCheckActive, bIsActive);

      int caps = m_pad->GetExtCaps(idx);
      for(int i = 0; i < sizeof(cap_checks)/sizeof(cap_checks[0]); i++)
      {
        HWND hwnd = GetDlgItem(cap_checks[i].id);
        EnableWindow(hwnd, bIsActive);
        Button_SetCheck(hwnd, caps & cap_checks[i].caps);
      }
    }
  }
  return TRUE;
}
//********************************************************************
int CapabilitiesPage::GetCurSelIdx()
{
  return ComboBox_GetItemData(m_hwndCombo, ComboBox_GetCurSel(m_hwndCombo));
}
//********************************************************************
BOOL CapabilitiesPage::OnCommand( int id, HWND hwndCtl, UINT nCode)
{
  switch(id)
  {
  case IDC_COMBO_EXTS: return ComboCommand(nCode);
  case IDC_CHECK_ACTIVE: return ActiveCheckCommand(nCode);
  case IDC_CHECK_CAN_CREATE:
  case IDC_CHECK_CAN_MODIFY:
  case IDC_CHECK_MULTI_FILES:
  case IDC_CHECK_CAN_DELETE:
  case IDC_CHECK_DETECT_TYPE:
  case IDC_CHECK_SUPPORTS_SEARCH:
  case IDC_CHECK_HIDE_ICON:
    return CapCheckCommand(nCode, id);
  default: break;
  }
  return SinglePage::OnCommand(id, hwndCtl, nCode);
}
//********************************************************************
BOOL CapabilitiesPage::OnInitDialog(HWND hwndFocus, LPARAM lParam)
{
  m_hwndCombo = GetDlgItem(IDC_COMBO_EXTS);
  m_hwndCheckActive = GetDlgItem(IDC_CHECK_ACTIVE);

  if(m_pad)
  {
    int count = m_pad->ExtsCount();
    for(int i=0; i < count; i++)
    {
      int idx = ComboBox_AddString(m_hwndCombo, m_pad->GetExt(i));
      ComboBox_SetItemData(m_hwndCombo, idx, i);
    }
    ComboBox_SetCurSel(m_hwndCombo, 0);
    ComboCommand(CBN_SELCHANGE);
  }
  return SinglePage::OnInitDialog(hwndFocus, lParam);
}
//********************************************************************
void CapabilitiesPage::SetLangCaptions()
{
  char str[40];

  GetWindowText(m_hwnd, str, 40);
  SetWindowText(m_hwnd, theArcMan.LangSupport.Strings(K_Lang_Capabilities_Caption, str).c_str()) ;

  GetDlgItemText(IDC_STATIC_EXTENSION, str, 40);
  SetDlgItemText(IDC_STATIC_EXTENSION, theArcMan.LangSupport.Strings(K_Lang_Capabilities_Extension, str).c_str()) ;

  GetDlgItemText(IDC_CHECK_CAN_CREATE, str, 40);
  SetDlgItemText(IDC_CHECK_CAN_CREATE, theArcMan.LangSupport.Strings(K_Lang_Capabilities_CAN_CREATE, str).c_str()) ;

  GetDlgItemText(IDC_CHECK_CAN_MODIFY, str, 40);
  SetDlgItemText(IDC_CHECK_CAN_MODIFY, theArcMan.LangSupport.Strings(K_Lang_Capabilities_CAN_MODIFY, str).c_str()) ;

  GetDlgItemText(IDC_CHECK_MULTI_FILES, str, 40);
  SetDlgItemText(IDC_CHECK_MULTI_FILES, theArcMan.LangSupport.Strings(K_Lang_Capabilities_MULTI_FILES, str).c_str()) ;

  GetDlgItemText(IDC_CHECK_DETECT_TYPE, str, 40);
  SetDlgItemText(IDC_CHECK_DETECT_TYPE, theArcMan.LangSupport.Strings(K_Lang_Capabilities_DETECT_TYPE, str).c_str()) ;

  GetDlgItemText(IDC_CHECK_CAN_DELETE, str, 40);
  SetDlgItemText(IDC_CHECK_CAN_DELETE, theArcMan.LangSupport.Strings(K_Lang_Capabilities_CAN_DELETE, str).c_str()) ;

  GetDlgItemText(IDC_CHECK_SUPPORTS_SEARCH, str, 40);
  SetDlgItemText(IDC_CHECK_SUPPORTS_SEARCH, theArcMan.LangSupport.Strings(K_Lang_Capabilities_SUPPORTS_SEARCH, str).c_str()) ;

  GetDlgItemText(IDC_CHECK_HIDE_ICON, str, 40);
  SetDlgItemText(IDC_CHECK_HIDE_ICON, theArcMan.LangSupport.Strings(K_Lang_Capabilities_HIDE_ICON, str).c_str()) ;

  GetDlgItemText(IDC_CHECK_ACTIVE, str, 40);
  SetDlgItemText(IDC_CHECK_ACTIVE, theArcMan.LangSupport.Strings(K_Lang_Capabilities_ACTIVE, str).c_str()) ;

  GetDlgItemText(IDOK, str, 40);
  SetDlgItemText(IDOK, theArcMan.LangSupport.Strings(K_Lang_Button_OK, str).c_str()) ;

  GetDlgItemText(IDCANCEL, str, 40);
  SetDlgItemText(IDCANCEL, theArcMan.LangSupport.Strings(K_Lang_Button_Cancel, str).c_str()) ;

};
//***********************************************************

//***********************************************************
// WaitPage class
//***********************************************************
BOOL WaitPage::OnCancel()
{
  if(MessageBox(GetFocus(),
     theArcMan.LangSupport.Strings(K_Lang_Wait_Terminale_Message, 
        "All changes in multiarc.ini you have made "
        "in external editor will be lost. Terminate anyway?").c_str(),
     theArcMan.LangSupport.Strings(K_Lang_Wait_Terminate_Caption,"Terminating editor").c_str()     
         , MB_ICONQUESTION|MB_YESNO) == IDYES)
  {
    TerminateProcess(m_hProcess, -1);
    return SinglePage::OnCancel();
  }
  return TRUE;
}
//***********************************************************
const int cnWaitTimerId = 2727;
const int cnWaitTimeout = 500;
//********************************************************************
BOOL WaitPage::OnInitDialog(HWND hwndFocus, LPARAM lParam)
{
  if (!SinglePage::OnInitDialog(hwndFocus, lParam)) return FALSE;
  SetTimer(cnWaitTimerId, cnWaitTimeout);
  return TRUE;
}
//********************************************************************
BOOL WaitPage::OnTimer(UINT id) 
{
  if(id == cnWaitTimerId)
  {
    if(WaitForSingleObject(m_hProcess, 0) == WAIT_OBJECT_0)
      OnOK();
    return TRUE; 
  }
  return SinglePage::OnTimer(id);
};
//********************************************************************
void WaitPage::SetLangCaptions()
{
  char str[40];

  GetWindowText(m_hwnd, str, 40);
  SetWindowText(m_hwnd, theArcMan.LangSupport.Strings(K_Lang_Wait_Caption, str).c_str()) ;

  GetDlgItemText(IDC_STATIC_WAIT_MESSAGE, str, 40);
  SetDlgItemText(IDC_STATIC_WAIT_MESSAGE, theArcMan.LangSupport.Strings(K_Lang_Wait_Message, str).c_str()) ;

  GetDlgItemText(IDCANCEL, str, 40);
  SetDlgItemText(IDCANCEL, theArcMan.LangSupport.Strings(K_Lang_Wait_Close, str).c_str()) ;
};

//***********************************************************
// ArcTypePage Methods
//***********************************************************
ArcTypePage::ArcTypePage(const char *ext, vector<CArchiveDescription *> pads)
{
  m_lpTemplateName ="ASK_TYPE";
  m_ext = ext;
  m_pads = pads;
  Pad_Idx = CB_ERR;
}
//***********************************************************
BOOL ArcTypePage::OnInitDialog(HWND hwndFocus, LPARAM lParam)
{
  m_hwndCombo = GetDlgItem(IDC_EDIT);

  long st=GetWindowLong(m_hwndCombo,GWL_STYLE);
  st&=~CBS_DROPDOWNLIST ; 
  const NOT_ES_READONLY = -2049;

//  st= st & NOT_ES_READONLY;
//  st|= CBS_DROPDOWN; 
//  SetWindowLong(m_hwndCombo,GWL_STYLE,st);
//  st=GetWindowLong(m_hwndCombo,GWL_STYLE);

//  int lasterr = SetWindowLong(m_hwndCombo, GWL_STYLE, CBS_DROPDOWN | WS_VSCROLL | WS_TABSTOP);
//  m_hwndCombo = GetDlgItem(IDC_EDIT);

  char *mask = "%s (%s)";
  for(vector<CArchiveDescription*>::iterator i=m_pads.begin(); i != m_pads.end(); i++)
  {
    CArchiveDescription *pad = *i;
    const char *descr = pad ->String(DESCRIPT_IDX);
    if(!descr || !strlen(descr))
      descr = pad->String(TYPENAME_IDX);
    
    if(!descr) descr="";

    char *str = new char[strlen(descr) + strlen(mask)];
    
    sprintf(str, mask, m_ext, descr);
    
    int idx = ComboBox_AddString(m_hwndCombo, str);
    ComboBox_SetItemData(m_hwndCombo, idx, (long)pad);
    delete[] str;
  }
  ComboBox_SetCurSel(m_hwndCombo, 0);
  return SinglePage::OnInitDialog(hwndFocus, lParam);
}
//***********************************************************
BOOL ArcTypePage::OnOK()
{
  Pad_Idx = ComboBox_GetCurSel(m_hwndCombo);
  m_pad = (CArchiveDescription *) ComboBox_GetItemData(m_hwndCombo, ComboBox_GetCurSel(m_hwndCombo));  
  return SinglePage::OnOK();
}
//***********************************************************
BOOL ArcTypePage::OnCancel()
{ 
  Pad_Idx = CB_ERR;
  m_pad = NULL;
  return SinglePage::OnCancel();
}
//***********************************************************
BOOL ArcTypePage::OnHelp(HELPINFO *lphi)
{
  if(lphi->iCtrlId == IDC_EDIT)
    lphi->iCtrlId = IDC_EDIT_ASK_DLG;
  return SinglePage::OnHelp(lphi);
};
//***********************************************************
void ArcTypePage::SetLangCaptions()
{
  SetDlgItemText(IDC_STATIC_REQ, theArcMan.LangSupport.Strings(K_Lang_AskArcType_Info_Text, "Select the type of archive\n you want to use:").c_str()) ;
  SetWindowText(m_hwnd, theArcMan.LangSupport.Strings(K_Lang_AskArcType_Caption, "MultiArc wanted info!!!").c_str()) ;
}
//***********************************************************
// SParamDialog Methods 
//***********************************************************
SParamPage::SParamPage(HWND hParentHwnd, CArchiveDescription *pad)
{
  m_lpTemplateName ="ASK";
  m_idx = 0; 
  m_nAskForParamsCount = 0;
  m_nAskHistorySize = 10;
  m_pad = pad;
};
//***********************************************************
BOOL SParamPage::OnCancel()
{
  m_strAddParam = "";
  return SinglePage::OnCancel();
}
//********************************************************************
BOOL SParamPage::OnHelp(HELPINFO *lphi)
{
  if(lphi->iCtrlId == IDC_EDIT)
    lphi->iCtrlId = IDC_EDIT_SPARAM_DLG;
  return SinglePage::OnHelp(lphi);
}
//***********************************************************
BOOL SParamPage::OnInitDialog(HWND hwndFocus, LPARAM lParam)
{
  SinglePage::OnInitDialog(hwndFocus, lParam);
  m_hwndCombo = GetDlgItem(IDC_EDIT);

  char sz1[MAX_PATH];
  char sz2[MAX_PATH];
  UINT u = GetDlgItemText(IDC_STATIC_REQ, sz1, MAX_PATH);
  
  sprintf(sz2, sz1, m_nAskForParamsCount, GetActionText(m_idx).c_str()/*aKeyNames[m_idx]*/);
  SetDlgItemText(IDC_STATIC_REQ, sz2);

  LoadHistory();
  ComboBox_SetCurSel(m_hwndCombo, 0);
  
  return TRUE;
};
//********************************************************************
BOOL SParamPage::OnOK()
{
  char szAddParam[MAX_PATH];
  GetDlgItemText(IDC_EDIT, szAddParam, MAX_PATH);
  m_strAddParam = szAddParam;
  SaveHistory();
  return SinglePage::OnOK();
};
//********************************************************************
void SParamPage::LoadHistory()
{
  char szKey[32];
  char szItem[MAX_PATH];

  for(int i=0; i < m_nAskHistorySize; i++)
  {
    wsprintf(szKey, INI_KEY_SPARAM_HISTORY_MASK, i);
    if(!GetPrivateProfileString(m_pad->String(TYPENAME_IDX), szKey, "", szItem, MAX_PATH, theArcMan.IniFile()))
      break;
    ComboBox_AddString(m_hwndCombo, szItem);
  }
}
//********************************************************************
void SParamPage::SaveHistory()
{
  char szKey[32];
  char szItem[MAX_PATH];

  if(m_strAddParam.length()) // g_szAddParam already initialized!
  {
    int idx = ComboBox_FindStringExact(m_hwndCombo, -1, m_strAddParam.c_str());
    if(idx != CB_ERR)
      ComboBox_DeleteString(m_hwndCombo, idx);

    ComboBox_InsertString(m_hwndCombo, 0, m_strAddParam.c_str());

    int nCount = ComboBox_GetCount(m_hwndCombo);
    if(nCount > m_nAskHistorySize)
      nCount = m_nAskHistorySize;

    for(int i=0; i < nCount; i++)
    {
      wsprintf(szKey, INI_KEY_SPARAM_HISTORY_MASK, i);

      ComboBox_GetLBText(m_hwndCombo, i, szItem);
      WritePrivateProfileString(m_pad->String(TYPENAME_IDX), szKey, szItem, theArcMan.IniFile());
    }
  }
};
//********************************************************************
void SParamPage::SetLangCaptions()
{
  SetWindowText(m_hwnd, theArcMan.LangSupport.Strings(K_Lang_AskArcType_Caption, "MultiArc wanted info!!!").c_str()) ;
  SetDlgItemText(IDC_STATIC_REQ, theArcMan.LangSupport.Strings(K_Lang_Sparameter_Info_Text, "Enter, please, parameter # %d\nfor running command \"%s\":").c_str()) ;
};
//***********************************************************
string SParamPage::GetActionText(int idx)
{ 
  int tmpTextCode;
  if (!_stricmp(aKeyNames[idx], "Test"))
    tmpTextCode = K_Lang_Sparameter_ActionTest_Text;
  else if (!_stricmp(aKeyNames[idx], "Delete"))
    tmpTextCode = K_Lang_Sparameter_ActionDelete_Text;
  else if (!_stricmp(aKeyNames[idx], "Add"))
    tmpTextCode = K_Lang_Sparameter_ActionAdd_Text;
  else if (!_stricmp(aKeyNames[idx], "Move"))
    tmpTextCode = K_Lang_Sparameter_ActionMove_Text;
  else return aKeyNames[idx];
  return theArcMan.LangSupport.Strings(tmpTextCode, aKeyNames[idx]);
};
//***********************************************************
CArchiveDescription * GetArcTypeUserChoice(const char *ext, vector<CArchiveDescription *> pads)
{
  ArcTypePage * tmpPage = new ArcTypePage(ext, pads);
  PageDialog dlg(GetFocus(), tmpPage);
  if (dlg.Run() == IDOK)
    return pads[tmpPage->Pad_Idx];
  else
    return NULL ;
};
//***********************************************************
bool GetSParamUserChoice(int idx, int ParamsCount, CArchiveDescription *pad, 
       string  &UserChoiceStr)
{
  SParamPage * tmpPage = new SParamPage(GetFocus(), pad);
  tmpPage->m_idx = idx;
  tmpPage->m_nAskForParamsCount = ParamsCount;
  PageDialog dlg(GetFocus(), tmpPage);
  if(dlg.Run() == IDOK && tmpPage->m_strAddParam.length())
  {
    UserChoiceStr = tmpPage->m_strAddParam;
    return true;
  }
  return false;
}
//***********************************************************
