#ifndef _MAConsole_h_
  #define _MAConsole_h_

#include "ArchiverManager.h"

class MAConsole
{
  char const *m_buff;
  int m_length;
  char const *m_buff_ptr;
  //string strText;
  HWND m_hwnd;
  HWND m_hwndEdit;
  HMODULE m_hRichEdLib;
  HANDLE m_hThread;
  bool m_bDieReq;
  eConMode m_cm;
  bool m_bUseTray;
 /* bool m_bAutoClose;
  int m_nDelay;*/
  HANDLE m_hEvent;
  HANDLE m_hCtrlBreakEvent;
  HANDLE m_hEventExLines;
  HANDLE m_hMutexExLines;

  static DWORD CALLBACK StreamCallback(DWORD dwCookie, LPBYTE buff, LONG cb, LONG *pcb);
  static LRESULT CALLBACK WndProc(HWND hwnd, WORD msg, WPARAM wParam, LPARAM lParam);
  static DWORD WINAPI ThreadProc( LPVOID lpParameter );
//  static VOID CALLBACK TimerProc( HWND hwnd, UINT uMsg, UINT_PTR idEvent, DWORD dwTime );

  LRESULT OnTrayMessage(UINT id, UINT msg);
  void SaveWindowSettings();
  WINDOWPLACEMENT GetWindowSettings();
  void CheckTopLines();
//  void ScrollHelper(int nCount = -1);

 // BOOL AddTrayIcon();
 // BOOL RemoveTrayIcon();
  void CreateConsole();
  void DestroyConsole();

public:
  MAConsole();
  ~MAConsole();

  BOOL OnCreate(HWND hwnd, LPCREATESTRUCT lpCreateStruct);
  void OnSize(UINT state, int cx, int cy);
  void OnMove(int cx, int cy);
  BOOL OnSysCommand(UINT id, int x, int y);
  void OnSetFocus(HWND hwndPrev);
 // bool OnKeyUp(UINT vk, int repeat, UINT flags);
  void OnNotify(int id, LPNMHDR lpnmhdr);
  LRESULT OnClose();
  LRESULT OnTimer(int id);
  BOOL ShowWindow(int nCmdShow){ return ::ShowWindow(m_hwnd, nCmdShow); }
  bool IsDying() { return m_bDieReq; }

  void Text(const char *buff, int nFormat);
  void Header(const char *buff, bool bRtf);
  void OnExecuteCommand(bool bStart, bool bIsCSet);
  void OnCParamsChange();
};

extern MAConsole theMAConsole;

#endif// _MAConsole_h_