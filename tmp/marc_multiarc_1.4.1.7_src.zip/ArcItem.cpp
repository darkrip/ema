#include "stdafx.h"
#include "utils.h"
#include "ArcItem.h"

CArcItem::CArcItem()
{
	m_pNext=NULL;
	m_szFilePath[0]=0;
	m_iPackedSize=0;
	m_iUnpackedSize=0;
	m_iFileAttr=0;
	m_iFileTime=0;
}

CArcItem::~CArcItem()
{
}

int GetAttr(char *p)
{
	int iRet=0;

	strlwr(p);

	if(strchr(p,'a'))
		iRet|=_A_ARCH;
	if(strchr(p,'h'))
		iRet|=_A_HIDDEN;
	if(strchr(p,'s'))
		iRet|=_A_SYSTEM;
	if(strchr(p,'r'))
		iRet|=_A_RDONLY;
	if(strchr(p,'d'))
		iRet|=_A_SUBDIR;

	return iRet;
}

int GetYear(char *str)
{
	int iRet=atoi(str);
	if(iRet<1900)
		if(iRet<80)
			iRet+=2000;
		else
			iRet+=1900;

	return iRet-1980;
}

int GetHourModifier(char *str)
{
	strlwr(str);
	if(strchr(str,'p'))
		return 12;
	return 0;
}

int GetMonth(char *str)
{
	char aMonths[][4]={"Jan","Feb","Mar","Apr","May","Jun",
						"Jul","Aug","Sep","Oct","Nov","Dec"};
	for(int i=0;i<12;i++)
		if(!lstrcmpi(str,aMonths[i]))
			return i+1;
	return 0;
}

int GetFormatFieldLength( const char *p)
{
	int iRet=0;
	if(p)
	{
		char ch=*p;
		switch(ch)
		{
		case 'n':case 'z':case 'p':
		case 'd':case 't':case 'y':
		case 'h':case 'H':case 'm':
		case 's':case 'a':case 'T':
		case 'e':
		{
			while(p && *p==ch){ p++; iRet++;}
		}
		default:
			break;
		}
	}
	return iRet;
}

int CArcItem::ParseFormatLine( const char *pFmt,const char **ppBeg, CArcItem *pai,CArchiveDescription *pad)
{
	const char *pStr=*ppBeg;

	while(pFmt && *pFmt)
	{
		if(*pFmt=='*')
		{
			pFmt++;
			while(pStr && *pStr && *pStr!=' ' && *pStr!='\n')pStr++;
			if(pStr && *pStr=='\n')
				pStr++;
			continue;
		}

		int iFmtLen=GetFormatFieldLength(pFmt);

		if(iFmtLen)
		{
			int iStrLen=iFmtLen;
			char *str=new char[iFmtLen+1];
			strncpy(str,pStr,iFmtLen);
			str[iFmtLen]=0;

			switch(*pFmt)
			{
			case 'z':
				pai->m_iUnpackedSize=atoi(str);
				break;
			case 'p':
				pai->m_iPackedSize=atoi(str);
				break;
			case 'y':
				pai->ftime.year=GetYear(str);
				break;
			case 't':
				pai->ftime.month=atoi(str);
				break;
			case 'T':
				pai->ftime.month=GetMonth(str);
				break;
			case 'd':
				pai->ftime.day=atoi(str);
				break;
			case 'h':
				pai->ftime.hour=atoi(str);
				break;
			case 'H':
					pai->ftime.hour+=GetHourModifier(str);
					if(!(pai->ftime.hour % 12))
							pai->ftime.hour -= 12;
				break;
			case 'm':
				pai->ftime.min=atoi(str);
				break;
			case 's':
				pai->ftime.sec=atoi(str)/2;
				break;
			case 'a':
				pai->m_iFileAttr=GetAttr(str);
				break;
			case 'n':
				{
					LPCSTR lpZ=pad->String(TYPENAME_IDX);
					bool bAINSpecific=lpZ && !strcmp(lpZ,"AIN");

					if(bAINSpecific)
					{
						int iLen=0;
						while(pStr[iLen] && pStr[iLen]!='\r')iLen++;
						
						if(iLen<=iFmtLen || pStr[iFmtLen]!=' ')
						{
							char *p=(char *)pStr;
							if(*p)
							{
								int iTrimmedLen=iLen-(p-pStr);
								if(iTrimmedLen<0)iTrimmedLen=0;
								strncpy(pai->m_szFilePath,p,iTrimmedLen);
								pai->m_szFilePath[iTrimmedLen]=0;
								int i=iTrimmedLen-1;
								while(iZspace(pai->m_szFilePath[i]))
									pai->m_szFilePath[i--]=0;
							}
							else
								pai->m_szFilePath[0]=0;
							iStrLen=iLen+2+iFmtLen;
							break;
						}
					}
					int iLen=0;
					while(str[iLen] && str[iLen]!='\r')iLen++;
					char *p=str;
					while(*p && iZspace(*p))p++;
					if(*p)
					{
						int iTrimmedLen=iLen-(p-str);
						if(iTrimmedLen<0)iTrimmedLen=0;
						strncpy(pai->m_szFilePath,p,iTrimmedLen);
						pai->m_szFilePath[iTrimmedLen]=0;
						int i=iTrimmedLen-1;
						while(iZspace(pai->m_szFilePath[i]))
							pai->m_szFilePath[i--]=0;
					}
					else
						pai->m_szFilePath[0]=0;
					iStrLen=iLen;
				}
				break;
			case 'e':
				{
					char *p=str;
					while(*p && iZspace(*p))p++;
					int i=lstrlen(p)-1;
					while(iZspace(p[i]))p[i--]=0;
					if(lstrlen(p))
					{
						strcat(pai->m_szFilePath,".");
						strcat(pai->m_szFilePath,str);
					}
				}
				break;
			}
			delete[] str;
			pFmt+=iFmtLen;
			pStr+=iStrLen;
		}
		else
		{
			pFmt++;
			pStr++;
		}
	}

	while(pStr && *pStr && *pStr!='\n')pStr++;
	if(pStr && *pStr=='\n')pStr++;
	*ppBeg=pStr;
	return 0;
}

CArcItem *CArcItem::LoadFromList(const char *pList,int iListLen,CArchiveDescription *pad)
{
	CArcItem *pListRoot=NULL;
	CArcItem *pListEnd=NULL;
	const char *pBeg=pList;
	while(pBeg-pList<iListLen)
	{
		CArcItem *pai=new CArcItem();

		int iHF=pad->FormatHeight();

		if(!iHF)
			break;

		for(int i=0;i<iHF;i++)
			ParseFormatLine(pad->Format(i),&pBeg, pai,pad);

		if(pad->SkipEmpty())
			if(!strlen(pai->m_szFilePath))
			{
				delete pai;
				continue;
			}

		if(!pListRoot)
		{
			pListRoot=pai;
			pListEnd=pListRoot;
		}
		else
		{
			pListEnd->m_pNext=pai;
			pListEnd=pai;
		}

		if(pad->ConverFromUnixPath())
		{
			char *p=pai->m_szFilePath;
			for(;*p;p++)
				if(*p=='/')*p='\\';
		}
	}

  if(pListRoot && pad->SearchForUglyDirs())
  {
    for(CArcItem *p=pListRoot;p->m_pNext; p=p->m_pNext)
    {
      char *pName = p->m_szFilePath;
      int nLen = strlen(pName);

      for(CArcItem *p2=pListRoot; p2->m_pNext; p2=p2->m_pNext)
      {
        char * pName2 = p2->m_szFilePath;
        if((strlen(pName2) > nLen) && 
              (pName2[nLen] == '\\') && 
                !strncmp(pName, pName2, nLen))
        {
          strcat(pName,"\\");
          break;
        }
      }
    }
  }

	return pListRoot;
}
