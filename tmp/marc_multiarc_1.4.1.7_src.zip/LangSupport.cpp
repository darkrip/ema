#include "LangSupport.h"
#include "multiarc.h"
#include "ArchiverManager.h"

#define Max_Count_String_Len (18+1) //if count of string more 999,999,999,999,999, inc this num 

//***********************************************************
CLanguageSupport::CLanguageSupport()//(string PathToLangFile) 
{
  //m_LangFileName = PathToLangFile;
  m_LangFileName = "";
}
//***********************************************************
void CLanguageSupport::SetPathToConfigFile(string PathToConfigFile)
{
  char buf[MAX_PATH];
  buf[0] = 0;
  SetPathToLangDir(PathToConfigFile);
  GetPrivateProfileString(INI_SECTION_SETUP, "LanguageFile", "", buf, MAX_PATH, (LPTSTR)PathToConfigFile.c_str());
  if (strcmp(buf,"")) // if language file define
  { 
    
    char szDrive[_MAX_DRIVE], szPath[MAX_PATH],
         szName[_MAX_FNAME],  szExt[_MAX_EXT];
    
    ExpandEnvironmentStrings(buf, szPath, MAX_PATH);
    //1. if language file set with path, use it
    //   ���� �������� ���� ������ � �����, ���������� ���
    _splitpath(szPath,szDrive,buf,szName,szExt);
    if (strcmp(szDrive, ""))
    { 
      m_LangFileName=szPath;
      return;
    }
    //2. if language file without path, get it from lang dir
    //   ���� ���, ����� ����� ��� �� ���������� �� ���������.
    // check lang-file present
    strcpy(buf,GetPathToLangDir().c_str());
    strcat(buf,szName);
    strcat(buf,szExt);

    ExpandEnvironmentStrings(buf, szPath, MAX_PATH);
    
    struct _stat st;
    if (!(_stat(szPath, &st) == -1 && errno == ENOENT))
      m_LangFileName=szPath;
     
  } // if

};
//************************************************
void CLanguageSupport::SetPathToLangDir(string PathToConfigFile)
{
  char buf[MAX_PATH];
  char szDrive[_MAX_DRIVE], szPath[MAX_PATH],
       szName[_MAX_FNAME],  szExt[_MAX_EXT];
  _splitpath(PathToConfigFile.c_str(), szDrive, szPath, szName, szExt);  
  strcat(szPath,"Lang\\");
  _makepath(buf,szDrive,szPath,"", "");
  m_LangDirPath = buf;

}
//************************************************
void CLanguageSupport::SetPathToLangFile(string PathToLangFile)
{ m_LangFileName= PathToLangFile;}

//************************************************
string CLanguageSupport::ProcessSpecialChar(string InputString)
{
  string::size_type tmpPos =0;
  do
  {
    tmpPos = InputString.find("\\n", tmpPos);//0)
    if (!(tmpPos == string::npos))
      InputString.replace(tmpPos, 2, "\n");
  }
  while (!(tmpPos == string::npos));
  return InputString;
}
//************************************************
string CLanguageSupport::Strings(int StringID, LPCSTR DefaultString)
{
  DefaultString = TEXT(DefaultString);
  if (!(m_LangFileName.compare(""))) return DefaultString; //if file not define
  char Buff[MAX_PATH];
  char num[Max_Count_String_Len]; 
  itoa(StringID,num,10);
  GetPrivateProfileString("Lang", num, DefaultString,Buff, MAX_PATH, m_LangFileName.c_str());
  
  return ProcessSpecialChar(Buff);
};
//************************************************
