#include "stdafx.h"
#include "ArchiverEngine.h"
#include "ArchiverManager.h"
#include "ArcItem.h"
#include "multiarc.h"

#include "dialogs.h"

#include "resource.h"
#include "utils.h"


const K_Lang_ArchiveEngine = 1100;
const K_Lang_ArchiveEngine_InvalidFormat   = K_Lang_ArchiveEngine + 0;
const K_Lang_ArchiveEngine_Warning         = K_Lang_Warning_String; //K_Lang_ArchiveEngine + 1;
const K_Lang_ArchiveEngine_MultipleEntries = K_Lang_ArchiveEngine + 2;
const K_Lang_ArchiveEngine_ErrorLevel      = K_Lang_ArchiveEngine + 3;
const K_Lang_ArchiveEngine_HigthErrorLevel = K_Lang_ArchiveEngine + 4;

// Some changes was make by: 
// Igor Glucksmann (IG)
// Mateusz Brzostek (MB)

CArchiverEngine::CArchiverEngine(CArchiveDescription *pad,tOpenArchiveData *data,BOOL bCreate)
{
	m_bAlreadyTested=false;
	m_pad=pad;
	m_pDeferedNames=0;
//MB>>
  m_pDestPath = NULL;
  m_pStripPath = NULL;
//MB<<
	strcpy(m_szArcPathName,data->ArcName);
	if(m_pad)
	{
		if(bCreate)
		{
			m_pArcItemsList=NULL;
			m_pCurItem=NULL;
			m_iOpenMode=data->OpenMode;
		}
		else
		{
			if(ParseNExecuteCommand(LISTCMD_IDX))
			{
				AdjustBounds();
				m_pArcItemsList=CArcItem::LoadFromList(m_coList.GetOutputData()+m_iBeginOff,m_iEndOff-m_iBeginOff,m_pad);
				m_pCurItem=(CArcItem *)-1;
				m_iOpenMode=data->OpenMode;
			}
			else
			{
				m_pArcItemsList=NULL;
				m_pCurItem=NULL;
				m_iOpenMode=data->OpenMode;
			}
		}
	}
}

CArchiverEngine::~CArchiverEngine()
{
	delete m_pDeferedNames;
  delete m_pDestPath;
  delete m_pStripPath;
// 02-09-2001: MB: Stack overflow fixed
  while(m_pArcItemsList)
  {
    CArcItem *p = m_pArcItemsList->m_pNext;
    delete m_pArcItemsList;
    m_pArcItemsList = p;
  }
}

void CArchiverEngine::AdjustBounds()
{
	LPCSTR lpList=m_coList.GetOutputData();

	LPCSTR lpStart=m_pad->String(START_IDX);
	LPCSTR lpEnd=m_pad->String(END_IDX);

	m_iBeginOff=0;
	m_iEndOff=lstrlen(lpList);

	if(!lpStart && !lpEnd)
		return;

	LPCSTR lpB=lpList,lpE=lpList;

	if(lpStart)
	{
		char *lpStr=new char[lstrlen(lpStart)+3];
		bool bFromBeg;
		if(bFromBeg=(bool)(*lpStart=='^'))
		{
			lstrcpy(lpStr,"\r\n");
			lstrcat(lpStr,lpStart+1);
		}
		else
			lstrcpy(lpStr,lpStart);

		LPSTR lpBTmp=strstr(lpList,lpStr);
		if(lpBTmp)
		{
			if(bFromBeg)
				lpBTmp+=2;

			while(*lpBTmp && *lpBTmp!='\n')lpBTmp++;
			if(*lpBTmp)
			{
				lpBTmp++;
				m_iBeginOff=lpBTmp-lpList;
			}

				// AIN specific code begin 8-)
			LPCSTR lp=0;
			if(IsArchiveType("AIN"))
			{
				while(*lpBTmp && *lpBTmp!='\n')lpBTmp++;
				if(*lpBTmp)
				{
					lpBTmp++;
					m_iBeginOff=lpBTmp-lpList;
				}
			}
		}
		delete[] lpStr;
	}

	if(lpEnd)
	{
		char *lpStr=new char[lstrlen(lpEnd)+3];
		bool bFromBeg;
		if(bFromBeg=(bool)(*lpEnd=='^'))
		{
			lstrcpy(lpStr,"\r\n");
			lstrcat(lpStr,lpEnd+1);
		}
		else
			lstrcpy(lpStr,lpEnd);

		const char *lpETmp = lpList + m_iBeginOff;
		if (bFromBeg && m_iBeginOff >= 2)
		  lpETmp -= 2;
		lpETmp = strstr( lpETmp, lpStr );

	    if(lpETmp)
		{
			if(!bFromBeg)
				while(lpETmp>lpList && *lpETmp!='\r')lpETmp--;

			if(*lpETmp)
				m_iEndOff=lpETmp-lpList;
		}
		delete[] lpStr;
	}
}
//***************************************************************
int CArchiverEngine::ReadHeader(tHeaderData *hdrData)
{
	if(!m_pArcItemsList)
		return E_END_ARCHIVE;

	if(m_pCurItem == (CArcItem *)-1)
		m_pCurItem=m_pArcItemsList;
	else
	{
		m_pCurItem=m_pCurItem->GetNext();
		if(!m_pCurItem)
			return E_END_ARCHIVE;
	}
	strcpy(hdrData->FileName,m_pCurItem->m_szFilePath);
	hdrData->PackSize=m_pCurItem->m_iPackedSize;
	hdrData->UnpSize=m_pCurItem->m_iUnpackedSize;
	hdrData->FileTime=m_pCurItem->m_iFileTime;
	hdrData->FileAttr=m_pCurItem->m_iFileAttr;
	return 0;
}
//***************************************************************
// returns length of string list NOT including last \0
int lst_strlen(char *str)
{
	int l=0;
	for(char *pp=str;l=strlen(pp);pp+=l+1);
	return (pp - str);
}
//***************************************************************
//MB>>
int StrniCmp( const char *s1, const char *s2, int n )
{
	return 2 - CompareString( LOCALE_USER_DEFAULT, NORM_IGNORECASE|SORT_STRINGSORT, s2, n, s1, n );
}
//***************************************************************
static int MakePaths( char *DestName, char *FileName, char **DestPath, unsigned *lStrip )
{
  char buf[ 260 ], *p, *p1;
  int w, i;

  if( GetFullPathName( DestName, 260, buf, &p ) < 4 )
    return 0;
  p = strchr( buf + 2, '\\' );           // buf starts with 'c:\'
  if( p == NULL )                        // or '\\CompName\DriveName\'
    return 0;
  if( buf[ 0 ] == '\\' )                 // case '\\CompName\DriveName\'
  {
    p = strchr( p + 1, '\\' );
    if( p == NULL )
      return 0;
  }

  p1 = FileName;
  w = strlen( p1 );
  i = strlen( ++p );
  while( w > i )
  {
    p1 = strchr( p1, '\\' );
    if( p1 == NULL )
      return 0;
    w = strlen( ++p1 );
  }
  p += i - w;

  while( w > 0 )
  {
     if( p[ -1 ] == '\\' && StrniCmp( p, p1, -1 ) == 0 )
     {
      i = p - buf;
      *DestPath = (char*)malloc( i + 1 );
      if( *DestPath == NULL )
        return 0;
      memcpy( *DestPath, buf, i );
      (*DestPath)[ i ] = 0;
      *lStrip = p1 - FileName;
      return 1;
    }
    p1 = strchr( p1, '\\' );
    if( p1 == NULL )
      return 0;
    i = strlen( ++p1 );
    p += w - i;
    w = i;
  }

  return 0;
}
//MB<<
//***************************************************************
//MB: a lot of changes in following function ...
bool CArchiverEngine::ExtractFile(LPSTR lpDestPath,LPSTR lpDestName)
{
	if(m_iOpenMode == PK_OM_LIST)
		return true;

   // process not null  lpDestPath
   char tmpStr[MAX_PATH];
   tmpStr[0]=0; 
   if (!lpDestPath)
     strcat(tmpStr, lpDestName);
   else  
   { 
     strcat(tmpStr, lpDestPath);
     if (tmpStr[strlen(tmpStr)] != '\\')
         tmpStr[strlen(tmpStr)] = '\\';
     strcat(tmpStr, lpDestName);
   };
   

	if(m_pad->BatchUnpack())
	{

		if( m_pDeferedNames )
      { 
        int length = lst_strlen( m_pDeferedNames );
        int add_length = strlen( m_pCurItem->m_szFilePath );

        m_pDeferedNames = (char *)realloc( m_pDeferedNames, length + add_length + 2 );
        memcpy( m_pDeferedNames + length, m_pCurItem->m_szFilePath, add_length );
        memset( m_pDeferedNames + length + add_length, 0, 2 );
      }
		else
		{
        int len = strlen( m_pCurItem->m_szFilePath );
        unsigned lStrip;

        m_pDeferedNames = (char *)malloc( len + 2 );
        memcpy( m_pDeferedNames, m_pCurItem->m_szFilePath, len );
        memset( m_pDeferedNames + len, 0, 2 );
        if( MakePaths(tmpStr, m_pCurItem->m_szFilePath, &m_pDestPath, &lStrip ) )
        {
          if( lStrip )
          {
            m_pStripPath = (char*)malloc( lStrip + 1 );
            memcpy( m_pStripPath, m_pCurItem->m_szFilePath, lStrip );
            m_pStripPath[ lStrip ] = 0;
          }
        }
        else
          return false; /// ??????
		}

		return true;
	}

	char szCurPath[MAX_PATH];

	char szFileList[MAX_PATH];
	char szTempFile[MAX_PATH];
	lstrcpy(szTempFile, theArcMan.TempDir());
	strcpy(szFileList,m_pCurItem->m_szFilePath);
	szFileList[lstrlen(szFileList)+1]=0;

	GetCurrentDirectory(MAX_PATH,szCurPath);
	CreateDirectory(szTempFile,0);
	SetCurrentDirectory(szTempFile);

	if(ParseNExecuteCommand(EXTRACT_IDX,szFileList))
	{
		SetCurrentDirectory(szCurPath);

		char szFNameExt[_MAX_FNAME];
		char szFName[_MAX_FNAME];
		char szFExt[_MAX_EXT];
		_splitpath(m_pCurItem->m_szFilePath,0,0,szFName,szFExt);
		_makepath(szFNameExt,0,0,szFName,szFExt);
		lstrcat(szTempFile,"\\");
		lstrcat(szTempFile,szFNameExt);

		LPSTR lpFileNameTo= tmpStr; //lpDestName;

		if(!lpFileNameTo)
		{
			if(lpDestPath)
				lstrcpy(szCurPath,lpDestPath);

			lstrcat(szCurPath,"\\");
			lstrcat(szCurPath,szFNameExt);
			lpFileNameTo=szCurPath;
		}

		char szPath[MAX_PATH];	
		char szDrive[_MAX_DRIVE];	
		char szPathNDrive[MAX_PATH];	
		_splitpath(lpFileNameTo,szDrive,szPath,0,0);
		_makepath(szPathNDrive,szDrive,szPath,0,0);
		
		int iLen=lstrlen(szPathNDrive);
		for(int i=0;i<iLen;i++)
		{
			if(szPathNDrive[i]=='\\')
			{
				szPathNDrive[i]=0;
				if(GetFileAttributes(szPathNDrive)==0xFFFFFFFF)
					CreateDirectory(szPathNDrive,0);
				szPathNDrive[i]='\\';
			}
		}

		MoveFile(szTempFile,lpFileNameTo);
		return true;
	}
	return false;
}
//***************************************************************
bool CArchiverEngine::TestArchive()
{
	if(!m_bAlreadyTested)
	{
		//CConsoleOutput co(m_pad->Debug());
		if(ParseNExecuteCommand(TEST_IDX))
			m_bAlreadyTested=true;
		else
			return false;
	}
	return true;
}
//***************************************************************
bool CArchiverEngine::DeleteFiles(char *DeleteList)
{
	int iAICount=0;
	for(CArcItem *p=m_pArcItemsList;p->m_pNext;iAICount++,p=p->m_pNext);

	int patcnt=0,l,idx=0;
	for(char *pp=DeleteList;l=strlen(pp);patcnt++,pp+=l+1);

	char **pattarray=new char *[iAICount+patcnt+1];
	ZeroMemory(pattarray,sizeof(char *)*(iAICount+patcnt+1));
	
	while(DeleteList && *DeleteList)
	{
		int iLen=lstrlen(DeleteList);
		if(!lstrcmp(DeleteList+iLen-3,"*.*"))
		{
			p=m_pArcItemsList;
			while(p)
			{
				if(!StrniCmp(p->m_szFilePath,DeleteList,iLen-3))
					pattarray[idx++]=p->m_szFilePath;
				p=p->m_pNext;
			}
		}
		else
			pattarray[idx++]=DeleteList;

		DeleteList+=lstrlen(DeleteList)+1;
	}

	int iListLen=0;
	for(idx=0;pattarray[idx];iListLen+=lstrlen(pattarray[idx++])+1);

	char *pRealDeleteList=new char[iListLen+1];
	ZeroMemory(pRealDeleteList,iListLen+1);

	pp=pRealDeleteList;
	for(idx=0;pattarray[idx];strcpy(pp,pattarray[idx]),pp+=lstrlen(pattarray[idx++])+1);
	*pp=0;

	bool bRet=(ParseNExecuteCommand(DELETE_IDX,pRealDeleteList));
	
	delete[] pRealDeleteList;
	delete[] pattarray;

	return bRet;
}
//***************************************************************
bool CArchiverEngine::PackFiles(char *szSubPath, char *szSrcPath, char *AddList, int Flags)
{
	char szCurPath[MAX_PATH];
	GetCurrentDirectory(MAX_PATH,szCurPath);

	if(szSrcPath)
		SetCurrentDirectory(szSrcPath);
  //02-09-2001 : MB : added support for packing to directories in archive
  m_SubPath = szSubPath;

	bool bRet=ParseNExecuteCommand((Flags&PK_PACK_MOVE_FILES)?MOVE_IDX:ADD_IDX,AddList);

	SetCurrentDirectory(szCurPath);
	return bRet;
}
//***************************************************************
void Modify(char *szAdd,const char *lpStr,char **p)
{
	int i=0;
	while((*p)[i] && !isspace((*p)[i]) && (*p)[i]!='}')i++;
	char sz[10];
	strncpy(sz,*p,i);
	sz[i]=0;
	*p+=i;

	char szTmp[MAX_PATH];
	strcpy( szTmp, lpStr ? lpStr : "" );

	if(strchr(sz,'W') || strchr(sz,'P'))
	{
		char szPath[MAX_PATH],szName[_MAX_FNAME],szExt[_MAX_EXT];
		_splitpath(szTmp,0,szPath,szName,szExt);
		if(strchr(sz,'P'))
			_makepath(szTmp,0,szPath,0,0);
		else
			_makepath(szTmp,0,0,szName,szExt);
	}

	if(strchr(sz,'q') || (strchr(sz,'Q') && strchr(szTmp,' ')))
	{
		strcpy(szAdd,"\\\"");
		strcat(szAdd,szTmp);
		strcat(szAdd,"\\\"");
	}
	else
		strcpy(szAdd,szTmp);

	if(!strchr(sz,'A'))
		CharToOem(szAdd,szAdd);
}
//***************************************************************
DWORD SafeGetShortPathName(LPCTSTR lpszLongPath,LPTSTR lpszShortPath,DWORD cchBuffer)
{
	int ifile=-1;
	if(_access(lpszLongPath,0) == -1)
		ifile=_open(lpszLongPath,_O_CREAT,_S_IREAD|_S_IWRITE);

	DWORD dwRet=GetShortPathName(lpszLongPath,lpszShortPath,cchBuffer);

	if(ifile!=-1)
	{
		_close(ifile);
		_unlink(lpszLongPath);
	}

	return dwRet;
}
//***************************************************************                         
bool CArchiverEngine::ParseNExecuteCommand(int idx, LPCSTR lpFileOrList)
{
  LPCSTR lpFmtStr=m_pad->String(idx);

  if(!lpFmtStr)
  {
    MessageBox(GetFocus(), theArcMan.LangSupport.Strings(K_Lang_ArchiveEngine_InvalidFormat, 
        "Format string for this command is not defined. Current command can't be executed. "
		  "Check you multiarc.ini settings for this archiver type.").c_str(),
        theArcMan.LangSupport.Strings(K_Lang_ArchiveEngine_Warning, WARNING_STR_CONST /*"Warning" */).c_str(),MB_ICONWARNING);
	 return false;
  }

  LPCSTR lpArchiver=m_pad->String(ARCHIVER_IDX);

  // expand possible environment strings ...
  char ArchiverBuf[MAX_PATH];
  ExpandEnvironmentStrings(lpArchiver, ArchiverBuf, MAX_PATH);
  lpArchiver=ArchiverBuf;
  char *pszCommand=new char[MAX_PATH*2];
  int idxCmd=0;
  int iErrorLevel=0;
  char *p=(char *)lpFmtStr;
  char *apFileListMod[2];
  BOOL bShort=FALSE;
  BOOL bList=FALSE;
  char cMod=0;
  int iflmIdx=0;
  bool bAvoidOem2Ansi=false;
  bool bShowConsole = false;

  bool bHasNonEmptyFields = false;
  int idxBraceBegin = -1;
  int nAskForParamsCount = 0;

  // 9-2-01 : IG : fix AV when this stay uninitialized 
  apFileListMod[0] = NULL;

  while(*p)
  {
    char ch=*p++;
    switch(ch)
	 {
      case '%':
      {
		  char szAdd[MAX_PATH];
		  szAdd[0]=0;
		  ch=*p++;
		  switch(ch)
		  {
          // 02-09-2001: MB : support for adding files to subdirectory
			 case 'R':
			   Modify(szAdd,m_SubPath,&p);
            if(m_SubPath && m_SubPath[0])
            bHasNonEmptyFields = true;
				break;
          // MB: end
			 case 'P':
			   Modify(szAdd,lpArchiver,&p);
			   break;
			 case 'p':
			   GetShortPathName(lpArchiver,szAdd,MAX_PATH);
			   Modify(szAdd,szAdd,&p);
			   break;
			 case 'A':
			   Modify(szAdd,m_szArcPathName,&p);
			   break;
			 case 'a': 
			   SafeGetShortPathName(m_szArcPathName,szAdd,MAX_PATH);
			   Modify(szAdd,szAdd,&p);
			   break;
			 case 'L':case 'l':case 'F':case 'f':
			   if(iflmIdx<2)
			   {
				  bList=(ch =='L' || ch == 'l');
				  bShort=(ch == 'l' || ch == 'f');
				  pszCommand[idxCmd++]='%';
				  pszCommand[idxCmd++]='s';
				  pszCommand[idxCmd]=0;
				  apFileListMod[iflmIdx++]=p;
			   }
			   else
              MessageBox(GetFocus(), theArcMan.LangSupport.Strings(K_Lang_ArchiveEngine_MultipleEntries,
              "You specified multiple entries for file/filelist for this command. Only first one will be accepted."
              "To avoid this message remove extra file/filelist entries from format string.").c_str(),
              theArcMan.LangSupport.Strings(K_Lang_ArchiveEngine_Warning, WARNING_STR_CONST /*"Warning"*/).c_str(), MB_ICONWARNING);

				  while(*p && !isspace(*p))p++;
				  continue;
			 case 'E':
			   iErrorLevel=atoi(p);
			   while(*p && !isspace(*p))p++;
			   continue;
			 case 'O':
			   bAvoidOem2Ansi=true;
			   while(*p && !isspace(*p))p++;
			   continue;
			 case 'C':
			   bShowConsole=true;
			   while(*p && !isspace(*p))p++;
			   continue;
          case 'S':
            if( m_pad->GetValidSParam() &&
               !(m_pad->SParamValidSkipLIST() && idx == LISTCMD_IDX))
            {
              string tmpStr;
              nAskForParamsCount ++;
              if (GetSParamUserChoice(idx, nAskForParamsCount, m_pad, tmpStr))
              {
                Modify(szAdd, tmpStr.c_str(), &p);
                bHasNonEmptyFields = true;
                break;
              }
            }
            //skip possible modificators
            while(*p && !isspace(*p) && *p!='}') p++;
            break;
			 case '\0':
			   p--;
			   continue;
         }

			if(szAdd[0])
			{
			  strcpy(pszCommand+idxCmd,szAdd);
			  idxCmd+=strlen(szAdd);
			}
		 }
       break;

    case '{':
      idxBraceBegin = idxCmd;
      bHasNonEmptyFields = false;
      break;

    case '}':
      if(idxBraceBegin >= 0 && !bHasNonEmptyFields)
          idxCmd = idxBraceBegin;
      break;

    default:
			pszCommand[idxCmd++]=ch;
      break;
    }
	}
	pszCommand[idxCmd]=0;

	char szCurPath[MAX_PATH];
	GetCurrentDirectory(MAX_PATH,szCurPath);

	bool bRet=true;
	if(idx == LISTCMD_IDX || idx == TEST_IDX)
	{
		m_coList.SetOemConversion(!bAvoidOem2Ansi);
    m_coList.SetShowConsole(bShowConsole);
    m_coList.SetCommandIdx(idx);
		int iRet=m_coList.ExecuteCommand(pszCommand,m_pad->String(INPUT_IDX), iErrorLevel+1);
		m_pad->DebugOutput(pszCommand,m_coList.GetOutputData(),iRet,szCurPath);
		if(!m_pad->IgnoreErrors())
		{
			if(iRet == -1 || iRet > iErrorLevel)
			{
           string sz = theArcMan.LangSupport.Strings(K_Lang_ArchiveEngine_ErrorLevel,
             "Executing command ' %1!s! ' returned errorlevel %2!d!. "
             "Possibly an error occure. Archive listing wasn't retrieved.");
           sz = ExpandParam(sz, pszCommand,iRet);
//				static char sz[MAX_PATH*2];
//        wsprintf(sz,"Executing command ' %s ' returned errorlevel %d. "
//          "Possibly an error occure. Archive listing wasn't retrieved.",pszCommand,iRet);
        MessageBox(GetFocus(),sz.c_str(), theArcMan.LangSupport.Strings(K_Lang_ArchiveEngine_Warning, WARNING_STR_CONST /*"Warning"*/).c_str(), MB_ICONWARNING);
				bRet=false;
			}
		}
	}
	else
	{
		char *pCurFile=(char *)lpFileOrList;
		do{
			static char szListPath[MAX_PATH];
			szListPath[0]=0;
			static char sz_UglyPath[MAX_PATH];
			static char sz_UglyPath2[MAX_PATH];
			char *pszCommand2=new char[MAX_PATH*2];
			char *pAlmostName=0;
			if(bList)
			{
				GetTempFileName(theArcMan.TempDir(), "lst",0,szListPath);
				HANDLE hFile=CreateFile(szListPath,GENERIC_WRITE,FILE_SHARE_READ,
										0,CREATE_ALWAYS,FILE_ATTRIBUTE_NORMAL,0);
				for(char *pp=(char *)lpFileOrList;*pp;pp+=lstrlen(pp)+1)
				{
					if(!(m_pad->SkipDirsInFileList() && pp[lstrlen(pp)-1] == '\\'))
					{
						DWORD dwWritten;
						if(bShort)
						{
							static char path[MAX_PATH];
							if(!SafeGetShortPathName(pp,path,MAX_PATH))
								strcpy(path,pp);
							WriteFile(hFile,path,lstrlen(path),&dwWritten,0);
						}
						else
						{
							static char anotherPath[MAX_PATH];
							if(strchr(apFileListMod[0],'q') || (strchr(apFileListMod[0],'Q') && strchr(pp,' ')))
								wsprintf(anotherPath,"\"%s\"",pp);
							else
								strcpy(anotherPath,pp);

							if(!strchr(apFileListMod[0],'A'))
								CharToOem(anotherPath,anotherPath);

							WriteFile(hFile,anotherPath,lstrlen(anotherPath),&dwWritten,0);
						}

						WriteFile(hFile,"\r\n",2,&dwWritten,0);
					}
				}
				CloseHandle(hFile);
				pAlmostName=szListPath;
			}
			else
			{
				if(bShort)
				{
					GetShortPathName(pCurFile,sz_UglyPath,MAX_PATH);
					pAlmostName=sz_UglyPath;
				}
				else
					pAlmostName=pCurFile;
				
				pCurFile+=lstrlen(pCurFile)+1;
			}

			char *pp=apFileListMod[0];

      if(pp)
			  Modify(sz_UglyPath2,pAlmostName,&pp);

			if(iflmIdx==2)
			{
				static char sz_UglyPath3[MAX_PATH];
				pp=apFileListMod[1];
				Modify(sz_UglyPath3,pAlmostName,&pp);
				wsprintf(pszCommand2,pszCommand,sz_UglyPath2,sz_UglyPath3);
			}
			else
				wsprintf(pszCommand2,pszCommand,sz_UglyPath2);

			CConsoleOutput co(m_pad->Debug());
			co.SetOemConversion(!bAvoidOem2Ansi);
         co.SetShowConsole(bShowConsole);
         co.SetCommandIdx(idx);

			int iRet=co.ExecuteCommand(pszCommand2,m_pad->String(INPUT_IDX), iErrorLevel+1);
			m_pad->DebugOutput(pszCommand2,co.GetOutputData(),iRet,szCurPath);

			if(szListPath[0] && !m_pad->Debug())
				DeleteFile(szListPath);

			if(!m_pad->IgnoreErrors())
			{
				if(iRet == -1 || iRet > iErrorLevel)
				{
              string sz = theArcMan.LangSupport.Strings(K_Lang_ArchiveEngine_HigthErrorLevel,
                "Executed command ' %1!s! ' returned errorlevel %2!d!, "
                "wich is higher than configured as normal for this command. "
                "Probably error occure. Check your configuration, please...");
              sz = ExpandParam(sz, pszCommand2,iRet);
              MessageBox(GetFocus(),
              sz.c_str(),
              theArcMan.LangSupport.Strings(K_Lang_ArchiveEngine_Warning, WARNING_STR_CONST /* "Warning"*/ ).c_str(),
              MB_ICONWARNING);
				  bRet=false;
				}
			}
			delete[] pszCommand2;

		}while(!bList && *pCurFile);
	}

	delete[] pszCommand;

  if(m_pad->GetValidSParam() == eSParamNext)
  { 
    if(!(idx == LISTCMD_IDX && m_pad->SParamValidSkipLIST() ))
    {
      WritePrivateProfileInt(m_pad->String(TYPENAME_IDX), INI_KEY_SPARAM_MODE, eSParamNone, theArcMan.IniFile());
      m_pad->SetValidSParamMode(eSParamNone);
    }
  }

	return bRet;
}
//***************************************************************
bool CArchiverEngine::IsArchiveType(LPCSTR lpcType)
{
	LPCSTR lp=0;
	return (lp=m_pad->String(TYPENAME_IDX)) && !strcmp(lp,lpcType);
}
//***************************************************************
//MB>>
static int MakeDir( char *Path )
{
  int l;
  char buf[ 260 ], *p;

  l = GetFullPathName( Path, 260, buf, &p );  // t/k\../z\a.c => c:\t\z\a.c
  if( l < 3 )                                 // min 'c:\'
    return 0;
  if( p )                                     // exclude file part
  {
    p[ 0 ] = 0;
    l = p - buf;
  }
  if( l < 3 || buf[ l - 1 ] != '\\' )         // min 'c:\' and ends at '\'
    return 0;
  p = strchr( buf + 2, '\\' );                // buf starts with 'c:\'
  if( p == NULL )                             // or '\\CompName\DriveName\'
    return 0;
  if( buf[ 0 ] == '\\' )                      // case '\\CompName\DriveName\'
  {
    p = strchr( p + 1, '\\' );
    if( p == NULL )
      return 0;
  }

  l = 0;
  while( (p = strchr( p + 1, '\\' )) != NULL )
  {
    p[ 0 ] = 0;
    l = _mkdir( buf );
    p[ 0 ] = '\\';
  }

  if( l == -1 && (errno == EEXIST || errno == EACCES) )
    l = 0;
  return l + 1;
}
//***************************************************************
static void move_files( char *tmp, char *StripPath, char *DestPath )
{
  SHFILEOPSTRUCT shF;
  char buf[ MAX_PATH + 1 ];

  strcpy( buf, tmp );
  strcat( buf, "\\" );
  strcat( buf, StripPath );
  strcat( buf, "*.*" );
  buf[ strlen( buf ) + 1 ] = 0;
  shF.hwnd = NULL;
  shF.wFunc = FO_MOVE;
  shF.pFrom = buf;
  shF.pTo = DestPath;
  shF.fFlags = FOF_NOCONFIRMATION | FOF_SILENT | FOF_NOCONFIRMMKDIR;
  SHFileOperation( &shF );
}

static void delete_files( char *tmp )
{
  SHFILEOPSTRUCT shF;
  char buf[ MAX_PATH + 1 ];

  strcpy( buf, tmp );
  buf[ strlen( buf ) + 1 ] = 0;
  shF.hwnd = NULL;
  shF.wFunc = FO_DELETE;
  shF.pFrom = buf;
  shF.fFlags = FOF_NOCONFIRMATION | FOF_SILENT;
  SHFileOperation( &shF );
}
//MB<<

bool CArchiverEngine::OnClose()
{
	  bool bRet;

	if(m_pad->BatchUnpack() && m_pDeferedNames)
	{
    char szCurPath[ MAX_PATH ], *tmp;
		GetCurrentDirectory(MAX_PATH,szCurPath);
    m_SubPath = m_pStripPath;

		if( m_pStripPath )
    {
      if (strstr( m_pad->String( EXTRACT_WITH_PATH_IDX ), "%R" ))
      {
        if (!MakeDir( m_pDestPath ))
          return false; // ???? for waht ????
        SetCurrentDirectory( m_pDestPath );
        *strrchr( m_SubPath, '\\' ) = 0;
        bRet = ParseNExecuteCommand( EXTRACT_WITH_PATH_IDX, m_pDeferedNames );
        SetCurrentDirectory( szCurPath );
        return bRet;
      }

      tmp = _tempnam( theArcMan.TempDir(), "" );

      if( tmp == NULL )
        return false;

      if( _mkdir( tmp ) != 0 )
      {
        free( tmp );
        return false;
      }

      SetCurrentDirectory( tmp );
    }
    else
    {
      if( !MakeDir( m_pDestPath ) )
        return false; // ???? for waht ????
      SetCurrentDirectory( m_pDestPath );
    }

		bRet=ParseNExecuteCommand(EXTRACT_WITH_PATH_IDX,m_pDeferedNames);

    if( m_pStripPath )
    {
      if( bRet )
      {
        move_files( tmp, m_pStripPath, m_pDestPath );
        delete_files( tmp );
      }
      free( tmp );
    }

		SetCurrentDirectory(szCurPath);
		return bRet;
	}

	return true;
}
