#ifndef _MULTIARC_H_
  #define _MULTIARC_H_


#include "wcxhead.h"

extern tProcessDataProc pProcessDataProc;

#define BUFFER_SIZE  65536	/*	4096 */
//int BUFFER_SIZE =65536;	/*	4096 */

//section in multiarc.ini with general settings ... 
#define INI_SECTION_SETUP      "MultiArc"

#define INI_KEY_SPARAM_MODE    "AskMode"
#define CTRL_BREAK_EVENT_NAME  "CtrlBreakEvent"

#define WARNING_STR_CONST  "Warning"

const K_Lang_Warning_String =3;
const K_Lang_Error_String = 4;

extern char aKeyNames[][19];


#endif //_MULTIARC_H_
