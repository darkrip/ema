#include "stdafx.h"
#include "ArchiverManager.h"
#include "multiarc.h"

LPSTR GetErrorMessage()
{
  LPVOID lpMsgBuf;
  FormatMessage(FORMAT_MESSAGE_ALLOCATE_BUFFER|FORMAT_MESSAGE_FROM_SYSTEM|FORMAT_MESSAGE_IGNORE_INSERTS,
    NULL,GetLastError(),MAKELANGID(LANG_NEUTRAL, SUBLANG_DEFAULT), // Default language
    (LPTSTR) &lpMsgBuf,0,NULL);
  return (LPSTR)lpMsgBuf;
}

char * GetWCXVersion(char * lpc)
{
  char modulePath[_MAX_PATH];
  void *pData=NULL;
  DWORD  handle;
  DWORD  dwSize;
  char   szName[512];
  char *lpBuffer;
  char *iRet=NULL;

  if(GetModuleFileName(theArcMan.Instance(),modulePath,_MAX_PATH))
  {
    dwSize = GetFileVersionInfoSize(modulePath, &handle);
    if(dwSize)
    {
      pData=malloc(dwSize);
      GetFileVersionInfo(modulePath, handle, dwSize, pData);
      VerQueryValue(pData, "\\VarFileInfo\\Translation", (void **)&lpBuffer, (unsigned int *)&dwSize);
      if (dwSize!=0)
      {
        wsprintf(szName, "\\StringFileInfo\\%04X%04X\\FileVersion",*((LPWORD)lpBuffer),*((LPWORD)(lpBuffer)+1));
        VerQueryValue(pData, szName, (void **)&lpBuffer, (unsigned int*)&dwSize);
        iRet=lpc;
        lstrcpy(lpc,lpBuffer);
      }
    }
  }

  if(pData)
  {
    free(pData);
    pData=NULL;
  }

  return iRet;
}

int HexVal(char c)
{
  if(isupper (c))
    c = tolower (c);
  if(isdigit (c))
    return (c - '0');  /* '0'..'9' */
  return (c - 'a' + 10);    /* 'a'..'f' */
}

BOOL WritePrivateProfileInt(const char *section, const char *key, int iValue, const char *ini_file)
{
  const int cnBufSize = 10;  
  char buf[cnBufSize];
  return WritePrivateProfileString(section, key, itoa(iValue, buf, cnBufSize), ini_file);
}

string ExpandParam(string Mask, ...)
{
  va_list argList;
  va_start(argList, Mask);
  LPTSTR lpszTemp;
  // Format message into temporary buffer lpszTemp
  if (::FormatMessage(FORMAT_MESSAGE_FROM_STRING|FORMAT_MESSAGE_ALLOCATE_BUFFER,
		                    Mask.c_str(), 0, 0, (LPTSTR)&lpszTemp, 0, &argList) == 0) 
	  {
        return "";
//		  AfxThrowMemoryException();
	  }
  string Result = lpszTemp;
  LocalFree(lpszTemp);
  va_end(argList);
  return Result; 
}

