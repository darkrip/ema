#ifndef _ARCHIVEDESCRIPTION_H_
	#define _ARCHIVEDESCRIPTION_H_


#define TYPENAME_IDX 		   0
#define ARCHIVER_IDX	   	   1
#define LISTCMD_IDX     	   2
#define START_IDX		         3
#define END_IDX			      4
#define EXTRACT_IDX	         5
#define EXTRACT_WITH_PATH_IDX	6
#define TEST_IDX		         7
#define DELETE_IDX	         8
#define ADD_IDX		         9
#define MOVE_IDX		        10
#define INPUT_IDX		        11
#define DESCRIPT_IDX	        12

#define STRINGS_COUNT	     21

enum eSParamMode
{
  eSParamNone    = 0,
  eSParamNext    = 1,
  eSParamAlways  = 2
};

typedef vector<unsigned char >  Signature_ID_Type;

typedef vector <int>                    poses_vector;
typedef poses_vector::iterator         poses_iterator;                  

typedef vector<vector<unsigned char> > ids_vector;
typedef ids_vector::iterator           ids_iterator;


struct ExcludeID_Struct
{
  bool isAbsolute ;
  int offset; 
  Signature_ID_Type  ID;
};

typedef vector<ExcludeID_Struct >     ExcludeIDs_vector;
typedef ExcludeIDs_vector::iterator  ExcludeIDs_iterator;


struct wcmd_ext{
  wcmd_ext(): active(false), caps(PK_CAPS_NEW | PK_CAPS_MODIFY |
                                  PK_CAPS_MULTIPLE | PK_CAPS_DELETE |
                                  PK_CAPS_BY_CONTENT),is_modified(false) {}
  string        ext;
  bool          active;
  unsigned long caps;
  bool          is_modified;
};

typedef vector<wcmd_ext>       exts_vector;
typedef exts_vector::iterator  exts_iterator;

typedef map<int, string>               strings_map;
typedef strings_map::iterator          strings_iterator;

typedef vector<string>                 strings_vector;
typedef strings_vector::iterator       strings_vector_iterator;

class CArchiveDescription
{
  poses_vector m_poses;
  ids_vector   m_ids;
  exts_vector  m_exts;
  strings_map  m_strings;
  strings_vector m_formats;
  ExcludeIDs_vector m_ExcludeIDs;

  BOOL  m_bIgnoreErrors;
  BOOL  m_bDebug;
  BOOL  m_bUnixPath;
  BOOL  m_bSkipEmpty;
  BOOL  m_bSkipDirsInFileList;
  BOOL  m_bBatchUnpack;
  BOOL  m_bSearchForUglyDirs;
  
  BOOL  m_bRealEntry;
  BOOL  m_SkipSFXPart;
  BOOL  m_SeekAfterIDPos; // if defined, seek ID in raw fale.
  int   m_IDSeekVolumeSize; // range to seek ID if defined "<SeekID>" or not exist IDPOS
  void ReleaseContents();
  void LoadString(const char *szKeyName, int iStrIdx, const char *szIniPath);
  void LoadFormats(const char *szTypeKeyName, const char *szIniPath);
 
  template< class T> bool CheckRange(int idx, const vector<T> &v) const
  {
    return idx >= 0 && idx < v.size();
  }
  
  eSParamMode m_eSParam;
  BOOL  m_bSParamSkipLIST;

public:
	int FormatHeight(){	return m_formats.size(); }

	CArchiveDescription();
	~CArchiveDescription(){ ReleaseContents(); }

  int		IDPos(int idx) const
          { return CheckRange(idx, m_poses) ? m_poses[idx] : 0; }
  int		IDSize(int idx) const
          { return CheckRange(idx , m_ids) ? m_ids[idx].size() : 0; }	
  const unsigned char *	GetID(int idx) const
          { return CheckRange(idx , m_ids) ? &m_ids[idx][0] : NULL; }
  BOOL	IDAtEnd(int idx) const
          { return CheckRange(idx , m_poses) ? (m_poses[idx] < 0) : FALSE; }
  
  int   IDPosesCount() const { return m_poses.size(); }
  int   IDsCount() const { return m_ids.size(); }

  int   ExtsCount() const { return m_exts.size(); }
  LPCSTR GetExt(int idx) const { return CheckRange(idx , m_exts) ? m_exts[idx].ext.c_str() : NULL; }
  bool  IsExtActive(int idx) const { return CheckRange(idx , m_exts) ? m_exts[idx].active : false; }

  BOOL IgnoreErrors() const {return m_bIgnoreErrors;}
  bool Debug()const {return m_bDebug == TRUE;}
  BOOL ConverFromUnixPath()const {return m_bUnixPath;}
  BOOL SkipDirsInFileList()const{return m_bSkipDirsInFileList;}
  BOOL SkipEmpty()const {return m_bSkipEmpty;}
  BOOL BatchUnpack();// {return m_bBatchUnpack;}
  BOOL SearchForUglyDirs() const {return m_bSearchForUglyDirs;}
  BOOL IsRealEntry() const {return m_bRealEntry;}
  BOOL SkipSFXPart() const {return m_SkipSFXPart;}
    // get SParams for this object
  eSParamMode GetSParam() const { return m_eSParam; }
  BOOL SParamSkipLIST() const { return m_bSParamSkipLIST; }
    // get "valid" SPArams - if local are invalid - get ones from global object 
  eSParamMode GetValidSParam() const;
  BOOL SParamValidSkipLIST() const;
  void SetValidSParamMode(eSParamMode espm);

  LPCSTR	String(int idx) const;// { return m_strings[idx]; }
  LPCSTR	Format(int idx) const {   return CheckRange(idx, m_formats) ? m_formats[idx].c_str() : NULL; }

  BOOL Load(char *szSectionName, const char *szIniFileName);
  void DebugOutput(LPCSTR szCommand, LPCSTR lpOutput,int errorlevel=0,LPCSTR lpCurDir=NULL);

  void SetSParams(int sepMode, BOOL bSkipLIST);
  void SetProgramPath(const char *path);
  void SaveChanges();
  void MachGanzNeu(bool bNeu) { m_bIstGanzNeu = bNeu; }
  void MachGestorben(bool bGestorben) { m_bIstGestorben = bGestorben; }
  bool IstGestorben() { return m_bIstGestorben; }
  bool IsRegistered() const;// { return m_bRegistered; }
  bool HasChanges();
  void SetExtActive(int idx, bool bIsActive)
    {if(CheckRange(idx , m_exts)) { m_exts[idx].active = bIsActive; m_exts[idx].is_modified = true; }}
  void SetExtCaps(int idx, unsigned int caps)
    {if(CheckRange(idx , m_exts)) { m_exts[idx].caps = caps; m_exts[idx].is_modified = true; }}
  unsigned int GetExtCaps(int idx){return CheckRange(idx , m_exts) ? m_exts[idx].caps : 0;}
  BOOL SeekAfterIDPos() {return m_SeekAfterIDPos;}
  int IDSeekVolumeSize() {return m_IDSeekVolumeSize;}

  // Exclude ID 
  int   ExcludeIDsCount() const { return m_ExcludeIDs.size(); }
  const ExcludeID_Struct * GetExcludeID(int idx) const
      { return CheckRange(idx , m_ExcludeIDs) ? &m_ExcludeIDs[idx] : NULL; }
  void LoadExcludeIDs(char *szSectionName, const char *szIniPath);

  int ExcludeID_Size(int idx) const
          { return CheckRange(idx , m_ExcludeIDs) ? m_ExcludeIDs[idx].ID.size() : 0; }	
                                          
//  const unsigned char *	GetExcludeID(int idx) const
//          { return CheckRange(idx , m_ExcludeIDs) ? &m_ExcludeIDs[idx][0] : NULL; }

private:
  bool m_bUserWarned;
  bool m_bIsModified;
  bool m_bIstGanzNeu;
  bool m_bIstGestorben;
  char m_szDebugOutputPath[MAX_PATH];
//  void GetIDFromString(string &str, Signature_ID_Type &Output);
//	int m_iFormatHeight;
};
#endif //_ARCHIVEDESCRIPTION_H_