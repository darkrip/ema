#include "stdafx.h"
#include "multiarc.h"
#include "utils.h"
#include "ConsoleOutput.h"
#include "MAConsole.h"

MAConsole theMAConsole;
const K_Lang_CosoleOutputFileNotFound = 1200;

CConsoleOutput::CConsoleOutput(bool bSaveList)
{
	m_bSaveList=bSaveList;
	m_hFile=NULL;
	m_hFileMap=NULL;
	m_lpData=NULL;
	m_bDoOemConversion=true;
  m_nIdx = LISTCMD_IDX;
}

void CConsoleOutput::FlushOutPipe(HANDLE hReadPipe, HANDLE hOutFile, bool bLoop /*= false*/)
{
  const int cnBuffSize = 256;
  char buff[cnBuffSize + 1];
  do
  {
    DWORD dwReaded = 0;
    if(ReadFile(hReadPipe, buff, cnBuffSize, &dwReaded, 0) && dwReaded)
    {
      buff[dwReaded] = 0;
      DWORD dwWritten = 0;
      WriteFile(hOutFile, buff, dwReaded, &dwWritten, 0);
      if(m_bDoOemConversion)
			  OemToChar(buff, buff);
      theMAConsole.Text(buff, SF_TEXT);
    }
    else
      break;
  }while(bLoop);
}

int CConsoleOutput::ExecuteCommand(LPCSTR lpCommand,LPCSTR lpInput, int MaxErrorLevel)
{

  struct _stat st;
  char cmdbuf[1024];
  wsprintf(cmdbuf,"%sconspawn.pipe", theArcMan.MADir());

  if(_stat(cmdbuf, &st) == -1 && errno == ENOENT)
  {
    MessageBox(GetFocus(), ExpandParam(theArcMan.LangSupport.Strings(K_Lang_CosoleOutputFileNotFound, "File not found: \"%1!s!\""), cmdbuf).c_str(),
        theArcMan.LangSupport.Strings(K_Lang_Error_String, "Error").c_str(),0);

    return MaxErrorLevel;
  }

  SECURITY_ATTRIBUTES sa          = {0};
  STARTUPINFO         si          = {0};
  PROCESS_INFORMATION pi          = {0};
  HANDLE              hPipeInputRead   = NULL;
  HANDLE              hPipeInputWrite  = NULL;
  HANDLE              hPipeOutputRead   = NULL;
  HANDLE              hPipeOutputWrite  = NULL;
  BOOL                bTest = 0;
  DWORD               dwNumberOfBytesRead = 0;

	ReleaseContents();

  sa.nLength = sizeof(sa);
  sa.bInheritHandle = TRUE;
  sa.lpSecurityDescriptor = NULL;

	char path[MAX_PATH];
	char name[MAX_PATH];
	GetTempPath(MAX_PATH,path);
	GetTempFileName(path,"zha",0,name);
	m_hFile=CreateFile(name,GENERIC_READ|GENERIC_WRITE,NULL,&sa,CREATE_ALWAYS,
								FILE_ATTRIBUTE_TEMPORARY|FILE_FLAG_RANDOM_ACCESS|
								FILE_FLAG_DELETE_ON_CLOSE,NULL);

    // Create pipe for standard input redirection.
  CreatePipe(&hPipeInputRead,&hPipeInputWrite,&sa,0);

	if(lpInput)
	{
		DWORD dw;
		WriteFile(hPipeInputWrite,lpInput,lstrlen(lpInput),&dw,0);
	}

    // Create pipe for standard output redirection.
  CreatePipe(&hPipeOutputRead, &hPipeOutputWrite, &sa, 0);

      // Make child process use hFile as standard out,
      // and make sure it does not show on screen.
  si.cb = sizeof(si);
  si.dwFlags     = STARTF_USESHOWWINDOW | STARTF_USESTDHANDLES;
  si.wShowWindow = SW_HIDE; 
  si.hStdInput   = hPipeInputRead;
 
  bool bRedirectConsole = (theArcMan.CMode() != cmNever) && 
                              !(m_nIdx == LISTCMD_IDX && theArcMan.CExclude()); 

  if(bRedirectConsole)
  {
    si.hStdOutput  = hPipeOutputWrite;
    si.hStdError   = hPipeOutputWrite;
  }
  else
  {
    si.hStdOutput  = m_hFile;
    si.hStdError   = m_hFile;
  }

  wsprintf(cmdbuf,"%sconspawn.pipe \"%s\"", theArcMan.MADir(), lpCommand);
  int ExitCode=0;

  if(bRedirectConsole)
  {
    theMAConsole.OnExecuteCommand(true, m_bShowConsole);
    theMAConsole.Header("Running Command:", true);
    theMAConsole.Header(lpCommand, false);
    theMAConsole.Header("\n\n",true);
  }
  SetFilePointer(m_hFile,0,0,FILE_BEGIN);

  if(!CreateProcess(NULL,cmdbuf,NULL,NULL,TRUE,0/*CREATE_NEW_PROCESS_GROUP*/,NULL,NULL,&si,&pi))
  {
    LPSTR lpError=GetErrorMessage();
	 char sz[1024];
	 wsprintf(sz,"CONSPAWN.PIPE running error : %s",lpError);
	 MessageBox(GetFocus(),sz,"Error",MB_ICONSTOP);
	 LocalFree(lpError);
	 ExitCode=MAEL_CANT_CREATE_PROCESS;
  }
  
  // Now that handles have been inherited, close it to be safe.
  // You don't want to read or write to them accidentally.
  CloseHandle(hPipeInputRead);
  CloseHandle(hPipeOutputWrite);
  CloseHandle(pi.hThread);

  int iCon=100000;
  // Wait for CONSPAWN to finish.
  while(WaitForSingleObject (pi.hProcess, 100)==WAIT_TIMEOUT)
  {
	  if(pProcessDataProc && !pProcessDataProc(NULL,iCon=(iCon<0)?100000:iCon-1000))
			break;

    FlushOutPipe(hPipeOutputRead, m_hFile, false);

    MSG msg;
    while(PeekMessage(&msg, 0, 0, 0, PM_REMOVE))
      DispatchMessage(&msg);
  }

  FlushOutPipe(hPipeOutputRead, m_hFile, true);   

  if(!ExitCode)
		GetExitCodeProcess(pi.hProcess,(LPDWORD)&ExitCode);

  if(bRedirectConsole)
    theMAConsole.OnExecuteCommand(false, m_bShowConsole);

   // Close all remaining handles
  CloseHandle (pi.hProcess);
  CloseHandle (hPipeInputWrite);
  CloseHandle (hPipeOutputRead);

  if(m_bSaveList)
  {
		DWORD dwSize=GetFileSize(m_hFile,NULL);
		m_hFileMap=CreateFileMapping(m_hFile,NULL,PAGE_READWRITE,0,dwSize+1,NULL);
		m_lpData=(LPSTR)MapViewOfFile(m_hFileMap,FILE_MAP_WRITE,0,0,0);
		m_lpData[dwSize]=0;
		if(m_bDoOemConversion)
			OemToChar(m_lpData,m_lpData);
	}
	else
	{
		CloseHandle(m_hFile);
		m_hFile=NULL;
	}

	return ExitCode;
}

void CConsoleOutput::ReleaseContents()
{
	if(m_lpData)
	{
		UnmapViewOfFile(m_lpData);
		m_lpData=NULL;
	}

	if(m_hFileMap)
	{
		CloseHandle(m_hFileMap);
		m_hFileMap=NULL;
	}

	if(m_hFile)
	{
		CloseHandle(m_hFile);
		m_hFile=NULL;
	}
}
