//{{NO_DEPENDENCIES}}
// Microsoft Developer Studio generated include file.
// Used by multiarc.rc
//
#define IDM_BREAK_RUN                   102
#define IDC_CURSOR                      103
#define IDB_BITMAP1                     106
#define IDI_ICON                        107
#define IDC_STATIC_NAME                 1001
#define IDC_STATIC_MAIL                 1002
#define IDC_STATIC_MAIL2                1003
#define IDC_STATIC_VERSION              1004
#define IDC_STATIC_THANKS               1005
#define IDC_STATIC_URL                  1006
#define IDC_STATIC_WEB                  1007
#define IDC_PAGE_ADDONS                 1010
#define IDC_BUTTON_CAPABILITIES         1011
#define IDC_BUTTON_EDIT_INI             1012
#define IDC_BUTTON_IMPORT               1013
#define IDC_BUTTON_REMOVE               1014
#define IDC_BUTTON_PATH                 1015
#define IDC_CHANGE_WINCMD_INI_BUTTON    1016
#define IDC_CHECK_SPARAM                1017
#define IDC_CHECK_XLIST                 1018
#define IDC_COMBO_SMODE                 1019
#define IDC_COMBO_TYPE                  1020
#define IDC_EDIT_PATH                   1021
#define IDC_LABEL_PATH                  1022
#define IDC_LABEL_STATUS                1023
#define IDC_STATIC_ACTIVE               1024
#define IDC_STATIC_ASK                  1025
#define IDC_STATIC_CURRENT_INI_CAPTION  1026
#define IDC_STATIC_CURRENT_WINCMD_INI   1027
#define IDC_STATIC_DESCRIPTION          1028
#define IDC_STATIC_TYPE                 1029
#define IDC_CHECK_CAPS_BASE             1040
#define IDC_CHECK_CAN_CREATE            1040
#define IDC_CHECK_CAN_MODIFY            1041
#define IDC_CHECK_MULTI_FILES           1042
#define IDC_CHECK_DETECT_TYPE           1043
#define IDC_CHECK_CAN_DELETE            1044
#define IDC_CHECK_SUPPORTS_SEARCH       1045
#define IDC_CHECK_HIDE_ICON             1046
#define IDC_CHECK_CAPS_END              1046
#define IDC_COMBO_EXTS                  1047
#define IDC_CHECK_ACTIVE                1048
#define IDC_STATIC_EXTENSION            1049
#define IDC_STATIC_SHOW_CONSOLE         1050
#define IDC_COMBO_CMODE                 1051
#define IDC_CHECK_XLIST_CONSOLE         1052
#define IDC_CHECK_TRAY                  1053
#define IDC_CHECK_AUTOCLOSE             1054
#define IDC_LABEL_DELAY                 1055
#define IDC_EDIT_DELAY                  1056
#define IDC_LABEL_SECONDS               1057
#define IDC_LABEL_HEIGHT                1058
#define IDC_EDIT_LINES                  1059
#define IDC_LABEL_LINES                 1060
#define IDC_STATIC_REQ                  1070
#define IDC_EDIT                        1071
#define IDC_PAGE_SETTINGS               1072
#define IDC_STATIC_WAIT_MESSAGE         1080
#define IDC_BUTTON_WAIT_TERMINATE       1081
#define IDC_PAGE_LANGUAGE               1082
#define IDC_LANG_LABEL_LANGUAGE         1083
#define IDC_LANG_COMBO_LANGUAGE         1084
#define IDC_LANG_LABEL_VERSION          1086
#define IDC_LANG_LABEL_LASTEDIT         1087
#define IDC_LANG_VERSION                1088
#define IDC_LANG_LASTEDIT               1089
#define IDC_LANG_LIST_PARAMETERS        1090
#define IDC_LANG_EDIT_VALUE             1093
#define IDC_LANG_LABEL_PARAMETERS       1094
#define IDC_LANG_LABEL_VALUE            1095
#define IDC_LANG_GROUP_FILEINFO         1096
#define IDC_HLP_LNG_REFERENCE           1097
#define IDC_EDIT_ASK_DLG                1098
#define IDC_EDIT_SPARAM_DLG             1099
#define IDH_TC_PLUGIN_SEARCH            1100
#define IDC_BUTTON1                     1101

// Next default values for new objects
// 
#ifdef APSTUDIO_INVOKED
#ifndef APSTUDIO_READONLY_SYMBOLS
#define _APS_NEXT_RESOURCE_VALUE        157
#define _APS_NEXT_COMMAND_VALUE         40002
#define _APS_NEXT_CONTROL_VALUE         1102
#define _APS_NEXT_SYMED_VALUE           107
#endif
#endif
